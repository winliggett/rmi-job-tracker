# ProTrack Logo Customization

## White-Label Logo Setup

ProTrack supports custom company logos that display throughout the app. Logos can be uploaded directly through the admin settings panel.

## How to Upload Your Logo

1. **Login as Admin** - Use admin credentials to access the app
2. **Go to Settings** - Navigate to the Settings tab
3. **Find Company Branding** - Scroll to the Company Branding section
4. **Click "Upload Logo"** - Select your logo image file
5. **Save** - The logo updates immediately throughout the app

## Logo Requirements

- **Format**: PNG, JPG, or JPEG
- **Size**: Maximum 5MB
- **Recommended Dimensions**: 400x400 pixels or larger (square works best)
- **Background**: Transparent PNG recommended for best results

## Where the Logo Appears

- Login screen
- Dashboard header (if configured)
- TV Dashboard mode
- Email notifications

## App Store Icons

For publishing to app stores, you'll need:

### App Icon (Required)
**Size:** 1024x1024 pixels
**Format:** PNG with transparency
**Usage:** Shows on home screen, App Store

### Splash Screen (Required)
**Size:** 1284x2778 pixels
**Format:** PNG
**Background:** Professional color that matches your brand

### Android Adaptive Icon
**Size:** 1024x1024 pixels
**Format:** PNG with transparency
**Note:** Should work on colored backgrounds

### Favicon (for web)
**Size:** 48x48 pixels
**Format:** PNG

---

## Design Recommendations

### Logo Style
- Simple, clean design
- Works in both color and monochrome
- Readable at small sizes (as small as 16x16)
- Professional construction industry aesthetic

### Color Palette Suggestions
- **Primary Blue:** #1e3a5f (ProTrack default)
- **Accent Blue:** #2563eb
- **White:** #FFFFFF for contrast

---

## Default ProTrack Logo

The default ProTrack logo files are included:
- `protrack-logo.png` - Main logo for splash/login
- `protrack-icon.png` - App icon

These are replaced when you upload a custom logo through the admin panel.

---

## Technical Details

Uploaded logos are stored in `/uploads/company/` and served via the Express static file handler. The logo path is stored in the `company_settings` database table and fetched via the `CompanyContext`.
