# ProTrack - Contractor Job Management (Multi-Tenant SaaS)

## Overview

ProTrack is a professional white-label job tracking application designed for contractors and construction companies. It's a React Native app built with Expo that enables construction teams to manage jobs, track tasks, capture photos, use voice dictation, and send notifications via @mentions. The app follows a client-server architecture with an Express.js backend and PostgreSQL database. It operates as a multi-tenant SaaS where each company gets isolated data.

## Key Features

- **Multi-Tenant SaaS**: Each company gets its own isolated data via company_id scoping
- **Owner Registration**: New companies can register with a company name, creating an owner account
- **Invite System**: Admins/owners can invite team members via email with role selection
- **White-Label Ready**: Customizable company branding (logo, name, contact info)
- **Voice Commands**: AI-powered voice dictation for hands-free task creation
- **Job Management**: Full CRUD operations for jobs with status tracking
- **Team Management**: Worker assignments, trades, notification preferences
- **@Mention Notifications**: SMS and email alerts when team members are mentioned
- **Photo Documentation**: Camera and gallery integration for job photos
- **TV Dashboard**: Full-screen display mode for office monitoring

## Architecture

### Frontend (React Native/Expo)
- Entry point: `App.js`
- Screens: `screens/` directory
  - `RegisterScreen.js` - New company registration flow
  - `JoinScreen.js` - Accept invite and create account
  - `LoginScreen.js` - Login with "Sign Up" link
  - `SettingsScreen.js` - Team invite management section
- Components: `components/` directory
- Contexts: `contexts/` (UserContext, CompanyContext)
- Utils: `utils/` (API, theme, voice corrections)

### Backend (Express.js)
- Entry point: `server/index.js`
- Port: 5000
- Database: PostgreSQL via `pg` Pool
- Notification service: `server/notificationService.js` (company-scoped SMTP)

### Multi-Tenant Design
- All tables have a `company_id` column
- All API queries are scoped by `company_id` from the JWT token
- JWT tokens contain: `id`, `username`, `role`, `company_id`
- Roles: `owner` (company creator), `admin`, `user`
- `isAdmin()` returns true for both `admin` and `owner` roles
- 403 enforcement prevents cross-company data access

### Database Tables
- `companies` - Company registry (name, email, created_at)
- `users` - Team members and authentication (company_id scoped)
- `jobs` - Job records with status, address, notes (company_id scoped)
- `tasks` - Task assignments per job (company_id scoped)
- `notes` - Job notes with @mentions (company_id scoped)
- `photos` - Photo attachments (company_id scoped)
- `activity_logs` - Audit trail (company_id scoped)
- `company_settings` - White-label configuration (company_id scoped)
- `settings` - App settings with UNIQUE(key, company_id) constraint
- `email_accounts` - SMTP notification accounts (company_id scoped)
- `notifications_log` - Notification history
- `invites` - Pending team invites (token, email, role, company_id, expires_at)

### Auth Endpoints
- `POST /api/auth/register` - Create new company + owner account
- `POST /api/auth/accept-invite` - Accept invite and create account
- `POST /api/auth/login` - Login with username/password
- `PUT /api/auth/change-password` - Change password
- `PUT /api/auth/change-username` - Change username

### Invite Flow
- Admins/owners create invites via `POST /api/invites`
- Token-based, 7-day expiry
- Invite URL format: `${appUrl}/invite/${token}`
- `GET /api/invites/verify/:token` verifies an invite token
- `GET /api/invites` lists pending invites for the company
- `DELETE /api/invites/:id` cancels an invite
- Web app detects `/invite/{token}` URLs and opens JoinScreen

## Running the App

The Backend API workflow runs `node server/index.js` on port 5000.

## White-Label Configuration

Admins can customize:
1. Company logo (uploaded via Settings)
2. Company name
3. Contact phone, email, address

Settings are stored in `company_settings` table and loaded via `CompanyContext`.

## Voice Commands

Natural language voice input is parsed by Claude AI:
- "Tell [worker] to [task] at [job/address]"
- "Add a note about [topic]"
- Supports fuzzy matching for worker names and job addresses

## Notifications

- Email: Configure SMTP accounts in Settings (company-scoped transporter caching)
- SMS: Configure Twilio credentials as environment secrets
- Notifications triggered by @mentions in notes and tasks
- Duplicate prevention (24-hour window)

## Development Notes

- All API routes prefixed with `/api/`
- Authentication via JWT tokens (contain company_id)
- Admin/owner role required for team management and company settings
- Mobile-first design with web support
- Database migrations run automatically at startup via `runMultiTenantMigrations()`
