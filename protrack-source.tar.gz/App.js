import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import NetInfo from '@react-native-community/netinfo';

import { UserProvider, useUser } from './contexts/UserContext';
import { CompanyProvider, useCompany } from './contexts/CompanyContext';
import { ToastProvider } from './components/Toast';
import { VoiceToastProvider } from './components/VoiceToast';
import DashboardScreen from './screens/DashboardScreen';
import JobDetailsScreen from './screens/JobDetailsScreen';
import CreateJobScreen from './screens/CreateJobScreen';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import JoinScreen from './screens/JoinScreen';
import SettingsScreen from './screens/SettingsScreen';
import MyTasksScreen from './screens/MyTasksScreen';
import TVDashboardScreen from './screens/TVDashboardScreen';
import GlobalVoiceButton from './components/GlobalVoiceButton';
import { colors, typography } from './utils/theme';

import { navigationRef } from './utils/navigation';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const screenOptions = {
  headerStyle: {
    backgroundColor: colors.backgroundSecondary,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
  },
  headerTintColor: colors.primary,
  headerTitleStyle: {
    ...typography.headline,
    color: colors.text,
    fontWeight: '600',
  },
  headerShadowVisible: false,
  headerBackTitleVisible: false,
  contentStyle: {
    backgroundColor: colors.background,
  },
};

function DashboardStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="DashboardHome"
        component={DashboardScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="JobDetails"
        component={JobDetailsScreen}
        options={{
          title: 'Job Details',
        }}
      />
      <Stack.Screen
        name="CreateJob"
        component={CreateJobScreen}
        options={{
          title: 'New Job',
          presentation: 'modal',
        }}
      />
      <Stack.Screen
        name="TVDashboard"
        component={TVDashboardScreen}
        options={{
          headerShown: false,
          presentation: 'fullScreenModal',
        }}
      />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="SettingsHome"
        component={SettingsScreen}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
}

function MyTasksStack() {
  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="MyTasksHome"
        component={MyTasksScreen}
        options={{
          title: 'My Jobs',
        }}
      />
      <Stack.Screen
        name="JobDetails"
        component={JobDetailsScreen}
        options={{
          title: 'Job Details',
        }}
      />
    </Stack.Navigator>
  );
}

function TabIcon({ name, focused }) {
  const iconStyle = {
    fontSize: 24,
    color: focused ? colors.primary : colors.textTertiary,
  };
  const icons = {
    Dashboard: '📋',
    MyTasks: '✅',
    Settings: '⚙️',
  };
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', minWidth: 48, minHeight: 48 }}>
      <Text style={iconStyle}>{icons[name] || '📋'}</Text>
    </View>
  );
}

function MainTabs() {
  const { isAdmin } = useUser();
  
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarStyle: {
          backgroundColor: colors.backgroundSecondary,
          borderTopColor: colors.borderLight,
          paddingTop: 8,
          paddingBottom: 8,
          height: 84,
        },
        tabBarLabelStyle: {
          ...typography.caption1,
          fontWeight: '600',
        },
      })}
    >
      {isAdmin() && (
        <Tab.Screen
          name="Dashboard"
          component={DashboardStack}
          options={{
            tabBarLabel: 'Jobs',
          }}
        />
      )}
      <Tab.Screen
        name="MyTasks"
        component={MyTasksStack}
        options={{
          tabBarLabel: 'My Jobs',
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsStack}
        options={{
          tabBarLabel: 'Settings',
        }}
      />
    </Tab.Navigator>
  );
}

function LoadingScreen() {
  return (
    <View style={styles.loadingContainer}>
      <View style={styles.logoContainer}>
        <Text style={styles.logoEmoji}>📋</Text>
        <Text style={styles.appName}>ProTrack</Text>
        <Text style={styles.appTagline}>Contractor Job Management</Text>
      </View>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={styles.loadingText}>Loading...</Text>
    </View>
  );
}

function getInviteTokenFromUrl() {
  if (Platform.OS === 'web') {
    try {
      const path = window.location.pathname;
      const match = path.match(/\/invite\/([a-f0-9]+)/i);
      if (match) return match[1];
    } catch (e) {}
  }
  return null;
}

function AppNavigator() {
  const { user, isLoading, login } = useUser();
  const { fetchSettings } = useCompany();
  const [inviteToken] = useState(() => getInviteTokenFromUrl());

  const handleLogin = (userData, authToken) => {
    login(userData, authToken);
    fetchSettings(authToken);
    if (Platform.OS === 'web' && window.location.pathname.includes('/invite/')) {
      window.history.replaceState({}, '', '/');
    }
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <View style={{ flex: 1 }}>
      <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName={inviteToken ? 'Join' : 'Login'}>
        {!user ? (
          <>
            <Stack.Screen name="Login">
              {props => (
                <LoginScreen
                  {...props}
                  onLogin={handleLogin}
                  onSignUp={() => props.navigation.navigate('Register')}
                />
              )}
            </Stack.Screen>
            <Stack.Screen name="Register">
              {props => (
                <RegisterScreen
                  {...props}
                  onBack={() => props.navigation.goBack()}
                  onRegisterSuccess={handleLogin}
                />
              )}
            </Stack.Screen>
            <Stack.Screen name="Join">
              {props => (
                <JoinScreen
                  {...props}
                  inviteToken={inviteToken || props.route?.params?.token}
                  onBack={() => props.navigation.navigate('Login')}
                  onJoinSuccess={handleLogin}
                />
              )}
            </Stack.Screen>
          </>
        ) : (
          <Stack.Screen name="Main" component={MainTabs} />
        )}
      </Stack.Navigator>
      {user && <GlobalVoiceButton />}
    </View>
  );
}

export default function App() {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    if (Platform.OS === 'web') {
      const updateOnlineStatus = () => setIsOnline(window.navigator.onLine);
      window.addEventListener('online', updateOnlineStatus);
      window.addEventListener('offline', updateOnlineStatus);
      updateOnlineStatus();
      return () => {
        window.removeEventListener('online', updateOnlineStatus);
        window.removeEventListener('offline', updateOnlineStatus);
      };
    } else {
      const unsubscribe = NetInfo.addEventListener(state => {
        setIsOnline(state.isConnected === true && state.isInternetReachable !== false);
      });
      return () => unsubscribe();
    }
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <CompanyProvider>
          <UserProvider>
            <ToastProvider>
              {!isOnline && (
                <View style={styles.offlineBanner}>
                  <Text style={styles.offlineBannerText}>
                    No internet connection - some features unavailable
                  </Text>
                </View>
              )}
              <VoiceToastProvider>
                <NavigationContainer ref={navigationRef}>
                  <StatusBar style="dark" />
                  <AppNavigator />
                </NavigationContainer>
              </VoiceToastProvider>
            </ToastProvider>
          </UserProvider>
        </CompanyProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoEmoji: {
    fontSize: 80,
    marginBottom: 16,
  },
  appName: {
    ...typography.title1,
    color: colors.text,
    fontWeight: '700',
  },
  appTagline: {
    ...typography.subhead,
    color: colors.textSecondary,
    marginTop: 4,
  },
  loadingText: {
    marginTop: 16,
    ...typography.body,
    color: colors.textTertiary,
  },
  offlineBanner: {
    backgroundColor: '#ff6b6b',
    padding: 12,
    alignItems: 'center',
    zIndex: 9999,
  },
  offlineBannerText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 14,
  },
});
