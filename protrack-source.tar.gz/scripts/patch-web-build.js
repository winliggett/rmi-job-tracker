#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const distIndexPath = path.join(__dirname, '..', 'dist', 'index.html');

if (!fs.existsSync(distIndexPath)) {
  console.error('dist/index.html not found. Run "npx expo export --platform web" first.');
  process.exit(1);
}

let html = fs.readFileSync(distIndexPath, 'utf8');

const newViewport = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';
html = html.replace(
  /content="width=device-width[^"]*"/,
  `content="${newViewport}"`
);

if (!html.includes('theme-color')) {
  html = html.replace(
    '</title>',
    `</title>
    <meta name="theme-color" content="#1C3B59" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />`
  );
}

const cssReset = `
      * {
        box-sizing: border-box;
        -webkit-tap-highlight-color: transparent;
      }
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
        overflow-x: hidden;
        -webkit-overflow-scrolling: touch;
        overscroll-behavior: none;
      }
      body {
        overflow: hidden;
      }
      input, textarea, select {
        font-size: 16px !important;
      }
      @supports (-webkit-touch-callout: none) {
        body {
          min-height: -webkit-fill-available;
        }
      }
      ::-webkit-scrollbar {
        width: 6px;
        height: 6px;
      }
      ::-webkit-scrollbar-track {
        background: transparent;
      }
      ::-webkit-scrollbar-thumb {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 3px;
      }`;

if (!html.includes('-webkit-tap-highlight-color')) {
  html = html.replace(
    '<style id="expo-reset">',
    `<style id="expo-reset">${cssReset}`
  );
}

html = html.replace(
  /#root\s*\{[^}]*\}/,
  `#root {
        display: flex;
        width: 100%;
        height: 100%;
        flex: 1;
      }`
);

fs.writeFileSync(distIndexPath, html);
console.log('✅ Web build patched with mobile responsiveness fixes');
