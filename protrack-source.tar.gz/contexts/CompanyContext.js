import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getApiUrl } from '../utils/api';

const CompanyContext = createContext(null);

const defaultSettings = {
  company_name: 'ProTrack',
  logo_path: null,
  contact_phone: '',
  contact_email: '',
  business_address: '',
  primary_color: '#2563eb',
  setup_completed: false
};

export function CompanyProvider({ children }) {
  const [settings, setSettings] = useState(defaultSettings);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchSettings = useCallback(async (authToken) => {
    try {
      setIsLoading(true);
      const storedToken = authToken || await AsyncStorage.getItem('token');
      const headers = {};
      if (storedToken) {
        headers['Authorization'] = `Bearer ${storedToken}`;
      }
      const response = await fetch(`${getApiUrl()}/api/company-settings`, { headers });
      if (response.ok) {
        const data = await response.json();
        setSettings({ ...defaultSettings, ...data });
      }
    } catch (err) {
      console.error('Failed to fetch company settings:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  const updateSettings = useCallback(async (newSettings, token) => {
    try {
      const response = await fetch(`${getApiUrl()}/api/company-settings`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newSettings)
      });
      
      if (response.ok) {
        const data = await response.json();
        setSettings({ ...defaultSettings, ...data });
        return { success: true, data };
      } else {
        const error = await response.json();
        return { success: false, error: error.error };
      }
    } catch (err) {
      console.error('Failed to update company settings:', err);
      return { success: false, error: err.message };
    }
  }, []);

  const uploadLogo = useCallback(async (file, token) => {
    try {
      const formData = new FormData();
      formData.append('logo', file);
      
      const response = await fetch(`${getApiUrl()}/api/company-settings/logo`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });
      
      if (response.ok) {
        const data = await response.json();
        setSettings(prev => ({ ...prev, logo_path: data.logo_path }));
        return { success: true, logo_path: data.logo_path };
      } else {
        const error = await response.json();
        return { success: false, error: error.error };
      }
    } catch (err) {
      console.error('Failed to upload logo:', err);
      return { success: false, error: err.message };
    }
  }, []);

  const getLogoUrl = useCallback(() => {
    if (settings.logo_path) {
      return `${getApiUrl()}${settings.logo_path}`;
    }
    return null;
  }, [settings.logo_path]);

  const value = {
    settings,
    isLoading,
    error,
    fetchSettings,
    updateSettings,
    uploadLogo,
    getLogoUrl,
    companyName: settings.company_name,
    isSetupComplete: settings.setup_completed
  };

  return (
    <CompanyContext.Provider value={value}>
      {children}
    </CompanyContext.Provider>
  );
}

export function useCompany() {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return context;
}

export default CompanyContext;
