const listeners = {};

export const VOICE_REFRESH_EVENT = 'voiceCommandRefresh';
export const JOBS_UPDATED_EVENT = 'jobsUpdated';

export function emit(event, data) {
  if (listeners[event]) {
    listeners[event].forEach(callback => callback(data));
  }
}

export function on(event, callback) {
  if (!listeners[event]) {
    listeners[event] = [];
  }
  listeners[event].push(callback);
  return () => off(event, callback);
}

export function off(event, callback) {
  if (listeners[event]) {
    listeners[event] = listeners[event].filter(cb => cb !== callback);
  }
}
