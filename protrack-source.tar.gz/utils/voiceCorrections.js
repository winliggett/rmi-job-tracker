const voiceCorrections = {
  "sidney": "sydney",
  "gene": "jean", 
  "jon": "john",
  "jim": "gym",
  "lee": "leigh",
  "will": "bill",
  "bob": "rob",
  "read": "reed",
  "micheal": "michael",
  "sara": "sarah",
  "mike": "mike",
  "smith": "smith",
  "johnson": "johnson",
  "williams": "williams",
  
  "sealing": "ceiling",
  "flour": "floor",
  "would": "wood",
  "steal": "steel",
  "wait": "weight",
  "pane": "pain",
  "plane": "plain",
  "drywall": "dry wall",
  "baseboards": "base boards",
  "heater": "heater",
  "plummer": "plumber",
  "pluming": "plumbing",
  "electrick": "electric",
  "ruff": "roof",
  "shinggles": "shingles",
  
  "drive": "dr",
  "street": "st",
  "avenue": "ave",
  "road": "rd",
  "court": "ct",
  "circle": "cir",
  "lane": "ln",
  "boulevard": "blvd",
  "highway": "hwy",
  "place": "pl",
  
  "birmingham alabama": "birmingham al",
  "birmingham, alabama": "birmingham, al",
};

const numberWords = {
  "zero": "0",
  "one": "1",
  "won": "1",
  "two": "2",
  "to": "2",
  "too": "2",
  "three": "3",
  "four": "4",
  "for": "4",
  "five": "5",
  "six": "6",
  "sicks": "6",
  "seven": "7",
  "eight": "8",
  "ate": "8",
  "nine": "9",
  "niner": "9",
  "ten": "10",
};

export function applyVoiceCorrections(text) {
  if (!text) return { correctedText: '', corrections: [] };
  
  let correctedText = text.toLowerCase();
  const corrections = [];
  
  Object.entries(voiceCorrections).forEach(([wrong, right]) => {
    const regex = new RegExp(`\\b${wrong}\\b`, 'gi');
    if (regex.test(correctedText)) {
      corrections.push({ original: wrong, corrected: right });
      correctedText = correctedText.replace(regex, right);
    }
  });
  
  correctedText = correctedText.replace(/\b(\d+)\s+(st|street|rd|road|dr|drive|ave|avenue|ct|court|ln|lane|cir|circle|pl|place|blvd|boulevard|hwy|highway)\b/gi, (match, num, suffix) => {
    return `${num} ${suffix.toLowerCase()}`;
  });
  
  return { correctedText, corrections };
}

export function applyNumberCorrections(text, context = 'address') {
  if (!text) return text;
  
  let result = text;
  
  if (context === 'address') {
    result = result.replace(/\b(one|two|three|four|five|six|seven|eight|nine|zero)\s*(one|two|three|four|five|six|seven|eight|nine|zero)*\s*(one|two|three|four|five|six|seven|eight|nine|zero)*\s*(one|two|three|four|five|six|seven|eight|nine|zero)*\s*(one|two|three|four|five|six|seven|eight|nine|zero)*/gi, (match) => {
      const words = match.toLowerCase().split(/\s+/);
      return words.map(w => numberWords[w] || w).join('');
    });
  }
  
  return result;
}

export function calculateConfidence(transcription, corrections, matchedJob, matchedWorker) {
  let confidence = 0.8;
  
  if (corrections.length > 0) {
    confidence -= corrections.length * 0.05;
  }
  
  if (matchedJob) {
    confidence += 0.1;
  }
  
  if (matchedWorker) {
    confidence += 0.1;
  }
  
  confidence = Math.max(0.3, Math.min(1.0, confidence));
  
  if (confidence >= 0.8) {
    return { level: 'high', score: confidence, label: '✓ Clear audio', color: '#22c55e' };
  } else if (confidence >= 0.6) {
    return { level: 'medium', score: confidence, label: '⚠ Please verify', color: '#f59e0b' };
  } else {
    return { level: 'low', score: confidence, label: '⚠ Unclear — please check carefully', color: '#ef4444' };
  }
}

export function fuzzyMatch(input, candidates, threshold = 0.6) {
  if (!input || !candidates || candidates.length === 0) return [];
  
  const inputLower = input.toLowerCase().trim();
  
  const scored = candidates.map(candidate => {
    const candidateName = (candidate.name || candidate.client_name || '').toLowerCase();
    const candidateAddress = (candidate.address || '').toLowerCase();
    
    let nameScore = levenshteinSimilarity(inputLower, candidateName);
    let addressScore = 0;
    
    if (candidateAddress) {
      addressScore = levenshteinSimilarity(inputLower, candidateAddress);
    }
    
    if (candidateName.includes(inputLower) || inputLower.includes(candidateName)) {
      nameScore = Math.max(nameScore, 0.85);
    }
    if (candidateAddress && (candidateAddress.includes(inputLower) || inputLower.includes(candidateAddress))) {
      addressScore = Math.max(addressScore, 0.85);
    }
    
    const bestScore = Math.max(nameScore, addressScore);
    
    return {
      ...candidate,
      matchScore: bestScore,
      matchType: nameScore >= addressScore ? 'name' : 'address'
    };
  });
  
  return scored
    .filter(c => c.matchScore >= threshold)
    .sort((a, b) => b.matchScore - a.matchScore);
}

function levenshteinSimilarity(s1, s2) {
  if (s1 === s2) return 1;
  if (s1.length === 0 || s2.length === 0) return 0;
  
  const matrix = [];
  
  for (let i = 0; i <= s2.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= s1.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= s2.length; i++) {
    for (let j = 1; j <= s1.length; j++) {
      const cost = s1[j - 1] === s2[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  
  const maxLen = Math.max(s1.length, s2.length);
  return 1 - matrix[s2.length][s1.length] / maxLen;
}

export function extractAddressFromText(text) {
  if (!text) return null;
  
  const addressPatterns = [
    /(\d+\s+[\w\s]+(?:st|street|rd|road|dr|drive|ave|avenue|ct|court|ln|lane|cir|circle|pl|place|blvd|boulevard|hwy|highway)[\w\s,]*)/i,
    /at\s+([\d\w\s,]+(?:st|street|rd|road|dr|drive|ave|avenue|ct|court|ln|lane|cir|circle|pl|place|blvd|boulevard|hwy|highway)[\w\s,]*)/i,
    /(\d+\s+\w+\s+\w+)/i,
  ];
  
  for (const pattern of addressPatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[1].trim();
    }
  }
  
  return null;
}

export function extractWorkerFromText(text, workers) {
  if (!text || !workers || workers.length === 0) return null;
  
  const textLower = text.toLowerCase();
  
  for (const worker of workers) {
    const workerName = (worker.name || '').toLowerCase();
    const firstName = workerName.split(' ')[0];
    const lastName = workerName.split(' ').slice(-1)[0];
    
    if (textLower.includes(workerName) || 
        textLower.includes(firstName) || 
        textLower.includes(lastName)) {
      return { ...worker, matchScore: 1.0 };
    }
  }
  
  const matches = fuzzyMatch(text, workers, 0.5);
  return matches.length > 0 ? matches[0] : null;
}

export default {
  applyVoiceCorrections,
  applyNumberCorrections,
  calculateConfidence,
  fuzzyMatch,
  extractAddressFromText,
  extractWorkerFromText,
};
