import Constants from 'expo-constants';
import { Platform } from 'react-native';

export const DEMO_MODE = false;

const getApiBaseUrl = () => {
  if (Platform.OS === 'web') {
    return '';
  }
  
  // Check environment variable first
  const envUrl = Constants.expoConfig?.extra?.apiUrl || process.env.API_BASE_URL;
  if (envUrl) {
    return envUrl;
  }
  
  // Fallback with warning
  console.warn('⚠️  API_BASE_URL not set in environment - using hardcoded dev URL');
  console.warn('   This may break if Replit restarts. Set API_BASE_URL in Replit Secrets.');
  return 'https://010917b4-1da4-419c-9770-3b2536ed1686-00-1em4jfwcp7ryi.janeway.replit.dev';
};

const API_BASE_URL = getApiBaseUrl();

export const BASE_URL = API_BASE_URL;

export const getApiUrl = () => API_BASE_URL;

export async function apiRequest(endpoint, options = {}) {
  const separator = endpoint.includes('?') ? '&' : '?';
  const cacheBuster = `_t=${Date.now()}`;
  const url = `${API_BASE_URL}${endpoint}${separator}${cacheBuster}`;
  
  const config = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      ...options.headers,
    },
  };

  try {
    const response = await fetch(url, config);
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.error || 'Request failed');
    }
    
    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

export async function login(username, password, remember = true) {
  return apiRequest('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password, remember }),
  });
}

export async function getJobs(token, filters = {}) {
  const params = new URLSearchParams(filters);
  const response = await apiRequest(`/api/jobs?${params}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return (response?.jobs || []).map(job => ({
    ...job,
    client_name: job.customerName || job.client_name,
  }));
}

export async function getJob(token, jobId) {
  return apiRequest(`/api/jobs/${jobId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function createJob(token, jobData) {
  return apiRequest('/api/jobs', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(jobData),
  });
}

export async function updateJobStatus(token, jobId, status) {
  return apiRequest(`/api/jobs/${jobId}/status`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ status }),
  });
}

export async function updateJob(token, jobId, jobData) {
  return apiRequest(`/api/jobs/${jobId}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(jobData),
  });
}

export async function addNote(token, jobId, text, options = {}) {
  return apiRequest(`/api/jobs/${jobId}/notes`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ text, ...options }),
  });
}

export async function getSettings(token) {
  return apiRequest('/api/settings', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function updateSetting(token, key, value) {
  return apiRequest('/api/settings', {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ key, value }),
  });
}

export async function testSMS(token, phone) {
  return apiRequest('/api/settings/test-sms', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ phone }),
  });
}

export async function getDashboardStats(token) {
  return apiRequest('/api/dashboard/stats', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function assignTrades(token, jobId, trades) {
  return apiRequest(`/api/jobs/${jobId}/trades`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ trades }),
  });
}

export async function toggleTask(token, taskId) {
  return apiRequest(`/api/tasks/${taskId}/toggle`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function deleteTask(token, taskId) {
  return apiRequest(`/api/tasks/${taskId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getJobDetails(token, jobId) {
  return apiRequest(`/api/jobs/${jobId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getTeamMembers(token) {
  return apiRequest('/api/users', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function deleteJob(token, jobId) {
  return apiRequest(`/api/jobs/${jobId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getMyTasks(token) {
  return apiRequest('/api/my-tasks', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function createTask(token, jobId, description, assigneeId, source = 'manual') {
  return apiRequest(`/api/jobs/${jobId}/tasks`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ description, assigneeId, source }),
  });
}

export async function getJobActivity(token, jobId) {
  return apiRequest(`/api/jobs/${jobId}/activity`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getTradeUsers(token) {
  return apiRequest('/api/users/trades', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getPlacesAutocomplete(token, input) {
  return apiRequest(`/api/places/autocomplete?input=${encodeURIComponent(input)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getPlaceDetails(token, placeId) {
  return apiRequest(`/api/places/details?place_id=${encodeURIComponent(placeId)}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function createUser(token, userData) {
  return apiRequest('/api/users', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(userData),
  });
}

export async function deleteUser(token, userId) {
  return apiRequest(`/api/users/${userId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function getNotificationHistory(token, jobId) {
  return apiRequest(`/api/jobs/${jobId}/notifications`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function resendNotification(token, notificationId) {
  return apiRequest(`/api/notifications/${notificationId}/resend`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function updateNotificationPreference(token, userId, preference) {
  return apiRequest(`/api/users/${userId}/notification-preference`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ preference }),
  });
}

export async function checkDuplicateNotification(token, recipientId, jobId, taskDescription) {
  return apiRequest('/api/notifications/check-duplicate', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ recipientId, jobId, taskDescription }),
  });
}

export async function updateJobAssignments(token, jobId, assignedUserIds) {
  return apiRequest(`/api/jobs/${jobId}/assignments`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify({ assignedUserIds }),
  });
}

export async function getWorkerJobs(token) {
  return apiRequest('/api/admin/worker-jobs', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export default {
  BASE_URL: API_BASE_URL,
  DEMO_MODE,
  login,
  getJobs,
  getJob,
  getJobDetails,
  createJob,
  updateJob,
  updateJobStatus,
  deleteJob,
  addNote,
  getSettings,
  updateSetting,
  testSMS,
  getDashboardStats,
  assignTrades,
  toggleTask,
  deleteTask,
  getTeamMembers,
  getMyTasks,
  createTask,
  getJobActivity,
  getTradeUsers,
  getPlacesAutocomplete,
  getPlaceDetails,
  createUser,
  deleteUser,
  getNotificationHistory,
  resendNotification,
  updateNotificationPreference,
  checkDuplicateNotification,
  updateJobAssignments,
  getWorkerJobs,
};
