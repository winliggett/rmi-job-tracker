// Name matching utilities with fuzzy logic and nickname support

// Common nickname variations
const NICKNAME_MAP = {
  // First names
  'bob': ['robert', 'bobby', 'rob', 'robbie'],
  'robert': ['bob', 'bobby', 'rob', 'robbie'],
  'lee': ['leigh', 'li', 'leo'],
  'leigh': ['lee', 'li'],
  'joe': ['joseph', 'joey', 'josef'],
  'joseph': ['joe', 'joey', 'josef'],
  'josef': ['joe', 'joseph', 'joey'],
  'mike': ['michael', 'mikey', 'mick'],
  'michael': ['mike', 'mikey', 'mick'],
  'jim': ['james', 'jimmy', 'jamie'],
  'james': ['jim', 'jimmy', 'jamie'],
  'bill': ['william', 'billy', 'will'],
  'william': ['bill', 'billy', 'will'],
  'dan': ['daniel', 'danny'],
  'daniel': ['dan', 'danny'],
  'dave': ['david', 'davey'],
  'david': ['dave', 'davey'],
  'tom': ['thomas', 'tommy'],
  'thomas': ['tom', 'tommy'],
  'chris': ['christopher', 'kristopher'],
  'christopher': ['chris'],
  'matt': ['matthew', 'matty'],
  'matthew': ['matt', 'matty'],
  'nick': ['nicholas', 'nicky'],
  'nicholas': ['nick', 'nicky'],
  'steve': ['steven', 'stephen'],
  'steven': ['steve'],
  'stephen': ['steve'],
  'tony': ['anthony'],
  'anthony': ['tony'],
  'alex': ['alexander', 'alexandra', 'alexis'],
  'alexander': ['alex'],
  'sam': ['samuel', 'samantha'],
  'samuel': ['sam'],
  'ed': ['edward', 'eddie', 'ted', 'teddy'],
  'edward': ['ed', 'eddie', 'ted', 'teddy'],
  'rick': ['richard', 'ricky', 'dick'],
  'richard': ['rick', 'ricky', 'dick'],
  'cathy': ['catherine', 'katherine', 'kathy', 'kate', 'katie'],
  'catherine': ['cathy', 'kathy', 'kate', 'katie'],
  'katherine': ['cathy', 'kathy', 'kate', 'katie'],
  'jen': ['jennifer', 'jenny'],
  'jennifer': ['jen', 'jenny'],
  'liz': ['elizabeth', 'beth', 'betty', 'lizzy'],
  'elizabeth': ['liz', 'beth', 'betty', 'lizzy'],
  'sue': ['susan', 'susie', 'suzy'],
  'susan': ['sue', 'susie', 'suzy'],
  'pat': ['patricia', 'patrick'],
  'patricia': ['pat', 'patty', 'trish'],
  'patrick': ['pat', 'paddy'],
};

// Calculate Levenshtein distance between two strings
function levenshteinDistance(str1, str2) {
  const s1 = str1.toLowerCase();
  const s2 = str2.toLowerCase();
  
  const m = s1.length;
  const n = s2.length;
  
  // Create distance matrix
  const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
  
  // Initialize first column and row
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  
  // Fill in the rest
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (s1[i - 1] === s2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(
          dp[i - 1][j],     // deletion
          dp[i][j - 1],     // insertion
          dp[i - 1][j - 1]  // substitution
        );
      }
    }
  }
  
  return dp[m][n];
}

// Calculate similarity score (0-1) based on Levenshtein distance
function similarityScore(str1, str2) {
  if (!str1 || !str2) return 0;
  
  const s1 = str1.toLowerCase();
  const s2 = str2.toLowerCase();
  
  if (s1 === s2) return 1;
  
  const distance = levenshteinDistance(s1, s2);
  const maxLen = Math.max(s1.length, s2.length);
  
  return 1 - (distance / maxLen);
}

// Check if two names are nickname variations
function areNicknameVariations(name1, name2) {
  const n1 = name1.toLowerCase();
  const n2 = name2.toLowerCase();
  
  if (n1 === n2) return true;
  
  const variations1 = NICKNAME_MAP[n1] || [];
  const variations2 = NICKNAME_MAP[n2] || [];
  
  return variations1.includes(n2) || variations2.includes(n1);
}

// Find best matching name from a list of known contacts
function findBestMatch(spokenName, knownContacts) {
  if (!spokenName || !knownContacts || knownContacts.length === 0) {
    return { match: null, confidence: 0, alternatives: [] };
  }
  
  const spoken = spokenName.toLowerCase().trim();
  const results = [];
  
  for (const contact of knownContacts) {
    const name = contact.name || contact;
    const firstName = name.split(' ')[0].toLowerCase();
    const lastName = name.split(' ').slice(1).join(' ').toLowerCase();
    const fullName = name.toLowerCase();
    
    // Check exact matches
    if (fullName === spoken || firstName === spoken) {
      results.push({ contact, confidence: 1.0, matchType: 'exact' });
      continue;
    }
    
    // Check nickname matches
    if (areNicknameVariations(spoken, firstName)) {
      results.push({ contact, confidence: 0.95, matchType: 'nickname' });
      continue;
    }
    
    // Check last name match
    if (lastName && lastName === spoken) {
      results.push({ contact, confidence: 0.9, matchType: 'lastName' });
      continue;
    }
    
    // Calculate fuzzy similarity
    const firstNameSim = similarityScore(spoken, firstName);
    const fullNameSim = similarityScore(spoken, fullName);
    const lastNameSim = lastName ? similarityScore(spoken, lastName) : 0;
    
    const bestSim = Math.max(firstNameSim, fullNameSim, lastNameSim);
    
    if (bestSim >= 0.6) {
      results.push({ contact, confidence: bestSim, matchType: 'fuzzy' });
    }
  }
  
  // Sort by confidence descending
  results.sort((a, b) => b.confidence - a.confidence);
  
  if (results.length === 0) {
    return { match: null, confidence: 0, alternatives: [] };
  }
  
  const bestMatch = results[0];
  const alternatives = results.slice(1, 4).map(r => ({
    name: r.contact.name || r.contact,
    confidence: r.confidence
  }));
  
  return {
    match: bestMatch.contact,
    confidence: bestMatch.confidence,
    matchType: bestMatch.matchType,
    alternatives
  };
}

// Parse mentions from text (handles @name, "tell name to", "at name", etc.)
function extractMentions(text) {
  if (!text) return [];
  
  const mentions = [];
  
  // Pattern 1: @name
  const atPattern = /@(\w+)/gi;
  let match;
  while ((match = atPattern.exec(text)) !== null) {
    mentions.push({
      name: match[1],
      pattern: '@mention',
      startIndex: match.index
    });
  }
  
  // Pattern 2: "tell [name] to..." or "ask [name] to..."
  const tellPattern = /(?:tell|ask|have|get)\s+(\w+)\s+(?:to|about|if)/gi;
  while ((match = tellPattern.exec(text)) !== null) {
    mentions.push({
      name: match[1],
      pattern: 'tell-to',
      startIndex: match.index
    });
  }
  
  // Pattern 3: "for [name]" (task assignment)
  const forPattern = /(?:task|job|work)\s+(?:for|to)\s+(\w+)/gi;
  while ((match = forPattern.exec(text)) !== null) {
    mentions.push({
      name: match[1],
      pattern: 'for-assignment',
      startIndex: match.index
    });
  }
  
  // Pattern 4: "assign [name]" or "put [name] on"
  const assignPattern = /(?:assign|put)\s+(\w+)\s+(?:to|on)/gi;
  while ((match = assignPattern.exec(text)) !== null) {
    mentions.push({
      name: match[1],
      pattern: 'assign',
      startIndex: match.index
    });
  }
  
  // Deduplicate by name (case-insensitive)
  const seen = new Set();
  return mentions.filter(m => {
    const key = m.name.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// Format dollar amounts from speech
function formatDollarAmount(text) {
  if (!text) return text;
  
  let result = text;
  
  // "twelve thousand five hundred" -> $12,500
  const wordNumbers = {
    'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5,
    'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
    'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15,
    'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
    'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50,
    'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
    'hundred': 100, 'thousand': 1000, 'million': 1000000
  };
  
  // Handle patterns like "$12500" or "12,500 dollars"
  result = result.replace(/\$?\s*(\d{1,3}(?:,?\d{3})*(?:\.\d{2})?)\s*(?:dollars?)?/gi, (match, num) => {
    const cleanNum = num.replace(/,/g, '');
    const value = parseFloat(cleanNum);
    if (!isNaN(value)) {
      return `$${value.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
    }
    return match;
  });
  
  return result;
}

// Format address from speech
function formatAddress(text) {
  if (!text) return text;
  
  let result = text;
  
  // "eighteen oh five" -> "1805"
  result = result.replace(/(\w+)\s+oh\s+(\w+)/gi, (match, first, second) => {
    const numWords = {
      'one': '1', 'two': '2', 'three': '3', 'four': '4', 'five': '5',
      'six': '6', 'seven': '7', 'eight': '8', 'nine': '9',
      'ten': '10', 'eleven': '11', 'twelve': '12', 'thirteen': '13',
      'fourteen': '14', 'fifteen': '15', 'sixteen': '16', 'seventeen': '17',
      'eighteen': '18', 'nineteen': '19'
    };
    
    const firstNum = numWords[first.toLowerCase()] || first;
    const secondNum = numWords[second.toLowerCase()] || second;
    
    return `${firstNum}0${secondNum}`;
  });
  
  // Capitalize street types
  result = result.replace(/\b(street|avenue|boulevard|drive|lane|road|way|court|circle|place)\b/gi, 
    (match) => match.charAt(0).toUpperCase() + match.slice(1).toLowerCase());
  
  return result;
}

module.exports = {
  levenshteinDistance,
  similarityScore,
  areNicknameVariations,
  findBestMatch,
  extractMentions,
  formatDollarAmount,
  formatAddress,
  NICKNAME_MAP
};
