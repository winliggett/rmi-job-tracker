import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  Platform,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../utils/api';

const { width: screenWidth } = Dimensions.get('window');
const isLargeScreen = screenWidth > 1200;
const cardMinWidth = isLargeScreen ? 420 : 360;

const playNotificationSound = () => {
  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 880;
      oscillator.type = 'sine';
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
      
      setTimeout(() => {
        const osc2 = audioContext.createOscillator();
        const gain2 = audioContext.createGain();
        osc2.connect(gain2);
        gain2.connect(audioContext.destination);
        osc2.frequency.value = 1320;
        osc2.type = 'sine';
        gain2.gain.setValueAtTime(0.3, audioContext.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        osc2.start(audioContext.currentTime);
        osc2.stop(audioContext.currentTime + 0.3);
      }, 150);
    } catch (e) {
      console.log('Audio not supported');
    }
  }
};

const getStatusColor = (status) => {
  switch (status) {
    case 'active': return '#22c55e';
    case 'estimate': return '#f59e0b';
    case 'completed': return '#6b7280';
    case 'on_hold': return '#ef4444';
    case 'closed': return '#64748b';
    default: return '#6b7280';
  }
};

const getStatusLabel = (status) => {
  switch (status) {
    case 'active': return 'ACTIVE';
    case 'estimate': return 'ESTIMATE';
    case 'completed': return 'DONE';
    case 'on_hold': return 'ON HOLD';
    case 'closed': return 'CLOSED';
    default: return status?.toUpperCase() || 'UNKNOWN';
  }
};

export default function TVDashboardScreen({ navigation }) {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const previousJobsRef = useRef(null);
  const isFirstLoad = useRef(true);

  const loadJobs = useCallback(async () => {
    if (isFirstLoad.current) {
      setLoading(true);
    }
    setError(null);
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await fetch(`${api.BASE_URL}/api/jobs/tv-view`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        if (response.status === 403) {
          setError('Admin access required for TV mode');
        } else {
          setError(`Failed to load data (${response.status})`);
        }
        setLoading(false);
        return;
      }
      
      const data = await response.json();
      const newJobs = data.jobs || [];
      
      if (!isFirstLoad.current && previousJobsRef.current && soundEnabled) {
        const prevJobIds = new Set(previousJobsRef.current.map(j => j.id));
        const newJobIds = newJobs.map(j => j.id);
        const hasNewJob = newJobIds.some(id => !prevJobIds.has(id));
        
        const hasNewActivity = newJobs.some((newJob) => {
          const prevJob = previousJobsRef.current.find(p => p.id === newJob.id);
          if (!prevJob) return true;
          if (newJob.latest_note !== prevJob.latest_note) return true;
          if (newJob.pending_tasks !== prevJob.pending_tasks) return true;
          if (newJob.status !== prevJob.status) return true;
          return false;
        });
        
        if (hasNewJob || hasNewActivity) {
          playNotificationSound();
        }
      }
      
      previousJobsRef.current = newJobs;
      setJobs(newJobs);
      setLastUpdate(new Date());
      setError(null);
      isFirstLoad.current = false;
    } catch (err) {
      console.error('Failed to load TV data:', err);
      setError('Connection error. Will retry...');
    } finally {
      setLoading(false);
    }
  }, [soundEnabled]);

  useEffect(() => {
    loadJobs();
  }, [loadJobs]);

  useEffect(() => {
    const interval = setInterval(loadJobs, 30000);
    return () => clearInterval(interval);
  }, [loadJobs]);

  const toggleFullscreen = () => {
    if (Platform.OS === 'web') {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.();
        setIsFullscreen(true);
      } else {
        document.exitFullscreen?.();
        setIsFullscreen(false);
      }
    }
  };

  const exitTVMode = () => {
    if (Platform.OS === 'web' && document.fullscreenElement) {
      document.exitFullscreen?.();
    }
    navigation.goBack();
  };

  const activeJobs = jobs.filter(j => j.status !== 'completed' && j.status !== 'closed');
  const stats = {
    active: jobs.filter(j => j.status === 'active').length,
    estimate: jobs.filter(j => j.status === 'estimate').length,
    onHold: jobs.filter(j => j.status === 'on_hold').length,
    completed: jobs.filter(j => j.status === 'completed' || j.status === 'closed').length,
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>📺 ProTrack</Text>
          <Text style={styles.subtitle}>
            Last updated: {lastUpdate.toLocaleTimeString()} • Auto-refreshes every 30s
          </Text>
        </View>

        <View style={styles.headerButtons}>
          <TouchableOpacity 
            style={[styles.soundButton, !soundEnabled && styles.soundButtonOff]} 
            onPress={() => setSoundEnabled(!soundEnabled)}
          >
            <Text style={styles.soundButtonText}>
              {soundEnabled ? '🔔 Sound ON' : '🔕 Sound OFF'}
            </Text>
          </TouchableOpacity>
          {Platform.OS === 'web' && (
            <TouchableOpacity style={styles.fullscreenButton} onPress={toggleFullscreen}>
              <Text style={styles.fullscreenButtonText}>
                {isFullscreen ? '⬜ Exit Fullscreen' : '⬛ Fullscreen'}
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.exitButton} onPress={exitTVMode}>
            <Text style={styles.exitButtonText}>✕ Exit TV Mode</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.statsBar}>
        <View style={[styles.statCard, { borderColor: '#22c55e', backgroundColor: 'rgba(34, 197, 94, 0.1)' }]}>
          <Text style={styles.statNumber}>{stats.active}</Text>
          <Text style={[styles.statLabel, { color: '#22c55e' }]}>ACTIVE</Text>
        </View>
        <View style={[styles.statCard, { borderColor: '#f59e0b', backgroundColor: 'rgba(245, 158, 11, 0.1)' }]}>
          <Text style={styles.statNumber}>{stats.estimate}</Text>
          <Text style={[styles.statLabel, { color: '#f59e0b' }]}>ESTIMATES</Text>
        </View>
        <View style={[styles.statCard, { borderColor: '#ef4444', backgroundColor: 'rgba(239, 68, 68, 0.1)' }]}>
          <Text style={styles.statNumber}>{stats.onHold}</Text>
          <Text style={[styles.statLabel, { color: '#ef4444' }]}>ON HOLD</Text>
        </View>
        <View style={[styles.statCard, { borderColor: '#6b7280', backgroundColor: 'rgba(107, 114, 128, 0.1)' }]}>
          <Text style={styles.statNumber}>{stats.completed}</Text>
          <Text style={[styles.statLabel, { color: '#6b7280' }]}>COMPLETED</Text>
        </View>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>Loading jobs...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadJobs}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.gridContainer}>
          {activeJobs.map(job => (
            <TouchableOpacity 
              key={job.id} 
              style={[styles.jobCard, { borderColor: getStatusColor(job.status) }]}
              onPress={() => navigation.navigate('JobDetails', { jobId: job.id })}
              activeOpacity={0.8}
            >
              <View style={[styles.jobHeader, { backgroundColor: getStatusColor(job.status) + '20' }]}>
                <View style={styles.jobHeaderLeft}>
                  <Text style={styles.jobClientName}>{job.client_name}</Text>
                  <Text style={styles.jobAddress}>📍 {job.address}</Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
                  <Text style={styles.statusBadgeText}>{getStatusLabel(job.status)}</Text>
                </View>
              </View>

              <View style={styles.jobBody}>
                {job.door_code && (
                  <View style={styles.doorCodeBox}>
                    <Text style={styles.doorCodeLabel}>🔑 DOOR CODE</Text>
                    <Text style={styles.doorCodeValue}>{job.door_code}</Text>
                  </View>
                )}

                {job.assigned_trades && job.assigned_trades.length > 0 && (
                  <View style={styles.tradesSection}>
                    <Text style={styles.sectionLabel}>👷 ASSIGNED</Text>
                    <View style={styles.tradesContainer}>
                      {job.assigned_trades.map((trade, i) => (
                        <View key={i} style={styles.tradeBadge}>
                          <Text style={styles.tradeBadgeText}>{trade.name || trade}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                )}

                {job.latest_note && (
                  <View style={styles.noteBox}>
                    <Text style={styles.sectionLabel}>📝 LATEST NOTE</Text>
                    <Text style={styles.noteText} numberOfLines={3}>
                      {job.latest_note}
                    </Text>
                    {job.latest_note_by && (
                      <Text style={styles.noteAuthor}>— {job.latest_note_by}</Text>
                    )}
                  </View>
                )}

                {job.pending_tasks_list && job.pending_tasks_list.length > 0 && (
                  <View style={styles.tasksSection}>
                    <Text style={styles.sectionLabel}>📋 PENDING TASKS (Last 7 Days)</Text>
                    {job.pending_tasks_list.map((task, idx) => (
                      <View key={task.id || idx} style={styles.taskItem}>
                        <Text style={styles.taskDescription} numberOfLines={2}>
                          {task.description}
                        </Text>
                        {task.assignee && (
                          <Text style={styles.taskAssignee}>→ {task.assignee}</Text>
                        )}
                      </View>
                    ))}
                    {job.pending_tasks > job.pending_tasks_list.length && (
                      <Text style={styles.moreTasksText}>
                        +{job.pending_tasks - job.pending_tasks_list.length} more
                      </Text>
                    )}
                  </View>
                )}
              </View>
            </TouchableOpacity>
          ))}

          {activeJobs.length === 0 && (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateIcon}>📋</Text>
              <Text style={styles.emptyStateText}>No active jobs to display</Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  title: {
    fontSize: 42,
    fontWeight: '700',
    color: '#ffffff',
  },
  subtitle: {
    fontSize: 18,
    color: '#94a3b8',
    marginTop: 6,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  fullscreenButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  fullscreenButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  exitButton: {
    backgroundColor: '#475569',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  exitButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  soundButton: {
    backgroundColor: '#22c55e',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  soundButtonOff: {
    backgroundColor: '#6b7280',
  },
  soundButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  statsBar: {
    flexDirection: 'row',
    padding: 20,
    gap: 16,
  },
  statCard: {
    borderWidth: 3,
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 32,
    alignItems: 'center',
    minWidth: 140,
  },
  statNumber: {
    fontSize: 56,
    fontWeight: '700',
    color: '#ffffff',
  },
  statLabel: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 6,
    letterSpacing: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#94a3b8',
    marginTop: 16,
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  errorIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  errorText: {
    color: '#ef4444',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 20,
    gap: 20,
  },
  jobCard: {
    backgroundColor: '#1e293b',
    borderRadius: 16,
    borderWidth: 2,
    overflow: 'hidden',
    minWidth: cardMinWidth,
    maxWidth: 450,
    flex: 1,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  jobHeaderLeft: {
    flex: 1,
    marginRight: 12,
  },
  jobClientName: {
    fontSize: 32,
    fontWeight: '700',
    color: '#ffffff',
  },
  jobAddress: {
    fontSize: 18,
    color: '#94a3b8',
    marginTop: 6,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  statusBadgeText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '700',
  },
  jobBody: {
    padding: 16,
  },
  doorCodeBox: {
    backgroundColor: '#1c3b59',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fbbf24',
  },
  doorCodeLabel: {
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 6,
    letterSpacing: 1,
  },
  doorCodeValue: {
    fontSize: 56,
    fontWeight: '700',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    color: '#fbbf24',
    letterSpacing: 4,
  },
  tradesSection: {
    marginBottom: 12,
  },
  sectionLabel: {
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 10,
    fontWeight: '600',
  },
  tradesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
  },
  tradeBadge: {
    backgroundColor: '#334155',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 16,
  },
  tradeBadgeText: {
    fontSize: 16,
    color: '#e2e8f0',
    fontWeight: '500',
  },
  noteBox: {
    backgroundColor: '#0f172a',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  noteText: {
    fontSize: 18,
    color: '#e2e8f0',
    lineHeight: 26,
  },
  noteAuthor: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 8,
    fontStyle: 'italic',
  },
  tasksSection: {
    marginTop: 12,
    backgroundColor: '#0f172a',
    borderRadius: 8,
    padding: 12,
  },
  taskItem: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  taskDescription: {
    fontSize: 16,
    color: '#e2e8f0',
    lineHeight: 22,
  },
  taskAssignee: {
    fontSize: 14,
    color: '#3b82f6',
    marginTop: 4,
    fontWeight: '500',
  },
  moreTasksText: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 8,
    fontStyle: 'italic',
  },
  emptyState: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 60,
  },
  emptyStateIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyStateText: {
    fontSize: 18,
    color: '#64748b',
  },
});
