import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Dimensions,
  ActivityIndicator,
  Platform,
  ScrollView,
  DeviceEventEmitter,
  TextInput,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from '../utils/haptics';
import { useUser } from '../contexts/UserContext';
import { useCompany } from '../contexts/CompanyContext';
import { AdminOnly } from '../components/Protected';
import api from '../utils/api';
import { colors, typography, spacing, borderRadius, shadows, screenSizes } from '../utils/theme';
import ConfirmModal from '../components/ConfirmModal';
import { useToast } from '../components/Toast';
import { VOICE_REFRESH_EVENT, JOBS_UPDATED_EVENT, emit } from '../utils/events';

// STATUS_CONFIG with WCAG-compliant contrast (light bg, dark text)
const STATUS_CONFIG = {
  estimate: { label: 'Estimate', icon: '📝', bgColor: '#fef3c7', textColor: '#b45309' },
  active: { label: 'Active', icon: '🟢', bgColor: '#dcfce7', textColor: '#15803d' },
  completed: { label: 'Done', icon: '✅', bgColor: '#f1f5f9', textColor: '#475569' },
  on_hold: { label: 'On Hold', icon: '⏸️', bgColor: '#ffedd5', textColor: '#c2410c' },
  closed: { label: 'Closed', icon: '📁', bgColor: '#f1f5f9', textColor: '#475569' },
};

// Memoized Job Card Component - BIGGER text, BETTER contrast
const JobCard = React.memo(({ item, onPress, onDelete, isAdmin, isTrade, cardStyle }) => {
  const statusConfig = useMemo(
    () => STATUS_CONFIG[item.status] || STATUS_CONFIG.active,
    [item.status]
  );

  const handleDelete = (e) => {
    e.stopPropagation();
    if (onDelete) onDelete(item);
  };

  return (
    <TouchableOpacity
      style={[styles.jobCard, cardStyle]}
      onPress={() => onPress(item)}
      activeOpacity={0.7}
    >
      <View style={styles.cardContent}>
        {/* Urgent Badge - Red bg, WHITE text */}
        {item.urgent && (
          <View style={styles.urgentBadge}>
            <Text style={styles.urgentBadgeText}>🚨 URGENT</Text>
          </View>
        )}

        <View style={styles.cardHeader}>
          <Text style={styles.clientName} numberOfLines={2}>
            {item.client_name}
          </Text>
          {isAdmin && (
            <TouchableOpacity 
              style={styles.deleteIconButton} 
              onPress={handleDelete}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <Text style={styles.deleteIcon}>🗑️</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.addressRow}>
          <Text style={styles.addressIcon}>📍</Text>
          <Text style={styles.addressText} numberOfLines={2}>
            {item.address}
          </Text>
        </View>

        {/* Door Code - Show prominently for trade workers */}
        {isTrade && (item.door_code || item.key_location) && (
          <View style={styles.doorCodeRow}>
            <Text style={styles.doorCodeIcon}>🔑</Text>
            <Text style={styles.doorCodeText}>
              {item.door_code || item.key_location}
            </Text>
          </View>
        )}

        {item.description && (
          <Text style={styles.descriptionText} numberOfLines={2}>
            {item.description}
          </Text>
        )}

        <View style={styles.cardFooter}>
          {/* Status Badge - Light pastel bg, dark matching text */}
          <View style={[styles.statusPill, { backgroundColor: statusConfig.bgColor }]}>
            <Text style={styles.statusIcon}>{statusConfig.icon}</Text>
            <Text style={[styles.statusText, { color: statusConfig.textColor }]}>
              {statusConfig.label}
            </Text>
          </View>

          {item.active_tasks > 0 && (
            <View style={styles.taskBadge}>
              <Text style={styles.taskBadgeText}>{item.active_tasks} tasks</Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
});

// Memoized Filter Button - BIGGER touch targets
const FilterButton = React.memo(({ value, label, icon, isActive, onPress }) => (
  <TouchableOpacity
    style={[styles.filterChip, isActive && styles.filterChipActive]}
    onPress={onPress}
  >
    {icon && <Text style={styles.filterIcon}>{icon}</Text>}
    <Text style={[styles.filterChipText, isActive && styles.filterChipTextActive]}>
      {label}
    </Text>
  </TouchableOpacity>
));

// Calculate responsive columns based on screen width
const getNumColumns = (windowWidth, isAdminUser) => {
  if (windowWidth < 768) return 1; // Mobile/small tablet: always 1 column
  return isAdminUser ? 2 : 1; // Larger screens: 2 for admin
};

export default function DashboardScreen({ navigation }) {
  const { user, token, isAdmin, isTrade } = useUser();
  const { settings: companySettings } = useCompany();
  const toast = useToast();
  const [jobs, setJobs] = useState([]);
  const [stats, setStats] = useState(null);
  const [myTasks, setMyTasks] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState({ visible: false, job: null });
  const [windowWidth, setWindowWidth] = useState(Dimensions.get('window').width);
  const [isDesktop, setIsDesktop] = useState(Dimensions.get('window').width >= 1024);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [searching, setSearching] = useState(false);

  // Update window width and desktop status on resize
  useEffect(() => {
    const subscription = Dimensions.addEventListener('change', ({ window }) => {
      setWindowWidth(window.width);
      setIsDesktop(window.width >= 1024);
    });
    return () => subscription?.remove();
  }, []);

  const loadData = useCallback(async () => {
    if (!token) return;

    try {
      const filters = {};
      if (filter !== 'all' && filter !== 'urgent') {
        filters.status = filter;
      }
      if (filter === 'urgent') {
        filters.urgent = 'true';
      }

      const [jobsData, statsData] = await Promise.all([
        api.getJobs(token, filters),
        api.getDashboardStats(token),
      ]);
      setJobs(jobsData || []);
      if (isAdmin()) {
        setStats(statsData);
      } else {
        setMyTasks(statsData.myTasks || []);
      }
    } catch (error) {
      console.error('Load error:', error);
      toast.error('Unable to load. Please pull down to refresh');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [token, filter, isAdmin]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Listen for voice command refresh events
  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener(VOICE_REFRESH_EVENT, () => {
      console.log('Voice refresh event received - reloading dashboard');
      loadData();
    });
    return () => subscription?.remove();
  }, [loadData]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadData();
  }, [loadData]);

  const handleCardPress = useCallback((item) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    navigation.navigate('JobDetails', { jobId: item.id, onRefresh: loadData });
  }, [navigation, loadData]);

  const handleFilterChange = useCallback((newFilter) => {
    Haptics.selectionAsync();
    setFilter(newFilter);
    setSearchQuery('');
    setSearchResults(null);
  }, []);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim() || !token) return;
    
    setSearching(true);
    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setSearchResults(data);
      Haptics.selectionAsync();
    } catch (error) {
      console.error('Search error:', error);
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  }, [searchQuery, token, toast]);

  const clearSearch = useCallback(() => {
    setSearchQuery('');
    setSearchResults(null);
    Haptics.selectionAsync();
  }, []);

  const handleCreateJob = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    navigation.navigate('CreateJob', { onRefresh: loadData });
  }, [navigation, loadData]);

  const handleDeleteJob = useCallback((job) => {
    setDeleteConfirm({ visible: true, job });
  }, []);

  const confirmDeleteJob = useCallback(async () => {
    const job = deleteConfirm.job;
    if (!job) return;
    
    setDeleteConfirm({ visible: false, job: null });
    
    try {
      await api.deleteJob(token, job.id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      emit(JOBS_UPDATED_EVENT);
      loadData();
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Failed to delete job');
    }
  }, [token, loadData, deleteConfirm.job, toast]);

  const renderStatCard = useCallback((value, label, colorKey) => {
    const bgColors = {
      estimate: colors.statusEstimateBg,
      active: colors.statusActiveBg,
      urgent: colors.urgentBg,
      tasks: colors.backgroundTertiary,
    };
    return (
      <View style={[styles.statCard, { backgroundColor: bgColors[colorKey] }]}>
        <Text style={styles.statNumber}>{value || 0}</Text>
        <Text style={styles.statLabel}>{label}</Text>
      </View>
    );
  }, []);

  // Calculate responsive columns - width is handled by flex in styles
  const numColumns = useMemo(() => getNumColumns(windowWidth, isAdmin()), [windowWidth, isAdmin]);

  const renderJobCard = useCallback(({ item }) => (
    <JobCard 
      item={item} 
      onPress={handleCardPress} 
      onDelete={handleDeleteJob}
      isAdmin={isAdmin()}
      isTrade={isTrade()}
      cardStyle={numColumns === 1 ? styles.jobCardFull : styles.jobCardHalf}
    />
  ), [handleCardPress, handleDeleteJob, isAdmin, isTrade, numColumns]);

  const keyExtractor = useCallback((item) => item.id.toString(), []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* HEADER - Navy bg, WHITE text */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          {companySettings?.logo_path ? (
            <Image source={{ uri: companySettings.logo_path }} style={styles.headerLogo} />
          ) : (
            <Image source={require('../assets/protrack-icon.png')} style={styles.headerLogo} />
          )}
          <View>
            <Text style={styles.appName}>{companySettings?.company_name || 'ProTrack'}</Text>
            <Text style={styles.greeting}>
              Hello, {user?.name || 'Admin'}
            </Text>
          </View>
        </View>
        {isAdmin() && isDesktop && (
          <TouchableOpacity 
            style={styles.tvButton}
            onPress={() => navigation.navigate('TVDashboard')}
          >
            <Text style={styles.tvButtonText}>📺 TV</Text>
          </TouchableOpacity>
        )}
      </View>

      {isAdmin() && stats?.jobs && (
        <View style={styles.statsContainer}>
          {renderStatCard(stats.jobs.needs_estimate, 'Estimates', 'estimate')}
          {renderStatCard(stats.jobs.active_jobs, 'Active', 'active')}
          {renderStatCard(stats.jobs.urgent_jobs, 'Urgent', 'urgent')}
          {renderStatCard(stats.tasks?.pending_tasks, 'Tasks', 'tasks')}
        </View>
      )}

      {/* Trade worker quick task summary - removed in favor of showing full job cards below */}

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchInputWrapper}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            placeholder='Search jobs (e.g., "Bob tile" or "active jobs")'
            placeholderTextColor="#94a3b8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={clearSearch} style={styles.clearButton}>
              <Text style={styles.clearButtonText}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
        {searchQuery.length > 0 && (
          <TouchableOpacity 
            style={styles.searchButton} 
            onPress={handleSearch}
            disabled={searching}
          >
            <Text style={styles.searchButtonText}>
              {searching ? '...' : 'Search'}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Search Results */}
      {searchResults && (
        <View style={styles.searchResultsContainer}>
          <View style={styles.searchResultsHeader}>
            <Text style={styles.searchInterpretation}>
              {searchResults.interpretation || `Results for "${searchQuery}"`}
            </Text>
            <TouchableOpacity onPress={clearSearch}>
              <Text style={styles.clearSearchText}>Clear</Text>
            </TouchableOpacity>
          </View>
          {searchResults.jobs?.length > 0 ? (
            searchResults.jobs.map(job => (
              <TouchableOpacity 
                key={job.id} 
                style={styles.searchResultCard}
                onPress={() => navigation.navigate('JobDetails', { jobId: job.id, onRefresh: loadData })}
              >
                <Text style={styles.searchResultName}>{job.customer_name}</Text>
                <Text style={styles.searchResultAddress}>{job.address}</Text>
                <Text style={styles.searchResultStatus}>{job.status?.toUpperCase()}</Text>
              </TouchableOpacity>
            ))
          ) : (
            <Text style={styles.noResultsText}>No jobs found</Text>
          )}
        </View>
      )}

      <View style={styles.filterWrapper}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.filterScroll}
          contentContainerStyle={styles.filterContainer}
        >
          <FilterButton
            value="all"
            label="All"
            isActive={filter === 'all'}
            onPress={() => handleFilterChange('all')}
          />
        <FilterButton
          value="urgent"
          label="Urgent"
          icon="⚡"
          isActive={filter === 'urgent'}
          onPress={() => handleFilterChange('urgent')}
        />
        <FilterButton
          value="estimate"
          label="Estimate"
          icon="📝"
          isActive={filter === 'estimate'}
          onPress={() => handleFilterChange('estimate')}
        />
        <FilterButton
          value="active"
          label="Active"
          icon="🟢"
          isActive={filter === 'active'}
          onPress={() => handleFilterChange('active')}
        />
        <FilterButton
          value="on_hold"
          label="On Hold"
          icon="⏸️"
          isActive={filter === 'on_hold'}
          onPress={() => handleFilterChange('on_hold')}
        />
        <FilterButton
          value="completed"
          label="Done"
          icon="✅"
          isActive={filter === 'completed'}
          onPress={() => handleFilterChange('completed')}
        />
        <FilterButton
          value="closed"
          label="Closed"
          icon="📁"
          isActive={filter === 'closed'}
          onPress={() => handleFilterChange('closed')}
        />
        </ScrollView>
      </View>

      <FlatList
        data={jobs}
        renderItem={renderJobCard}
        keyExtractor={keyExtractor}
        numColumns={numColumns}
        key={numColumns}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={numColumns > 1 ? styles.gridRow : undefined}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        removeClippedSubviews={true}
        maxToRenderPerBatch={10}
        windowSize={5}
        initialNumToRender={8}
        ListEmptyComponent={
          loading ? (
            <View style={styles.emptyState}>
              <ActivityIndicator size="large" color={colors.primary} />
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>📋</Text>
              <Text style={styles.emptyTitle}>No Jobs Found</Text>
              <Text style={styles.emptySubtitle}>
                {isTrade()
                  ? 'No jobs assigned to you yet'
                  : 'Tap + below to create your first job'}
              </Text>
            </View>
          )
        }
      />

      <AdminOnly>
        <TouchableOpacity
          style={styles.fab}
          onPress={handleCreateJob}
          activeOpacity={0.8}
        >
          <Text style={styles.fabIcon}>+</Text>
        </TouchableOpacity>
      </AdminOnly>
      
      <ConfirmModal
        visible={deleteConfirm.visible}
        title="Delete Job"
        message={`Are you sure you want to delete "${deleteConfirm.job?.client_name}"?\n\nThis will permanently remove the job and all its notes, tasks, and activity history.`}
        confirmText="Delete"
        cancelText="Cancel"
        confirmStyle="danger"
        onConfirm={confirmDeleteJob}
        onCancel={() => setDeleteConfirm({ visible: false, job: null })}
      />
    </SafeAreaView>
  );
}

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  loadingLogo: {
    width: 80,
    height: 80,
    borderRadius: 16,
    marginBottom: spacing.sm,
  },
  appTitle: {
    fontSize: 28,
    color: colors.text,
    fontWeight: '700',
  },
  loadingText: {
    marginTop: spacing.md,
    fontSize: 18,
    color: colors.textTertiary,
  },
  // HEADER - Navy background, WHITE text
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.md,
    backgroundColor: '#1c3b59',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tvButton: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
    flexDirection: 'row',
    alignItems: 'center',
  },
  tvButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  headerLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: spacing.md,
    backgroundColor: '#ffffff',
  },
  appName: {
    fontSize: 22,
    color: '#ffffff',
    fontWeight: '700',
  },
  greeting: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.backgroundSecondary,
    gap: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
  },
  statCard: {
    flex: 1,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 32,
    color: '#1e293b',
    fontWeight: '700',
  },
  statLabel: {
    fontSize: 14,
    color: '#475569',
    marginTop: spacing.xs,
    fontWeight: '500',
  },
  myTasksContainer: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    backgroundColor: colors.backgroundSecondary,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
  },
  sectionTitle: {
    ...typography.title3,
    color: colors.text,
    marginBottom: spacing.md,
  },
  taskCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
  },
  taskCheckbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  checkboxInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: 'transparent',
  },
  taskContent: {
    flex: 1,
  },
  taskText: {
    ...typography.body,
    color: colors.text,
  },
  taskMeta: {
    ...typography.footnote,
    color: colors.textTertiary,
    marginTop: spacing.xs,
  },
  moreTasksText: {
    ...typography.footnote,
    color: colors.primary,
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  // FILTER CHIPS - BIGGER touch targets
  filterWrapper: {
    backgroundColor: '#f8fafc',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    zIndex: 1,
  },
  filterScroll: {
    overflow: 'visible',
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.lg,
    gap: spacing.sm,
    minHeight: 70,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    height: 48,
    borderRadius: 10,
    backgroundColor: '#ffffff',
    ...shadows.small,
  },
  filterChipActive: {
    backgroundColor: '#1c3b59',
    ...shadows.medium,
  },
  filterIcon: {
    fontSize: 16,
    marginRight: spacing.sm,
  },
  filterChipText: {
    fontSize: 16,
    color: '#1e293b',
    fontWeight: '600',
  },
  filterChipTextActive: {
    color: '#ffffff',
    fontWeight: '600',
  },
  listContent: {
    padding: spacing.lg,
    paddingBottom: 140,
  },
  gridRow: {
    justifyContent: 'space-between',
  },
  // JOB CARDS - BIGGER padding, BIGGER text
  jobCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    ...shadows.small,
    overflow: 'hidden',
  },
  jobCardFull: {
    flex: 1,
    width: '100%',
  },
  jobCardHalf: {
    width: '46%',
    marginHorizontal: '1%',
  },
  cardContent: {
    padding: 28,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.sm,
  },
  clientName: {
    fontSize: 28,
    color: '#1e293b',
    flex: 1,
    marginRight: spacing.sm,
    fontWeight: '700',
    lineHeight: 34,
  },
  urgentBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#ef4444',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
    marginBottom: spacing.sm,
  },
  urgentBadgeText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  deleteIconButton: {
    padding: spacing.sm,
    opacity: 0.6,
  },
  deleteIcon: {
    fontSize: 18,
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: spacing.md,
  },
  addressIcon: {
    fontSize: 20,
    flexShrink: 0,
  },
  addressText: {
    fontSize: 20,
    color: '#475569',
    lineHeight: 28,
    flex: 1,
  },
  doorCodeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fef3c7',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    marginTop: spacing.sm,
  },
  doorCodeIcon: {
    fontSize: 18,
    marginRight: spacing.sm,
  },
  doorCodeText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#92400e',
    letterSpacing: 1,
  },
  descriptionText: {
    fontSize: 18,
    color: '#64748b',
    marginBottom: spacing.lg,
    lineHeight: 26,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: 'auto',
  },
  // STATUS BADGE - Light bg, dark text (WCAG compliant)
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 20,
    height: 40,
    borderRadius: 10,
  },
  statusIcon: {
    fontSize: 15,
  },
  statusText: {
    fontSize: 16,
    fontWeight: '600',
  },
  taskBadge: {
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  taskBadgeText: {
    fontSize: 14,
    color: '#475569',
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.xxl * 2,
  },
  emptyIcon: {
    fontSize: 72,
    marginBottom: spacing.md,
    opacity: 0.4,
  },
  emptyTitle: {
    fontSize: 24,
    color: '#1e293b',
    marginBottom: spacing.sm,
    fontWeight: '600',
  },
  emptySubtitle: {
    fontSize: 17,
    color: '#64748b',
    textAlign: 'center',
    paddingHorizontal: spacing.xl,
    lineHeight: 24,
  },
  // FAB - BIGGER (72px)
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: 120,
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#1c3b59',
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.large,
  },
  fabIcon: {
    fontSize: 36,
    color: '#ffffff',
    fontWeight: '300',
    marginTop: -2,
  },
  // Search Styles
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  searchInputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: '#e2e8f0',
    paddingHorizontal: spacing.md,
    height: 50,
  },
  searchIcon: {
    fontSize: 18,
    marginRight: spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1e293b',
    paddingVertical: spacing.sm,
  },
  clearButton: {
    padding: spacing.xs,
  },
  clearButtonText: {
    fontSize: 18,
    color: '#94a3b8',
  },
  searchButton: {
    backgroundColor: '#1c3b59',
    paddingHorizontal: spacing.lg,
    height: 50,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  searchResultsContainer: {
    backgroundColor: '#ffffff',
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    ...shadows.small,
  },
  searchResultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  searchInterpretation: {
    fontSize: 14,
    color: '#64748b',
    fontStyle: 'italic',
    flex: 1,
  },
  clearSearchText: {
    fontSize: 14,
    color: '#2563eb',
    fontWeight: '600',
  },
  searchResultCard: {
    padding: spacing.md,
    backgroundColor: '#f8fafc',
    borderRadius: borderRadius.sm,
    marginBottom: spacing.sm,
  },
  searchResultName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 4,
  },
  searchResultAddress: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
  },
  searchResultStatus: {
    fontSize: 12,
    color: '#0ea5e9',
    fontWeight: '600',
  },
  noResultsText: {
    fontSize: 16,
    color: '#94a3b8',
    textAlign: 'center',
    paddingVertical: spacing.md,
  },
});
