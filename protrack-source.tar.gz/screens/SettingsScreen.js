import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Modal,
  Image,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Haptics from '../utils/haptics';
import { useUser, ROLES } from '../contexts/UserContext';
import { useCompany } from '../contexts/CompanyContext';
import { apiRequest, getApiUrl } from '../utils/api';
import { colors, typography, spacing, borderRadius, shadows } from '../utils/theme';
import UserAvatar from '../components/UserAvatar';
import imageCompression from 'browser-image-compression';
import ConfirmModal from '../components/ConfirmModal';
import { useToast } from '../components/Toast';

const COMMON_TRADES = [
  'Carpentry', 'Drywall', 'Electrical', 'Flooring', 'Framing',
  'HVAC', 'Landscaping', 'Masonry', 'Painting', 'Plumbing',
  'Roofing', 'Tile'
];

export default function SettingsScreen({ navigation }) {
  const { user, token, logout, isAdmin } = useUser();
  const { settings: companySettings, updateSettings: updateCompanySettings, uploadLogo, fetchSettings: refetchCompanySettings } = useCompany();
  const toast = useToast();
  
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [showAddUser, setShowAddUser] = useState(false);
  const [invites, setInvites] = useState([]);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('user');
  const [editingUser, setEditingUser] = useState(null);
  const [newUserName, setNewUserName] = useState('');
  const [newUserUsername, setNewUserUsername] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState('user');
  const [newUserTrade, setNewUserTrade] = useState('');
  const [newUserNotifyPref, setNewUserNotifyPref] = useState('email');
  const [newUserNotifyTiming, setNewUserNotifyTiming] = useState('immediate');
  const [showTradePicker, setShowTradePicker] = useState(false);
  const [showCustomTradeInput, setShowCustomTradeInput] = useState(false);
  const [customTrade, setCustomTrade] = useState('');
  const [photoPreview, setPhotoPreview] = useState(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const fileInputRef = useRef(null);
  const [logoutConfirm, setLogoutConfirm] = useState(false);
  
    
  // Account settings state
  const [showAccountSettings, setShowAccountSettings] = useState(false);
  const [accountUsername, setAccountUsername] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingAccount, setSavingAccount] = useState(false);
  
  // Worker jobs overview
  const [workerJobs, setWorkerJobs] = useState([]);
  const [showWorkerOverview, setShowWorkerOverview] = useState(false);
  const [loadingWorkerJobs, setLoadingWorkerJobs] = useState(false);
  
  // Delete user confirmation
  const [deleteUserConfirm, setDeleteUserConfirm] = useState({ visible: false, user: null });
  
  // Email configuration state (multi-account)
  const [emailAccounts, setEmailAccounts] = useState([]);
  const [loadingEmailAccounts, setLoadingEmailAccounts] = useState(false);
  const [showEmailSetup, setShowEmailSetup] = useState(false);
  const [gmailAddress, setGmailAddress] = useState('');
  const [gmailAppPassword, setGmailAppPassword] = useState('');
  const [savingEmail, setSavingEmail] = useState(false);
  const [testingEmailId, setTestingEmailId] = useState(null);
  const [emailError, setEmailError] = useState(null);
  const [emailTroubleshooting, setEmailTroubleshooting] = useState([]);

  // Twilio SMS settings state
  const [twilioStatus, setTwilioStatus] = useState({ configured: false, phone: null, a2pApproved: false });
  const [loadingTwilio, setLoadingTwilio] = useState(false);
  const [togglingA2p, setTogglingA2p] = useState(false);
  const [sendingTestSms, setSendingTestSms] = useState(false);
  const [testSmsPhone, setTestSmsPhone] = useState('');
  const [showTestSmsModal, setShowTestSmsModal] = useState(false);

  // Company branding settings state
  const [showCompanySettings, setShowCompanySettings] = useState(false);
  const [companyName, setCompanyName] = useState('');
  const [companyPhone, setCompanyPhone] = useState('');
  const [companyEmail, setCompanyEmail] = useState('');
  const [companyAddress, setCompanyAddress] = useState('');
  const [savingCompany, setSavingCompany] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const companyLogoInputRef = useRef(null);

  useEffect(() => {
    if (companySettings) {
      setCompanyName(companySettings.company_name || '');
      setCompanyPhone(companySettings.contact_phone || '');
      setCompanyEmail(companySettings.contact_email || '');
      setCompanyAddress(companySettings.business_address || '');
    }
  }, [companySettings]);

  const handleSaveCompanySettings = async () => {
    setSavingCompany(true);
    try {
      const result = await updateCompanySettings({
        company_name: companyName,
        contact_phone: companyPhone,
        contact_email: companyEmail,
        business_address: companyAddress,
        setup_completed: true
      }, token);
      
      if (result.success) {
        toast.success('Company settings saved');
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        toast.error(result.error || 'Failed to save settings');
      }
    } catch (error) {
      toast.error('Failed to save company settings');
    } finally {
      setSavingCompany(false);
    }
  };

  const handleCompanyLogoUpload = async (event) => {
    const file = event.target?.files?.[0];
    if (!file) return;
    
    setUploadingLogo(true);
    try {
      const result = await uploadLogo(file, token);
      if (result.success) {
        toast.success('Logo uploaded successfully');
        refetchCompanySettings();
      } else {
        toast.error(result.error || 'Failed to upload logo');
      }
    } catch (error) {
      toast.error('Failed to upload logo');
    } finally {
      setUploadingLogo(false);
    }
  };

  const resetForm = () => {
    setNewUserName('');
    setNewUserUsername('');
    setNewUserPassword('');
    setNewUserPhone('');
    setNewUserEmail('');
    setNewUserRole('user');
    setNewUserTrade('');
    setNewUserNotifyPref('email');
    setNewUserNotifyTiming('immediate');
    setShowTradePicker(false);
    setShowCustomTradeInput(false);
    setCustomTrade('');
    setPhotoPreview(null);
    setEditingUser(null);
  };

  const loadTwilioStatus = async () => {
    if (!isAdmin()) return;
    setLoadingTwilio(true);
    try {
      const result = await apiRequest('/api/twilio/status', { headers: { Authorization: `Bearer ${token}` } });
      setTwilioStatus({
        configured: result.configured || false,
        phone: result.phone || null,
        a2pApproved: result.a2pApproved || false
      });
    } catch (error) {
      console.error('Failed to load Twilio status:', error);
    } finally {
      setLoadingTwilio(false);
    }
  };

  const toggleA2pApproval = async () => {
    setTogglingA2p(true);
    try {
      const result = await apiRequest('/api/twilio/a2p', {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ approved: !twilioStatus.a2pApproved })
      });
      if (result.success) {
        setTwilioStatus(prev => ({ ...prev, a2pApproved: result.a2pApproved }));
        toast.success(result.a2pApproved ? 'A2P registration marked as approved' : 'A2P registration marked as pending');
      }
    } catch (error) {
      toast.error('Failed to update A2P status');
    } finally {
      setTogglingA2p(false);
    }
  };

  const sendTestSms = async () => {
    if (!testSmsPhone.trim()) {
      toast.error('Please enter a phone number');
      return;
    }
    setSendingTestSms(true);
    try {
      const result = await apiRequest('/api/twilio/test', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ phone: testSmsPhone.trim() })
      });
      if (result.success) {
        toast.success(result.message || 'Test SMS sent!');
        setShowTestSmsModal(false);
        setTestSmsPhone('');
      } else {
        toast.error(result.error || 'Failed to send test SMS');
      }
    } catch (error) {
      toast.error('Failed to send test SMS');
    } finally {
      setSendingTestSms(false);
    }
  };

  useEffect(() => {
    if (token) {
      loadData();
      if (isAdmin()) {
        loadEmailAccounts();
        loadTwilioStatus();
      }
    }
  }, [token]);

  // Reload data when screen comes into focus (ensures fresh data)
  useFocusEffect(
    useCallback(() => {
      if (token) {
        loadData();
      }
    }, [token])
  );

  const loadData = async () => {
    try {
      setLoading(true);
      const usersRes = await apiRequest('/api/users', { headers: { Authorization: `Bearer ${token}` } });
      setUsers(usersRes.members || []);
      if (isAdmin()) {
        loadInvites();
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadInvites = async () => {
    try {
      const res = await apiRequest('/api/invites', { headers: { Authorization: `Bearer ${token}` } });
      setInvites(res.invites || []);
    } catch (error) {
      console.error('Failed to load invites:', error);
    }
  };

  const handleSendInvite = async () => {
    if (!inviteEmail.trim()) {
      toast.error('Please enter an email address');
      return;
    }
    try {
      await apiRequest('/api/invites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ email: inviteEmail.trim(), role: inviteRole }),
      });
      toast.success('Invite sent!');
      setShowInviteModal(false);
      setInviteEmail('');
      setInviteRole('user');
      loadInvites();
    } catch (error) {
      toast.error(error.message || 'Failed to send invite');
    }
  };

  const handleDeleteInvite = async (inviteId) => {
    try {
      await apiRequest(`/api/invites/${inviteId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Invite cancelled');
      loadInvites();
    } catch (error) {
      toast.error(error.message || 'Failed to cancel invite');
    }
  };
  
  const loadEmailAccounts = async () => {
    try {
      setLoadingEmailAccounts(true);
      const result = await apiRequest('/api/email-accounts', { 
        headers: { Authorization: `Bearer ${token}` } 
      });
      setEmailAccounts(result.accounts || []);
    } catch (error) {
      console.error('Failed to load email accounts:', error);
    } finally {
      setLoadingEmailAccounts(false);
    }
  };
  
  const addEmailAccount = async () => {
    if (!gmailAddress || !gmailAppPassword) {
      setEmailError('Please enter both Gmail address and app password');
      setEmailTroubleshooting([
        'Enter your full Gmail address (e.g., yourname@gmail.com)',
        'Enter the 16-character app password from Google'
      ]);
      return;
    }
    
    setSavingEmail(true);
    setEmailError(null);
    setEmailTroubleshooting([]);
    
    try {
      const result = await apiRequest('/api/email-accounts', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: gmailAddress,
          password: gmailAppPassword
        })
      });
      toast.success(result.message || 'Email connected!');
      setShowEmailSetup(false);
      setGmailAddress('');
      setGmailAppPassword('');
      loadEmailAccounts();
    } catch (error) {
      console.error('Failed to add email:', error);
      setEmailError(error.message || 'Failed to connect email');
      if (error.troubleshooting) {
        setEmailTroubleshooting(error.troubleshooting);
      } else {
        setEmailTroubleshooting([
          'Make sure 2-Factor Authentication is enabled on your Google account',
          'Generate a new app password at myaccount.google.com/apppasswords',
          'Copy the 16-character password exactly (no spaces)'
        ]);
      }
    } finally {
      setSavingEmail(false);
    }
  };
  
  const testEmailAccount = async (accountId) => {
    setTestingEmailId(accountId);
    try {
      const result = await apiRequest(`/api/email-accounts/${accountId}/test`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success(result.message || 'Test email sent!');
      loadEmailAccounts();
    } catch (error) {
      console.error('Failed to test email:', error);
      toast.error(error.message || 'Test failed');
      loadEmailAccounts();
    } finally {
      setTestingEmailId(null);
    }
  };
  
  const removeEmailAccount = async (accountId, email) => {
    try {
      await apiRequest(`/api/email-accounts/${accountId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success(`${email} removed`);
      loadEmailAccounts();
    } catch (error) {
      console.error('Failed to remove email:', error);
      toast.error('Failed to remove email');
    }
  };
  
  const setPrimaryEmail = async (accountId) => {
    try {
      const result = await apiRequest(`/api/email-accounts/${accountId}/primary`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` }
      });
      toast.success(result.message || 'Primary email updated');
      loadEmailAccounts();
    } catch (error) {
      console.error('Failed to set primary:', error);
      toast.error('Failed to update primary email');
    }
  };

  const loadWorkerJobs = async () => {
    setLoadingWorkerJobs(true);
    try {
      const result = await apiRequest('/api/admin/worker-jobs', { 
        headers: { Authorization: `Bearer ${token}` } 
      });
      setWorkerJobs(result.workers || []);
    } catch (error) {
      console.error('Failed to load worker jobs:', error);
      toast.error('Failed to load worker overview');
    } finally {
      setLoadingWorkerJobs(false);
    }
  };

  const handleShowWorkerOverview = () => {
    setShowWorkerOverview(true);
    loadWorkerJobs();
  };

  const selectTrade = (trade) => {
    if (trade === 'Other...') {
      setShowCustomTradeInput(true);
      setShowTradePicker(false);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    } else {
      setNewUserTrade(trade);
      setShowTradePicker(false);
      setShowCustomTradeInput(false);
      setCustomTrade('');
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const applyCustomTrade = () => {
    if (customTrade.trim()) {
      setNewUserTrade(customTrade.trim());
      setShowCustomTradeInput(false);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target?.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please choose an image file (JPG, PNG)');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error('Please choose a smaller image (max 10MB)');
      return;
    }

    setUploadingPhoto(true);
    try {
      const options = {
        maxSizeMB: 0.5,
        maxWidthOrHeight: 800,
        useWebWorker: true
      };
      const compressed = await imageCompression(file, options);

      const reader = new FileReader();
      reader.onload = (ev) => setPhotoPreview(ev.target.result);
      reader.readAsDataURL(compressed);

      if (editingUser) {
        const formData = new FormData();
        formData.append('photo', compressed, file.name);
        
        const response = await fetch(`/api/users/${editingUser.id}/photo`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` },
          body: formData
        });
        
        const result = await response.json();
        if (result.success) {
          setUsers(users.map(u => u.id === editingUser.id ? { ...u, profile_picture_url: result.url } : u));
          setEditingUser({ ...editingUser, profile_picture_url: result.url });
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        } else {
          throw new Error(result.error || 'Upload failed');
        }
      }
    } catch (error) {
      console.error('Photo upload error:', error);
      toast.error('Failed to upload photo. Please try again.');
      setPhotoPreview(null);
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleRemovePhoto = async () => {
    if (!editingUser) {
      setPhotoPreview(null);
      return;
    }

    try {
      const response = await fetch(`/api/users/${editingUser.id}/photo`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const result = await response.json();
      if (result.success) {
        setPhotoPreview(null);
        setUsers(users.map(u => u.id === editingUser.id ? { ...u, profile_picture_url: null } : u));
        setEditingUser({ ...editingUser, profile_picture_url: null });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      toast.error('Failed to remove photo');
    }
  };

  const handleAddUser = async () => {
    if (!newUserName.trim() || !newUserUsername.trim() || (!editingUser && !newUserPassword.trim())) {
      toast.error('Please fill in name, username, and password');
      return;
    }
    try {
      setSaving(true);
      
      const finalTrade = showCustomTradeInput && customTrade.trim() 
        ? customTrade.trim() 
        : newUserTrade;
      
      if (editingUser) {
        const result = await apiRequest(`/api/users/${editingUser.id}`, {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            name: newUserName.trim(),
            phone: newUserPhone.trim(),
            email: newUserEmail.trim(),
            role: newUserRole,
            trade: newUserRole === 'user' ? finalTrade : null,
            notify_preference: newUserNotifyPref,
            notification_preference: newUserNotifyTiming,
          }),
        });
        if (result.user) {
          await apiRequest(`/api/users/${editingUser.id}/notification-preference`, {
            method: 'PUT',
            headers: { Authorization: `Bearer ${token}` },
            body: JSON.stringify({ preference: newUserNotifyTiming }),
          });
        }
        setUsers(users.map(u => u.id === editingUser.id ? result.user : u));
      } else {
        const result = await apiRequest('/api/users', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            name: newUserName.trim(),
            username: newUserUsername.trim(),
            password: newUserPassword,
            phone: newUserPhone.trim(),
            email: newUserEmail.trim(),
            role: newUserRole,
            trade: newUserRole === 'user' ? finalTrade : null,
            notify_preference: newUserNotifyPref,
          }),
        });
        if (result.user) {
          await apiRequest(`/api/users/${result.user.id}/notification-preference`, {
            method: 'PUT',
            headers: { Authorization: `Bearer ${token}` },
            body: JSON.stringify({ preference: newUserNotifyTiming }),
          });
        }
        setUsers([...users, result.user]);
      }
      
      resetUserForm();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success(editingUser ? 'User updated' : 'User added');
    } catch (error) {
      toast.error(error.message || 'Failed to save user');
    } finally {
      setSaving(false);
    }
  };

  const resetUserForm = () => {
    setShowAddUser(false);
    setEditingUser(null);
    setNewUserName('');
    setNewUserUsername('');
    setNewUserPassword('');
    setNewUserPhone('');
    setNewUserEmail('');
    setNewUserRole('user');
    setNewUserTrade('');
    setNewUserNotifyPref('email');
    setNewUserNotifyTiming('immediate');
    setShowTradePicker(false);
    setShowCustomTradeInput(false);
    setCustomTrade('');
    setPhotoPreview(null);
  };

  const handleEditUser = (userToEdit) => {
    setEditingUser(userToEdit);
    setNewUserName(userToEdit.name || '');
    setNewUserUsername(userToEdit.username || '');
    setNewUserPhone(userToEdit.phone || '');
    setNewUserEmail(userToEdit.email || '');
    setNewUserRole(userToEdit.role || 'user');
    setNewUserTrade(userToEdit.trade || '');
    setNewUserNotifyPref(userToEdit.notify_preference || 'email');
    setNewUserNotifyTiming(userToEdit.notification_preference || 'immediate');
    setPhotoPreview(userToEdit.profile_picture_url || null);
    setShowAddUser(true);
  };

  const handleDeleteUser = (userToDelete) => {
    if (userToDelete.id === user?.id) {
      toast.error('You cannot delete your own account');
      return;
    }
    setDeleteUserConfirm({ visible: true, user: userToDelete });
  };

  const confirmDeleteUser = async () => {
    const userToDelete = deleteUserConfirm.user;
    if (!userToDelete) return;
    
    setDeleteUserConfirm({ visible: false, user: null });
    try {
      await apiRequest(`/api/users/${userToDelete.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(users.filter(u => u.id !== userToDelete.id));
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('User removed');
    } catch (error) {
      toast.error('Failed to remove user');
    }
  };

  const handleLogout = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setLogoutConfirm(true);
  };

  const confirmLogout = () => {
    setLogoutConfirm(false);
    logout();
  };

  const openAccountSettings = () => {
    setAccountUsername(user?.username || '');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setShowAccountSettings(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const saveAccountSettings = async () => {
    const usernameChanged = accountUsername.trim() && accountUsername.trim() !== user?.username;
    const passwordChanged = newPassword.length > 0;
    
    // Check if any changes were made
    if (!usernameChanged && !passwordChanged) {
      toast.error('No changes to save');
      return;
    }
    
    if (!currentPassword.trim()) {
      toast.error('Enter your current password to save changes');
      return;
    }

    // Validate new password if provided
    if (passwordChanged) {
      if (newPassword !== confirmPassword) {
        toast.error('New passwords do not match');
        return;
      }
      if (newPassword.length < 4) {
        toast.error('Password must be at least 4 characters');
        return;
      }
    }

    // Validate username if changed
    if (usernameChanged && accountUsername.trim().length < 3) {
      toast.error('Username must be at least 3 characters');
      return;
    }

    try {
      setSavingAccount(true);

      // Update username if changed
      if (usernameChanged) {
        const usernameRes = await apiRequest('/api/auth/change-username', {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({ 
            currentPassword, 
            newUsername: accountUsername.trim() 
          }),
        });
        if (!usernameRes.success) {
          throw new Error(usernameRes.error || 'Failed to update username');
        }
      }

      // Update password if provided
      if (passwordChanged) {
        const passwordRes = await apiRequest('/api/auth/change-password', {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({ currentPassword, newPassword }),
        });
        if (!passwordRes.success) {
          throw new Error(passwordRes.error || 'Failed to update password');
        }
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setShowAccountSettings(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      
      // If username changed, force logout so user logs in with new credentials
      if (usernameChanged) {
        toast.success('Username changed! Please log in with your new username.');
        setTimeout(() => logout(), 1500);
      } else {
        toast.success('Password changed successfully');
      }
    } catch (error) {
      toast.error(error.message || 'Failed to save settings');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setSavingAccount(false);
    }
  };

  const getRoleDisplay = (role) => {
    if (!role) return 'Not set';
    if (role === 'admin') return 'Administrator';
    return role.charAt(0).toUpperCase() + role.slice(1);
  };

  const getUserTradeDisplay = (member) => {
    if (member.role === 'admin') return 'Admin';
    if (!member.trade) return '(no trade)';
    return member.trade;
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={['bottom']}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView 
        style={styles.scrollView} 
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Account</Text>
            <TouchableOpacity 
              style={styles.addButton}
              onPress={openAccountSettings}
            >
              <Text style={styles.addButtonText}>Edit</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.card}>
            <View style={styles.profileRow}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>
                  {user?.name?.charAt(0)?.toUpperCase() || '?'}
                </Text>
              </View>
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>{user?.name || 'Unknown'}</Text>
                <Text style={styles.profileRole}>{getRoleDisplay(user?.role)}</Text>
                <Text style={styles.profileUsername}>Username: {user?.username || 'N/A'}</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Team Members</Text>
            <TouchableOpacity 
              style={styles.addButton}
              onPress={() => setShowAddUser(true)}
            >
              <Text style={styles.addButtonText}>+ Add</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.sectionSubtitle}>
            Manage users who can access the app
          </Text>
          
          <View style={styles.card}>
            {users.filter(u => u.id !== user?.id).length === 0 ? (
              <Text style={styles.emptyText}>No other team members</Text>
            ) : (
              users.filter(u => u.id !== user?.id).map((member, index) => (
                  <View key={member.id} style={[styles.listItem, index > 0 && styles.listItemBorder]}>
                    <UserAvatar user={member} size={56} />
                    <View style={[styles.userInfo, { marginLeft: spacing.md, flex: 1 }]}>
                      <Text style={styles.listItemText}>{member.name}</Text>
                      <Text style={styles.listItemSubtext}>
                        {getUserTradeDisplay(member)} • {member.username}
                      </Text>
                      {member.phone && (
                        <Text style={styles.phoneText}>📱 {member.phone}</Text>
                      )}
                    </View>
                    <View style={styles.actionButtons}>
                      <TouchableOpacity 
                        style={styles.editButton}
                        onPress={() => handleEditUser(member)}
                      >
                        <Text style={styles.editButtonText}>Edit</Text>
                      </TouchableOpacity>
                      <TouchableOpacity 
                        style={styles.deleteButton}
                        onPress={() => handleDeleteUser(member)}
                      >
                        <Text style={styles.deleteButtonText}>Remove</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
            )}
          </View>
        </View>

        {isAdmin() && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Team Invites</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => setShowInviteModal(true)}
              >
                <Text style={styles.addButtonText}>+ Invite</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.sectionSubtitle}>
              Send invite links for new team members to join your company
            </Text>
            <View style={styles.card}>
              {invites.filter(i => !i.accepted).length === 0 ? (
                <Text style={styles.emptyText}>No pending invites</Text>
              ) : (
                invites.filter(i => !i.accepted).map((invite, index) => (
                  <View key={invite.id} style={[styles.listItem, index > 0 && styles.listItemBorder]}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.listItemText}>{invite.email}</Text>
                      <Text style={styles.listItemSubtext}>
                        Role: {invite.role} | Expires: {new Date(invite.expires_at).toLocaleDateString()}
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => handleDeleteInvite(invite.id)}
                    >
                      <Text style={styles.deleteButtonText}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                ))
              )}
            </View>
          </View>
        )}

        {isAdmin() && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Company Branding</Text>
            <Text style={styles.sectionSubtitle}>
              Customize your company's branding and contact information
            </Text>
            
            <View style={styles.companySettingsCard}>
              {/* Logo Upload */}
              <View style={styles.companyLogoSection}>
                <Text style={styles.inputLabel}>Company Logo</Text>
                <View style={styles.companyLogoContainer}>
                  {companySettings?.logo_path ? (
                    <Image 
                      source={{ uri: `${getApiUrl()}${companySettings.logo_path}` }}
                      style={styles.companyLogoPreview}
                      resizeMode="contain"
                    />
                  ) : (
                    <View style={styles.companyLogoPlaceholder}>
                      <Text style={styles.companyLogoPlaceholderText}>📋</Text>
                      <Text style={styles.companyLogoPlaceholderLabel}>No logo</Text>
                    </View>
                  )}
                  <TouchableOpacity
                    style={styles.companyLogoUploadButton}
                    onPress={() => companyLogoInputRef.current?.click()}
                    disabled={uploadingLogo}
                  >
                    {uploadingLogo ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Text style={styles.companyLogoUploadButtonText}>
                        {companySettings?.logo_path ? 'Change Logo' : 'Upload Logo'}
                      </Text>
                    )}
                  </TouchableOpacity>
                  {Platform.OS === 'web' && (
                    <input
                      ref={companyLogoInputRef}
                      type="file"
                      accept="image/*"
                      style={{ display: 'none' }}
                      onChange={handleCompanyLogoUpload}
                    />
                  )}
                </View>
              </View>
              
              {/* Company Name */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Company Name</Text>
                <TextInput
                  style={styles.input}
                  value={companyName}
                  onChangeText={setCompanyName}
                  placeholder="Enter company name"
                  placeholderTextColor={colors.textTertiary}
                />
              </View>
              
              {/* Contact Phone */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Contact Phone</Text>
                <TextInput
                  style={styles.input}
                  value={companyPhone}
                  onChangeText={setCompanyPhone}
                  placeholder="555-123-4567"
                  placeholderTextColor={colors.textTertiary}
                  keyboardType="phone-pad"
                />
              </View>
              
              {/* Contact Email */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Contact Email</Text>
                <TextInput
                  style={styles.input}
                  value={companyEmail}
                  onChangeText={setCompanyEmail}
                  placeholder="info@company.com"
                  placeholderTextColor={colors.textTertiary}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
              
              {/* Business Address */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Business Address</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={companyAddress}
                  onChangeText={setCompanyAddress}
                  placeholder="123 Main Street, City, State ZIP"
                  placeholderTextColor={colors.textTertiary}
                  multiline
                  numberOfLines={2}
                />
              </View>
              
              
              {/* Save Button */}
              <TouchableOpacity
                style={[styles.saveButton, savingCompany && styles.buttonDisabled]}
                onPress={handleSaveCompanySettings}
                disabled={savingCompany}
              >
                {savingCompany ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.saveButtonText}>Save Company Settings</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          <Text style={styles.sectionSubtitle}>
            SMS and email notifications for @mentions
          </Text>
          {/* SMS Settings Card - Admin Only */}
          {isAdmin() && (
            <View style={styles.twilioSettingsCard}>
              <View style={styles.twilioSettingsHeader}>
                <Text style={styles.twilioSettingsTitle}>📱 SMS Notifications</Text>
                {loadingTwilio ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : twilioStatus.configured ? (
                  <View style={styles.twilioStatusBadgeConnected}>
                    <Text style={styles.twilioStatusTextConnected}>✓ Twilio Connected</Text>
                  </View>
                ) : (
                  <View style={styles.twilioStatusBadgeWarning}>
                    <Text style={styles.twilioStatusTextWarning}>⚠ Not Configured</Text>
                  </View>
                )}
              </View>
              
              {twilioStatus.configured && twilioStatus.phone && (
                <View style={styles.twilioPhoneRow}>
                  <Text style={styles.twilioPhoneLabel}>Sending from:</Text>
                  <Text style={styles.twilioPhoneNumber}>{twilioStatus.phone}</Text>
                </View>
              )}
              
              <View style={styles.twilioA2pRow}>
                <View style={styles.twilioA2pInfo}>
                  <Text style={styles.twilioA2pLabel}>A2P Registration Approved</Text>
                  <Text style={styles.twilioA2pHelpText}>
                    Turn on once your Twilio A2P 10DLC registration is approved for production SMS
                  </Text>
                </View>
                <TouchableOpacity
                  style={[styles.twilioToggle, twilioStatus.a2pApproved && styles.twilioToggleActive]}
                  onPress={toggleA2pApproval}
                  disabled={togglingA2p}
                >
                  {togglingA2p ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <View style={[styles.twilioToggleKnob, twilioStatus.a2pApproved && styles.twilioToggleKnobActive]} />
                  )}
                </TouchableOpacity>
              </View>
              
              <TouchableOpacity
                style={[styles.twilioTestButton, !twilioStatus.configured && styles.buttonDisabled]}
                onPress={() => setShowTestSmsModal(true)}
                disabled={!twilioStatus.configured}
              >
                <Text style={styles.twilioTestButtonText}>Send Test SMS</Text>
              </TouchableOpacity>
              
              {!twilioStatus.configured && (
                <Text style={styles.twilioHelpText}>
                  Add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER to your secrets to enable SMS.
                </Text>
              )}
            </View>
          )}

          <View style={styles.notificationInfoCard}>
            <View style={styles.notificationInfoRow}>
              <Text style={styles.notificationInfoIcon}>✉️</Text>
              <View style={styles.notificationInfoContent}>
                <Text style={styles.notificationInfoTitle}>Email Notifications</Text>
                <Text style={styles.notificationInfoText}>
                  Email notifications are sent when team members are @mentioned in notes or tasks.
                </Text>
              </View>
            </View>
            <View style={styles.notificationInfoRow}>
              <Text style={styles.notificationInfoIcon}>🔄</Text>
              <View style={styles.notificationInfoContent}>
                <Text style={styles.notificationInfoTitle}>Smart Deduplication</Text>
                <Text style={styles.notificationInfoText}>
                  Same task won't be sent twice within 24 hours.
                </Text>
              </View>
            </View>
          </View>
          
          {/* Email Configuration Section - Admin Only */}
          {isAdmin() && (
            <View style={styles.emailConfigCard}>
              <View style={styles.emailConfigHeader}>
                <Text style={styles.emailConfigTitle}>Email Accounts</Text>
                {loadingEmailAccounts ? (
                  <ActivityIndicator size="small" color="#1c3b59" />
                ) : emailAccounts.length > 0 ? (
                  <View style={styles.emailStatusBadge}>
                    <Text style={styles.emailStatusText}>{emailAccounts.length} connected</Text>
                  </View>
                ) : (
                  <View style={[styles.emailStatusBadge, styles.emailStatusWarning]}>
                    <Text style={[styles.emailStatusText, styles.emailStatusTextWarning]}>None configured</Text>
                  </View>
                )}
              </View>
              
              {/* Connected Email Accounts */}
              {emailAccounts.map((account) => (
                <View key={account.id} style={styles.emailAccountRow}>
                  <View style={styles.emailAccountInfo}>
                    <View style={styles.emailAccountHeader}>
                      <Text style={styles.emailAccountAddress}>{account.email}</Text>
                      {account.is_primary && (
                        <View style={styles.primaryBadge}>
                          <Text style={styles.primaryBadgeText}>Primary</Text>
                        </View>
                      )}
                    </View>
                    <View style={styles.emailAccountStatus}>
                      {account.status === 'active' ? (
                        <Text style={styles.emailStatusActive}>✓ Active</Text>
                      ) : (
                        <Text style={styles.emailStatusError}>⚠ {account.last_error || 'Error'}</Text>
                      )}
                    </View>
                  </View>
                  <View style={styles.emailAccountActions}>
                    <TouchableOpacity 
                      style={styles.emailAccountButton}
                      onPress={() => testEmailAccount(account.id)}
                      disabled={testingEmailId === account.id}
                    >
                      {testingEmailId === account.id ? (
                        <ActivityIndicator size="small" color="#1c3b59" />
                      ) : (
                        <Text style={styles.emailAccountButtonText}>Test</Text>
                      )}
                    </TouchableOpacity>
                    {!account.is_primary && emailAccounts.length > 1 && (
                      <TouchableOpacity 
                        style={styles.emailAccountButton}
                        onPress={() => setPrimaryEmail(account.id)}
                      >
                        <Text style={styles.emailAccountButtonText}>Set Primary</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity 
                      style={styles.emailAccountButtonRemove}
                      onPress={() => removeEmailAccount(account.id, account.email)}
                    >
                      <Text style={styles.emailAccountButtonTextRemove}>Remove</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
              
              {/* Add Email Form */}
              {showEmailSetup ? (
                <View style={styles.emailForm}>
                  {emailError && (
                    <View style={styles.emailErrorBox}>
                      <Text style={styles.emailErrorTitle}>{emailError}</Text>
                      {emailTroubleshooting.length > 0 && (
                        <View style={styles.emailTroubleshootingList}>
                          {emailTroubleshooting.map((step, idx) => (
                            <Text key={idx} style={step === '' ? styles.emailTroubleshootingSpacer : styles.emailTroubleshootingStep}>
                              {step}
                            </Text>
                          ))}
                        </View>
                      )}
                    </View>
                  )}
                  
                  <Text style={styles.emailFormLabel}>Gmail Address</Text>
                  <TextInput
                    style={styles.emailFormInput}
                    placeholder="your@gmail.com"
                    value={gmailAddress}
                    onChangeText={setGmailAddress}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                  <Text style={styles.emailFormLabel}>App Password</Text>
                  <TextInput
                    style={styles.emailFormInput}
                    placeholder="xxxx xxxx xxxx xxxx"
                    value={gmailAppPassword}
                    onChangeText={setGmailAppPassword}
                    secureTextEntry
                  />
                  <View style={styles.emailFormButtons}>
                    <TouchableOpacity 
                      style={[styles.emailFormButton, styles.emailFormButtonSave]}
                      onPress={addEmailAccount}
                      disabled={savingEmail}
                    >
                      {savingEmail ? (
                        <ActivityIndicator size="small" color="#fff" />
                      ) : (
                        <Text style={styles.emailFormButtonText}>Connect</Text>
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.emailFormButton, styles.emailFormButtonCancel]}
                      onPress={() => {
                        setShowEmailSetup(false);
                        setGmailAddress('');
                        setGmailAppPassword('');
                        setEmailError(null);
                        setEmailTroubleshooting([]);
                      }}
                    >
                      <Text style={styles.emailFormButtonTextCancel}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <View style={styles.addEmailSection}>
                  {emailAccounts.length === 0 && (
                    <>
                      <Text style={styles.emailConfigInstructions}>
                        Connect a Gmail account to send email notifications:
                      </Text>
                      <View style={styles.emailSteps}>
                        <Text style={styles.emailStep}>1. Enter your Gmail address</Text>
                        <Text style={styles.emailStep}>2. Go to myaccount.google.com/apppasswords</Text>
                        <Text style={styles.emailStep}>3. Generate an app password</Text>
                        <Text style={styles.emailStep}>4. Paste it here</Text>
                      </View>
                    </>
                  )}
                  <TouchableOpacity 
                    style={styles.emailSetupButton}
                    onPress={() => {
                      setShowEmailSetup(true);
                      setEmailError(null);
                      setEmailTroubleshooting([]);
                    }}
                  >
                    <Text style={styles.emailSetupButtonText}>
                      {emailAccounts.length > 0 ? '+ Add Another Email' : 'Add Email Account'}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
        </View>

        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Text style={styles.logoutButtonText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      <Modal visible={showAccountSettings} animationType="slide" transparent onRequestClose={() => setShowAccountSettings(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowAccountSettings(false)}>
          <ScrollView contentContainerStyle={styles.modalScrollContent} onStartShouldSetResponder={() => true}>
            <TouchableOpacity style={styles.modalContent} activeOpacity={1} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.modalTitle}>Account Settings</Text>
              
              <Text style={styles.inputLabel}>Username</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Enter username"
                placeholderTextColor={colors.textTertiary}
                value={accountUsername}
                onChangeText={setAccountUsername}
                autoCapitalize="none"
              />
              
              <Text style={[styles.inputLabel, { marginTop: spacing.lg }]}>Change Password</Text>
              <Text style={styles.sectionSubtitle}>Leave blank to keep current password</Text>
              
              <Text style={[styles.inputLabel, { marginTop: spacing.md }]}>New Password</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Enter new password"
                placeholderTextColor={colors.textTertiary}
                value={newPassword}
                onChangeText={setNewPassword}
                secureTextEntry
              />
              
              <Text style={styles.inputLabel}>Confirm New Password</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Confirm new password"
                placeholderTextColor={colors.textTertiary}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry
              />
              
              <Text style={[styles.inputLabel, { marginTop: spacing.lg }]}>Current Password (required)</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Enter current password to save"
                placeholderTextColor={colors.textTertiary}
                value={currentPassword}
                onChangeText={setCurrentPassword}
                secureTextEntry
              />
              
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => setShowAccountSettings(false)}
                  disabled={savingAccount}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.saveButton, savingAccount && styles.saveButtonDisabled]}
                  onPress={saveAccountSettings}
                  disabled={savingAccount}
                >
                  {savingAccount ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={styles.saveButtonText}>Save Changes</Text>
                  )}
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showInviteModal} animationType="slide" transparent onRequestClose={() => setShowInviteModal(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowInviteModal(false)}>
          <TouchableOpacity style={styles.modalContent} activeOpacity={1} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Invite Team Member</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email Address</Text>
              <TextInput
                style={styles.textInput}
                placeholder="name@company.com"
                placeholderTextColor={colors.textTertiary}
                value={inviteEmail}
                onChangeText={setInviteEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Role</Text>
              <View style={styles.roleRow}>
                {['user', 'admin'].map(r => (
                  <TouchableOpacity
                    key={r}
                    style={[styles.roleChip, inviteRole === r && styles.roleChipActive]}
                    onPress={() => setInviteRole(r)}
                  >
                    <Text style={[styles.roleChipText, inviteRole === r && styles.roleChipTextActive]}>
                      {r.charAt(0).toUpperCase() + r.slice(1)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setShowInviteModal(false)}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={handleSendInvite}>
                <Text style={styles.saveButtonText}>Send Invite</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showAddUser} animationType="slide" transparent onRequestClose={() => { setShowAddUser(false); resetForm(); }}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => { setShowAddUser(false); resetForm(); }}>
          <ScrollView contentContainerStyle={styles.modalScrollContent} onStartShouldSetResponder={() => true}>
            <TouchableOpacity style={styles.modalContent} activeOpacity={1} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.modalTitle}>
                {editingUser ? 'Edit Team Member' : 'Add Team Member'}
              </Text>

              {Platform.OS === 'web' && (
                <View style={styles.photoSection}>
                  <Text style={styles.inputLabel}>Profile Picture</Text>
                  <View style={styles.photoRow}>
                    <View style={styles.photoPreviewContainer}>
                      {photoPreview ? (
                        <Image
                          source={{ uri: photoPreview }}
                          style={styles.photoPreview}
                        />
                      ) : (
                        <UserAvatar 
                          user={{ name: newUserName || '?', trade: newUserTrade }}
                          size={120}
                        />
                      )}
                      {uploadingPhoto && (
                        <View style={styles.photoLoadingOverlay}>
                          <ActivityIndicator size="small" color="#fff" />
                        </View>
                      )}
                    </View>
                    <View style={styles.photoButtons}>
                      <input
                        type="file"
                        accept="image/*"
                        capture="user"
                        onChange={handlePhotoUpload}
                        style={{ display: 'none' }}
                        ref={fileInputRef}
                        id="profile-pic-input"
                      />
                      <TouchableOpacity
                        style={styles.uploadButton}
                        onPress={() => fileInputRef.current?.click()}
                        disabled={uploadingPhoto || !editingUser}
                      >
                        <Text style={styles.uploadButtonText}>
                          {uploadingPhoto ? 'Uploading...' : 'Upload Photo'}
                        </Text>
                      </TouchableOpacity>
                      {(photoPreview || editingUser?.profile_picture_url) && (
                        <TouchableOpacity
                          style={styles.removePhotoButton}
                          onPress={handleRemovePhoto}
                          disabled={uploadingPhoto}
                        >
                          <Text style={styles.removePhotoButtonText}>Remove</Text>
                        </TouchableOpacity>
                      )}
                      {!editingUser && (
                        <Text style={styles.photoHint}>
                          Save member first, then add photo
                        </Text>
                      )}
                    </View>
                  </View>
                </View>
              )}
              
              <Text style={styles.inputLabel}>Full Name</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Enter full name"
                placeholderTextColor={colors.textTertiary}
                value={newUserName}
                onChangeText={setNewUserName}
                autoFocus
              />
              
              {!editingUser && (
                <>
                  <Text style={styles.inputLabel}>Username</Text>
                  <TextInput
                    style={styles.modalInput}
                    placeholder="For login"
                    placeholderTextColor={colors.textTertiary}
                    value={newUserUsername}
                    onChangeText={setNewUserUsername}
                    autoCapitalize="none"
                  />
                  
                  <Text style={styles.inputLabel}>Password</Text>
                  <TextInput
                    style={styles.modalInput}
                    placeholder="Create password"
                    placeholderTextColor={colors.textTertiary}
                    value={newUserPassword}
                    onChangeText={setNewUserPassword}
                    secureTextEntry
                  />
                </>
              )}
              
              <Text style={styles.inputLabel}>Phone</Text>
              <View style={styles.phoneInputRow}>
                <TextInput
                  style={[styles.modalInput, { flex: 1, marginBottom: 0 }]}
                  placeholder="For SMS notifications (optional)"
                  placeholderTextColor={colors.textTertiary}
                  value={newUserPhone}
                  onChangeText={setNewUserPhone}
                  keyboardType="phone-pad"
                />
              </View>

              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="Email address (optional)"
                placeholderTextColor={colors.textTertiary}
                value={newUserEmail}
                onChangeText={setNewUserEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <Text style={[styles.inputLabel, { marginTop: spacing.md }]}>Notification Preference</Text>
              <View style={styles.roleSelector}>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyPref === 'email' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyPref('email')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyPref === 'email' && styles.roleOptionTextActive]}>
                    Email Only
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyPref === 'sms' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyPref('sms')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyPref === 'sms' && styles.roleOptionTextActive]}>
                    SMS Only
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyPref === 'both' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyPref('both')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyPref === 'both' && styles.roleOptionTextActive]}>
                    Both
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyPref === 'none' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyPref('none')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyPref === 'none' && styles.roleOptionTextActive]}>
                    None
                  </Text>
                </TouchableOpacity>
              </View>

              <Text style={[styles.inputLabel, { marginTop: spacing.md }]}>Notification Timing</Text>
              <View style={styles.roleSelector}>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyTiming === 'immediate' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyTiming('immediate')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyTiming === 'immediate' && styles.roleOptionTextActive]}>
                    Immediate
                  </Text>
                  <Text style={styles.roleDescription}>Send right away</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyTiming === 'daily_digest' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyTiming('daily_digest')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyTiming === 'daily_digest' && styles.roleOptionTextActive]}>
                    Daily Digest
                  </Text>
                  <Text style={styles.roleDescription}>One message at 8 AM</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserNotifyTiming === 'disabled' && styles.roleOptionActive]}
                  onPress={() => setNewUserNotifyTiming('disabled')}
                >
                  <Text style={[styles.roleOptionText, newUserNotifyTiming === 'disabled' && styles.roleOptionTextActive]}>
                    Disabled
                  </Text>
                  <Text style={styles.roleDescription}>No notifications</Text>
                </TouchableOpacity>
              </View>

              <Text style={[styles.inputLabel, { marginTop: spacing.md }]}>Role</Text>
              <View style={styles.roleSelector}>
                <TouchableOpacity
                  style={[styles.roleOption, newUserRole === 'user' && styles.roleOptionActive]}
                  onPress={() => setNewUserRole('user')}
                >
                  <Text style={styles.roleIcon}>👷</Text>
                  <Text style={[styles.roleOptionText, newUserRole === 'user' && styles.roleOptionTextActive]}>
                    Trade Worker
                  </Text>
                  <Text style={styles.roleDescription}>Can view assigned tasks</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.roleOption, newUserRole === 'admin' && styles.roleOptionActive]}
                  onPress={() => setNewUserRole('admin')}
                >
                  <Text style={styles.roleIcon}>👔</Text>
                  <Text style={[styles.roleOptionText, newUserRole === 'admin' && styles.roleOptionTextActive]}>
                    Admin
                  </Text>
                  <Text style={styles.roleDescription}>Full access to all jobs</Text>
                </TouchableOpacity>
              </View>

              {newUserRole === 'user' && (
                <>
                  <Text style={[styles.inputLabel, { marginTop: spacing.lg }]}>Trade</Text>
                  <Text style={styles.tradeHint}>Select this person's primary trade</Text>
                  
                  <TouchableOpacity 
                    style={styles.tradePickerButton}
                    onPress={() => setShowTradePicker(!showTradePicker)}
                  >
                    <Text style={[
                      styles.tradePickerButtonText,
                      !newUserTrade && styles.tradePickerPlaceholder
                    ]}>
                      {newUserTrade || 'Select a trade...'}
                    </Text>
                    <Text style={styles.tradePickerArrow}>{showTradePicker ? '▲' : '▼'}</Text>
                  </TouchableOpacity>

                  {showTradePicker && (
                    <View style={styles.tradePickerDropdown}>
                      <ScrollView style={styles.tradePickerScrollView} nestedScrollEnabled={true}>
                        {COMMON_TRADES.map(trade => (
                          <TouchableOpacity
                            key={trade}
                            style={[
                              styles.tradePickerOption,
                              newUserTrade === trade && styles.tradePickerOptionSelected
                            ]}
                            onPress={() => selectTrade(trade)}
                          >
                            <Text style={[
                              styles.tradePickerOptionText,
                              newUserTrade === trade && styles.tradePickerOptionTextSelected
                            ]}>
                              {trade}
                            </Text>
                            {newUserTrade === trade && (
                              <Text style={styles.tradeCheckmark}>✓</Text>
                            )}
                          </TouchableOpacity>
                        ))}
                        <TouchableOpacity
                          style={[styles.tradePickerOption, styles.tradePickerOtherOption]}
                          onPress={() => selectTrade('Other...')}
                        >
                          <Text style={styles.tradePickerOptionText}>Other...</Text>
                        </TouchableOpacity>
                      </ScrollView>
                    </View>
                  )}

                  {showCustomTradeInput && (
                    <View style={styles.customTradeContainer}>
                      <TextInput
                        style={styles.customTradeInput}
                        placeholder="Enter custom trade..."
                        placeholderTextColor={colors.textTertiary}
                        value={customTrade}
                        onChangeText={setCustomTrade}
                        autoFocus
                      />
                      <View style={styles.customTradeButtons}>
                        <TouchableOpacity
                          style={styles.customTradeCancel}
                          onPress={() => {
                            setShowCustomTradeInput(false);
                            setCustomTrade('');
                          }}
                        >
                          <Text style={styles.customTradeCancelText}>Cancel</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[styles.customTradeApply, !customTrade.trim() && styles.customTradeApplyDisabled]}
                          onPress={applyCustomTrade}
                          disabled={!customTrade.trim()}
                        >
                          <Text style={styles.customTradeApplyText}>Apply</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}
                </>
              )}

              <View style={styles.modalButtonsStacked}>
                <TouchableOpacity 
                  style={[styles.modalSaveButtonFull, saving && styles.modalSaveButtonDisabled]}
                  onPress={handleAddUser}
                  disabled={saving}
                >
                  {saving ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={styles.modalSaveText}>
                      {editingUser ? 'Save Changes' : 'Add Team Member'}
                    </Text>
                  )}
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.modalCancelButtonFull}
                  onPress={resetUserForm}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </TouchableOpacity>
      </Modal>

      {/* Test SMS Modal */}
      <Modal visible={showTestSmsModal} animationType="fade" transparent onRequestClose={() => setShowTestSmsModal(false)}>
        <TouchableOpacity 
          style={styles.modalOverlay} 
          activeOpacity={1} 
          onPress={() => setShowTestSmsModal(false)}
        >
          <TouchableOpacity activeOpacity={1} style={styles.testSmsModalContent}>
            <Text style={styles.testSmsModalTitle}>Send Test SMS</Text>
            <Text style={styles.testSmsModalSubtitle}>
              Enter a phone number to receive a test message
            </Text>
            <TextInput
              style={styles.testSmsInput}
              placeholder="Phone number (e.g., 205-555-1234)"
              placeholderTextColor={colors.textTertiary}
              value={testSmsPhone}
              onChangeText={setTestSmsPhone}
              keyboardType="phone-pad"
              autoFocus
            />
            <View style={styles.testSmsModalButtons}>
              <TouchableOpacity
                style={styles.testSmsCancelButton}
                onPress={() => { setShowTestSmsModal(false); setTestSmsPhone(''); }}
              >
                <Text style={styles.testSmsCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.testSmsSendButton, sendingTestSms && styles.buttonDisabled]}
                onPress={sendTestSms}
                disabled={sendingTestSms}
              >
                {sendingTestSms ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.testSmsSendButtonText}>Send Test</Text>
                )}
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <ConfirmModal
        visible={logoutConfirm}
        title="Sign Out"
        message="Are you sure you want to sign out?"
        confirmText="Sign Out"
        cancelText="Cancel"
        confirmStyle="danger"
        onConfirm={confirmLogout}
        onCancel={() => setLogoutConfirm(false)}
      />

      <ConfirmModal
        visible={deleteUserConfirm.visible}
        title="Remove Team Member"
        message={`Are you sure you want to remove "${deleteUserConfirm.user?.name}"?`}
        confirmText="Remove"
        cancelText="Cancel"
        confirmStyle="danger"
        onConfirm={confirmDeleteUser}
        onCancel={() => setDeleteUserConfirm({ visible: false, user: null })}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  sectionTitle: {
    ...typography.title3,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  sectionSubtitle: {
    ...typography.subhead,
    color: colors.textTertiary,
    marginBottom: spacing.md,
  },
  addButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  addButtonText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '600',
  },
  card: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.small,
  },
  profileRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  avatarText: {
    ...typography.title2,
    color: '#fff',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    ...typography.headline,
    color: colors.text,
  },
  profileRole: {
    ...typography.subhead,
    color: colors.textSecondary,
    marginTop: 2,
  },
  profileUsername: {
    ...typography.footnote,
    color: colors.textTertiary,
    marginTop: 4,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  listItemBorder: {
    borderTopWidth: 1,
    borderTopColor: colors.borderLight,
  },
  listItemText: {
    ...typography.body,
    color: colors.text,
    flex: 1,
  },
  listItemSubtext: {
    ...typography.footnote,
    color: colors.textTertiary,
  },
  userAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  userAvatarText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '600',
  },
  userInfo: {
    flex: 1,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  editButton: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  editButtonText: {
    ...typography.footnote,
    color: colors.primary,
  },
  deleteButton: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  deleteButtonText: {
    ...typography.footnote,
    color: colors.danger,
  },
  emptyText: {
    ...typography.body,
    color: colors.textTertiary,
    textAlign: 'center',
    paddingVertical: spacing.lg,
  },
  logoutButton: {
    backgroundColor: colors.danger,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  logoutButtonText: {
    ...typography.headline,
    color: '#fff',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalScrollContent: {
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.backgroundSecondary,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    padding: spacing.lg,
    maxHeight: '90%',
  },
  modalTitle: {
    ...typography.title2,
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  inputLabel: {
    ...typography.subhead,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  modalInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    ...typography.body,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  roleSelector: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  roleOption: {
    flex: 1,
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.borderLight,
  },
  roleOptionActive: {
    borderColor: colors.primary,
    backgroundColor: `${colors.primary}10`,
  },
  roleIcon: {
    fontSize: 24,
    marginBottom: spacing.xs,
  },
  roleOptionText: {
    ...typography.subhead,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  roleOptionTextActive: {
    color: colors.primary,
  },
  roleDescription: {
    ...typography.caption,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 2,
  },
  roleTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
    marginBottom: spacing.md,
  },
  roleTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    paddingLeft: spacing.md,
    paddingRight: spacing.xs,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.lg,
  },
  roleTagText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '500',
  },
  removeTagButton: {
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: spacing.xs,
  },
  removeTagText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
  },
  customRoleRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  customRoleInput: {
    flex: 1,
    marginBottom: 0,
  },
  addRoleButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addRoleButtonText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '600',
  },
  commonTradesLabel: {
    ...typography.footnote,
    color: colors.textTertiary,
    marginBottom: spacing.sm,
  },
  commonTradesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
    marginBottom: spacing.lg,
  },
  commonTradeButton: {
    backgroundColor: colors.background,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.borderLight,
    minHeight: 48,
    justifyContent: 'center',
  },
  commonTradeButtonSelected: {
    backgroundColor: `${colors.primary}20`,
    borderColor: colors.primary,
  },
  commonTradeButtonText: {
    ...typography.subhead,
    color: colors.textSecondary,
  },
  commonTradeButtonTextSelected: {
    color: colors.primary,
    fontWeight: '600',
  },
  modalButtonsStacked: {
    marginTop: spacing.lg,
    gap: spacing.sm,
  },
  modalSaveButtonFull: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  modalSaveButtonDisabled: {
    opacity: 0.5,
  },
  modalSaveText: {
    ...typography.headline,
    color: '#fff',
  },
  modalCancelButtonFull: {
    backgroundColor: colors.background,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  modalCancelText: {
    ...typography.headline,
    color: colors.textSecondary,
  },
  tradeHint: {
    ...typography.footnote,
    color: colors.textTertiary,
    marginBottom: spacing.sm,
  },
  tradePickerButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    minHeight: 52,
  },
  tradePickerButtonText: {
    ...typography.body,
    color: colors.text,
  },
  tradePickerPlaceholder: {
    color: colors.textTertiary,
  },
  tradePickerArrow: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  tradePickerDropdown: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderRadius: borderRadius.md,
    marginTop: spacing.xs,
    marginBottom: spacing.md,
    maxHeight: 250,
    overflow: 'hidden',
  },
  tradePickerScrollView: {
    maxHeight: 250,
  },
  tradePickerOtherOption: {
    borderBottomWidth: 0,
    backgroundColor: colors.surface,
  },
  tradePickerOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    minHeight: 48,
  },
  tradePickerOptionSelected: {
    backgroundColor: `${colors.primary}15`,
  },
  tradePickerOptionText: {
    ...typography.body,
    color: colors.text,
  },
  tradePickerOptionTextSelected: {
    color: colors.primary,
    fontWeight: '600',
  },
  tradeCheckmark: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: 'bold',
  },
  customTradeContainer: {
    marginTop: spacing.sm,
    marginBottom: spacing.md,
  },
  customTradeInput: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    ...typography.body,
    color: colors.text,
    minHeight: 48,
  },
  customTradeButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  customTradeCancel: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  customTradeCancelText: {
    ...typography.body,
    color: colors.textSecondary,
  },
  customTradeApply: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
  },
  customTradeApplyDisabled: {
    opacity: 0.5,
  },
  customTradeApplyText: {
    ...typography.body,
    color: '#fff',
    fontWeight: '600',
  },
  photoSection: {
    marginBottom: spacing.lg,
  },
  photoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
  },
  photoPreviewContainer: {
    position: 'relative',
  },
  photoPreview: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  photoLoadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoButtons: {
    flex: 1,
    gap: spacing.sm,
  },
  uploadButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    minHeight: 44,
    justifyContent: 'center',
  },
  uploadButtonText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '600',
  },
  removePhotoButton: {
    backgroundColor: colors.background,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.danger,
  },
  removePhotoButtonText: {
    ...typography.subhead,
    color: colors.danger,
  },
  photoHint: {
    ...typography.caption,
    color: colors.textTertiary,
    fontStyle: 'italic',
  },
  
  // Overview button
  overviewButton: {
    backgroundColor: colors.backgroundTertiary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  overviewButtonText: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.text,
  },
  
  // Worker Overview Modal Styles
  workerOverlayModal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  workerOverviewContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: spacing.lg,
    maxHeight: '85%',
  },
  workerOverviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
  },
  workerOverviewTitle: {
    ...typography.title2,
    color: colors.text,
  },
  workerOverviewClose: {
    fontSize: 24,
    color: colors.textSecondary,
    padding: spacing.sm,
  },
  workerOverviewSubtitle: {
    ...typography.caption1,
    color: colors.textSecondary,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.xs,
    marginBottom: spacing.lg,
  },
  workerOverviewLoading: {
    padding: spacing.xl,
    alignItems: 'center',
  },
  workerOverviewLoadingText: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
  workerOverviewList: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xl,
  },
  workerOverviewEmpty: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    padding: spacing.xl,
  },
  workerCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  workerCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  workerCardName: {
    ...typography.headline,
    fontWeight: '700',
    color: colors.text,
  },
  workerCardTrade: {
    ...typography.caption1,
    color: colors.primary,
    backgroundColor: colors.primaryLight,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
  },
  workerNoJobs: {
    ...typography.caption1,
    color: colors.textTertiary,
    fontStyle: 'italic',
  },
  workerJobsList: {
    gap: spacing.sm,
  },
  workerJobItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.background,
    padding: spacing.sm,
    borderRadius: borderRadius.md,
    gap: spacing.sm,
  },
  workerJobItemUrgent: {
    backgroundColor: '#fef2f2',
    borderLeftWidth: 3,
    borderLeftColor: '#ef4444',
  },
  workerJobUrgent: {
    fontSize: 16,
  },
  workerJobInfo: {
    flex: 1,
  },
  workerJobName: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.text,
  },
  workerJobAddress: {
    ...typography.caption1,
    color: colors.textSecondary,
  },
  workerJobStatus: {
    ...typography.caption1,
    color: colors.textTertiary,
    textTransform: 'capitalize',
  },
  comingSoonCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.xl,
    alignItems: 'center',
    ...shadows.small,
  },
  comingSoonIcon: {
    fontSize: 48,
    marginBottom: spacing.md,
  },
  comingSoonTitle: {
    ...typography.headline,
    color: colors.text,
    fontWeight: '600',
    marginBottom: spacing.xs,
  },
  comingSoonText: {
    ...typography.body,
    color: colors.textSecondary,
  },
  phoneInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  phoneText: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  notificationInfoCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.small,
  },
  notificationInfoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.md,
  },
  notificationInfoIcon: {
    fontSize: 24,
    marginRight: spacing.md,
    marginTop: 2,
  },
  notificationInfoContent: {
    flex: 1,
  },
  notificationInfoTitle: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.xs,
  },
  notificationInfoText: {
    ...typography.caption1,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  emailConfigCard: {
    backgroundColor: '#fff',
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginTop: spacing.lg,
    borderWidth: 1,
    borderColor: colors.borderLight,
    ...shadows.small,
  },
  emailConfigHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  emailConfigTitle: {
    ...typography.headline,
    fontWeight: '600',
    color: colors.text,
  },
  emailStatusBadge: {
    backgroundColor: '#dcfce7',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
  },
  emailStatusWarning: {
    backgroundColor: '#fef3c7',
  },
  emailStatusText: {
    ...typography.caption1,
    color: '#166534',
    fontWeight: '600',
  },
  emailStatusTextWarning: {
    color: '#92400e',
  },
  emailConfigInfo: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  emailButtonRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  emailButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    minWidth: 80,
    alignItems: 'center',
  },
  emailButtonTest: {
    backgroundColor: colors.primary,
  },
  emailButtonUpdate: {
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: colors.border,
  },
  emailButtonDisconnect: {
    backgroundColor: '#fef2f2',
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  emailButtonText: {
    ...typography.footnote,
    color: '#fff',
    fontWeight: '600',
  },
  emailButtonTextSecondary: {
    ...typography.footnote,
    color: colors.text,
    fontWeight: '600',
  },
  emailButtonTextDanger: {
    ...typography.footnote,
    color: '#dc2626',
    fontWeight: '600',
  },
  emailConfigInstructions: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  emailSteps: {
    marginBottom: spacing.md,
  },
  emailStep: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    paddingLeft: spacing.sm,
  },
  emailSetupButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignSelf: 'flex-start',
  },
  emailSetupButtonText: {
    ...typography.subhead,
    color: '#fff',
    fontWeight: '600',
  },
  emailForm: {
    marginTop: spacing.sm,
  },
  emailFormLabel: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    fontWeight: '500',
  },
  emailFormInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    padding: spacing.sm,
    marginBottom: spacing.md,
    ...typography.body,
    backgroundColor: '#fff',
  },
  emailFormButtons: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  emailFormButton: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    minWidth: 80,
    alignItems: 'center',
  },
  emailFormButtonSave: {
    backgroundColor: colors.primary,
  },
  emailFormButtonCancel: {
    backgroundColor: '#f3f4f6',
    borderWidth: 1,
    borderColor: colors.border,
  },
  emailFormButtonText: {
    ...typography.footnote,
    color: '#fff',
    fontWeight: '600',
  },
  emailFormButtonTextCancel: {
    ...typography.footnote,
    color: colors.text,
    fontWeight: '600',
  },
  emailAccountRow: {
    backgroundColor: '#f8f9fa',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  emailAccountInfo: {
    marginBottom: spacing.sm,
  },
  emailAccountHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.xs,
  },
  emailAccountAddress: {
    ...typography.subhead,
    fontWeight: '600',
    color: colors.text,
  },
  primaryBadge: {
    backgroundColor: '#dbeafe',
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
  },
  primaryBadgeText: {
    ...typography.caption2,
    color: '#1e40af',
    fontWeight: '600',
  },
  emailAccountStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  emailStatusActive: {
    ...typography.caption1,
    color: '#166534',
    fontWeight: '500',
  },
  emailStatusError: {
    ...typography.caption1,
    color: '#dc2626',
    fontWeight: '500',
  },
  emailAccountActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  emailAccountButton: {
    backgroundColor: '#fff',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  emailAccountButtonText: {
    ...typography.caption1,
    color: colors.primary,
    fontWeight: '600',
  },
  emailAccountButtonRemove: {
    backgroundColor: '#fef2f2',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  emailAccountButtonTextRemove: {
    ...typography.caption1,
    color: '#dc2626',
    fontWeight: '600',
  },
  emailErrorBox: {
    backgroundColor: '#fef2f2',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  emailErrorTitle: {
    ...typography.subhead,
    color: '#dc2626',
    fontWeight: '600',
    marginBottom: spacing.sm,
  },
  emailTroubleshootingList: {
    marginTop: spacing.xs,
  },
  emailTroubleshootingStep: {
    ...typography.caption1,
    color: '#7f1d1d',
    marginBottom: spacing.xs,
    lineHeight: 18,
  },
  emailTroubleshootingSpacer: {
    height: spacing.sm,
  },
  addEmailSection: {
    marginTop: spacing.sm,
  },
  redetectAllButton: {
    backgroundColor: colors.primary,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  redetectAllButtonText: {
    ...typography.body,
    color: '#fff',
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  twilioSettingsCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    ...shadows.small,
  },
  twilioSettingsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  twilioSettingsTitle: {
    ...typography.headline,
    fontWeight: '600',
    color: colors.text,
  },
  twilioStatusBadgeConnected: {
    backgroundColor: '#dcfce7',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.md,
  },
  twilioStatusTextConnected: {
    ...typography.caption1,
    color: '#166534',
    fontWeight: '600',
  },
  twilioStatusBadgeWarning: {
    backgroundColor: '#fef9c3',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.md,
  },
  twilioStatusTextWarning: {
    ...typography.caption1,
    color: '#854d0e',
    fontWeight: '600',
  },
  twilioPhoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  twilioPhoneLabel: {
    ...typography.body,
    color: colors.textSecondary,
    marginRight: spacing.sm,
  },
  twilioPhoneNumber: {
    ...typography.body,
    color: colors.text,
    fontWeight: '600',
  },
  twilioA2pRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  twilioA2pInfo: {
    flex: 1,
    marginRight: spacing.md,
  },
  twilioA2pLabel: {
    ...typography.body,
    color: colors.text,
    fontWeight: '500',
    marginBottom: spacing.xs,
  },
  twilioA2pHelpText: {
    ...typography.caption1,
    color: colors.textSecondary,
    lineHeight: 18,
  },
  twilioToggle: {
    width: 50,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#e5e7eb',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  twilioToggleActive: {
    backgroundColor: '#22c55e',
  },
  twilioToggleKnob: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#fff',
    ...shadows.small,
  },
  twilioToggleKnobActive: {
    alignSelf: 'flex-end',
  },
  twilioTestButton: {
    backgroundColor: colors.primary,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
  },
  twilioTestButtonText: {
    ...typography.body,
    color: '#fff',
    fontWeight: '600',
  },
  twilioHelpText: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginTop: spacing.md,
    textAlign: 'center',
    lineHeight: 18,
  },
  testSmsModalContent: {
    backgroundColor: '#fff',
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    width: '90%',
    maxWidth: 400,
    ...shadows.large,
  },
  testSmsModalTitle: {
    ...typography.title2,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.xs,
    textAlign: 'center',
  },
  testSmsModalSubtitle: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  testSmsInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...typography.body,
    color: colors.text,
    marginBottom: spacing.lg,
    fontSize: 18,
  },
  testSmsModalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  testSmsCancelButton: {
    flex: 1,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.backgroundSecondary,
    alignItems: 'center',
  },
  testSmsCancelButtonText: {
    ...typography.body,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  testSmsSendButton: {
    flex: 1,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.primary,
    alignItems: 'center',
  },
  testSmsSendButtonText: {
    ...typography.body,
    color: '#fff',
    fontWeight: '600',
  },
  companySettingsCard: {
    backgroundColor: '#fff',
    borderRadius: borderRadius.xl,
    padding: spacing.lg,
    ...shadows.medium,
  },
  companyLogoSection: {
    marginBottom: spacing.lg,
  },
  companyLogoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    marginTop: spacing.sm,
  },
  companyLogoPreview: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.backgroundSecondary,
  },
  companyLogoPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.backgroundSecondary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.border,
    borderStyle: 'dashed',
  },
  companyLogoPlaceholderText: {
    fontSize: 28,
  },
  companyLogoPlaceholderLabel: {
    ...typography.caption2,
    color: colors.textTertiary,
    marginTop: 2,
  },
  companyLogoUploadButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    minWidth: 100,
    alignItems: 'center',
  },
  companyLogoUploadButtonText: {
    ...typography.footnote,
    color: '#fff',
    fontWeight: '600',
  },
  companyDemoToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    marginBottom: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    marginTop: spacing.sm,
  },
  companyDemoInfo: {
    flex: 1,
    marginRight: spacing.md,
  },
  companyDemoLabel: {
    ...typography.body,
    color: colors.text,
    fontWeight: '500',
  },
  companyDemoHelpText: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  saveButton: {
    backgroundColor: colors.success,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
    minHeight: 50,
    justifyContent: 'center',
  },
  saveButtonText: {
    ...typography.body,
    color: '#fff',
    fontWeight: '600',
  },
  textArea: {
    minHeight: 60,
    textAlignVertical: 'top',
    paddingTop: spacing.md,
  },
  roleRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  roleChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  roleChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  roleChipText: {
    ...typography.subhead,
    color: colors.textSecondary,
    fontWeight: '500',
  },
  roleChipTextActive: {
    color: '#fff',
  },
});
