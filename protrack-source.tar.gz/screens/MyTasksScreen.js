import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Haptics from '../utils/haptics';
import { useUser } from '../contexts/UserContext';
import { apiRequest } from '../utils/api';
import { on, JOBS_UPDATED_EVENT } from '../utils/events';
import { colors, typography, spacing, borderRadius, shadows } from '../utils/theme';

export default function MyTasksScreen({ navigation }) {
  const { user, token, isAdmin } = useUser();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadOverview = useCallback(async () => {
    if (!token) return;
    
    try {
      const data = await apiRequest('/api/job-overview', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setJobs(data.jobs || []);
    } catch (error) {
      console.error('Load overview error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [token]);

  useEffect(() => {
    loadOverview();
  }, [loadOverview]);

  useFocusEffect(
    useCallback(() => {
      loadOverview();
    }, [loadOverview])
  );

  useEffect(() => {
    const unsubscribe = on(JOBS_UPDATED_EVENT, () => {
      loadOverview();
    });
    return unsubscribe;
  }, [loadOverview]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadOverview();
  }, [loadOverview]);

  const handleJobPress = (jobId) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    navigation.navigate('JobDetails', { 
      jobId: jobId,
      onRefresh: loadOverview 
    });
  };

  const totalTasks = jobs.reduce((sum, job) => 
    sum + job.workers.reduce((wSum, w) => wSum + w.tasks.length, 0), 0);
  const pendingTasks = jobs.reduce((sum, job) => 
    sum + job.workers.reduce((wSum, w) => wSum + w.tasks.filter(t => !t.completed).length, 0), 0);

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return { bg: '#E8F5E9', text: '#2E7D32' };
      case 'estimate': return { bg: '#FFF3E0', text: '#E65100' };
      case 'on_hold': return { bg: '#FFF8E1', text: '#F57F17' };
      default: return { bg: colors.backgroundSecondary, text: colors.textSecondary };
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'In Progress';
      case 'estimate': return 'Needs Estimate';
      case 'on_hold': return 'On Hold';
      default: return status;
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Loading jobs...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      >
        <View style={styles.header}>
          <Text style={styles.greeting}>
            {isAdmin ? 'Job Overview' : `Hi, ${user?.name || 'there'}!`}
          </Text>
          <Text style={styles.subtitle}>
            {jobs.length} active job{jobs.length !== 1 ? 's' : ''} • {pendingTasks} pending task{pendingTasks !== 1 ? 's' : ''}
          </Text>
        </View>

        {jobs.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>📋</Text>
            <Text style={styles.emptyTitle}>No Active Jobs</Text>
            <Text style={styles.emptyText}>
              {isAdmin 
                ? 'Create a new job to get started.'
                : 'You have no jobs assigned to you yet.'}
            </Text>
          </View>
        ) : (
          jobs.map((job) => {
            const statusColors = getStatusColor(job.status);
            return (
              <TouchableOpacity
                key={job.id}
                style={[styles.jobCard, job.urgent && styles.urgentCard]}
                onPress={() => handleJobPress(job.id)}
                activeOpacity={0.7}
              >
                <View style={styles.jobHeader}>
                  <View style={styles.jobInfo}>
                    {job.urgent && (
                      <View style={styles.urgentBadge}>
                        <Text style={styles.urgentText}>URGENT</Text>
                      </View>
                    )}
                    <Text style={styles.customerName}>{job.customerName}</Text>
                    <Text style={styles.jobNumber}>{job.jobNumber}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: statusColors.bg }]}>
                    <Text style={[styles.statusText, { color: statusColors.text }]}>
                      {getStatusLabel(job.status)}
                    </Text>
                  </View>
                </View>
                
                <Text style={styles.address}>{job.address}</Text>
                
                {job.workers.length === 0 ? (
                  <View style={styles.noWorkers}>
                    <Text style={styles.noWorkersText}>No workers assigned</Text>
                  </View>
                ) : (
                  <View style={styles.workersSection}>
                    <Text style={styles.sectionLabel}>Assigned Workers</Text>
                    {job.workers.map((worker) => (
                      <View key={worker.id} style={styles.workerBlock}>
                        <View style={styles.workerHeader}>
                          <View style={styles.workerAvatar}>
                            <Text style={styles.avatarText}>
                              {worker.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                            </Text>
                          </View>
                          <View style={styles.workerInfo}>
                            <Text style={styles.workerName}>{worker.name}</Text>
                            {worker.trade && (
                              <Text style={styles.workerTrade}>{worker.trade}</Text>
                            )}
                          </View>
                          <View style={styles.taskCount}>
                            <Text style={styles.taskCountText}>
                              {worker.tasks.filter(t => !t.completed).length}/{worker.tasks.length}
                            </Text>
                          </View>
                        </View>
                        
                        {worker.tasks.length > 0 ? (
                          <View style={styles.tasksList}>
                            {worker.tasks.map((task) => (
                              <View key={task.id} style={styles.taskItem}>
                                <View style={[
                                  styles.taskDot,
                                  task.completed && styles.taskDotCompleted
                                ]} />
                                <Text style={[
                                  styles.taskText,
                                  task.completed && styles.taskTextCompleted
                                ]}>
                                  {task.description}
                                </Text>
                              </View>
                            ))}
                          </View>
                        ) : (
                          <Text style={styles.noTasksText}>No tasks assigned</Text>
                        )}
                      </View>
                    ))}
                  </View>
                )}
              </TouchableOpacity>
            );
          })
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    ...typography.body,
    color: colors.textTertiary,
    marginTop: spacing.md,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
  },
  header: {
    marginBottom: spacing.lg,
  },
  greeting: {
    ...typography.title1,
    color: colors.text,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing.xl * 2,
    paddingHorizontal: spacing.lg,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: spacing.md,
  },
  emptyTitle: {
    ...typography.title2,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  emptyText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  jobCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
    ...shadows.small,
  },
  urgentCard: {
    borderLeftWidth: 4,
    borderLeftColor: colors.error,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.sm,
  },
  jobInfo: {
    flex: 1,
    marginRight: spacing.sm,
  },
  urgentBadge: {
    backgroundColor: colors.error,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
    alignSelf: 'flex-start',
    marginBottom: spacing.xs,
  },
  urgentText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  customerName: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
  },
  jobNumber: {
    ...typography.caption1,
    color: colors.primary,
    fontWeight: '600',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.md,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  address: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  noWorkers: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  noWorkersText: {
    ...typography.footnote,
    color: colors.textTertiary,
    fontStyle: 'italic',
  },
  workersSection: {
    borderTopWidth: 1,
    borderTopColor: colors.borderLight,
    paddingTop: spacing.md,
  },
  sectionLabel: {
    ...typography.caption1,
    color: colors.textTertiary,
    fontWeight: '600',
    marginBottom: spacing.sm,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  workerBlock: {
    marginBottom: spacing.md,
  },
  workerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  workerAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  avatarText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
  },
  workerInfo: {
    flex: 1,
  },
  workerName: {
    ...typography.headline,
    color: colors.text,
    fontWeight: '600',
  },
  workerTrade: {
    ...typography.caption1,
    color: colors.textSecondary,
  },
  taskCount: {
    backgroundColor: colors.backgroundTertiary || '#E3E9ED',
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: borderRadius.sm,
  },
  taskCountText: {
    ...typography.caption1,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  tasksList: {
    marginLeft: 44,
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.xs,
  },
  taskDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.warning,
    marginTop: 6,
    marginRight: spacing.sm,
  },
  taskDotCompleted: {
    backgroundColor: colors.success,
  },
  taskText: {
    ...typography.body,
    color: colors.text,
    flex: 1,
  },
  taskTextCompleted: {
    textDecorationLine: 'line-through',
    color: colors.textTertiary,
  },
  noTasksText: {
    ...typography.footnote,
    color: colors.textTertiary,
    fontStyle: 'italic',
    marginLeft: 44,
  },
});
