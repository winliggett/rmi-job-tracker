import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Linking,
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Dimensions,
  DeviceEventEmitter,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from '../utils/haptics';
import { useUser } from '../contexts/UserContext';
import api from '../utils/api';
import { colors, typography, spacing, borderRadius, shadows } from '../utils/theme';
import VoiceDictation from '../components/VoiceDictation';
import UserAvatar from '../components/UserAvatar';
import ConfirmModal from '../components/ConfirmModal';
import EditableField from '../components/EditableField';
import { useToast } from '../components/Toast';
import { VOICE_REFRESH_EVENT, JOBS_UPDATED_EVENT, emit } from '../utils/events';

export default function JobDetailsScreen({ route, navigation }) {
  const { jobId, onRefresh } = route.params || {};
  const { user, token, isAdmin } = useUser();
  const toast = useToast();
  const scrollViewRef = useRef(null);
  const activitySectionRef = useRef(null);
  
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [noteText, setNoteText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showVoice, setShowVoice] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);
  const [activities, setActivities] = useState([]);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [allJobs, setAllJobs] = useState([]);
  const [allTeamMembers, setAllTeamMembers] = useState([]);
  const [mentionSuggestions, setMentionSuggestions] = useState([]);
  const [showMentionDropdown, setShowMentionDropdown] = useState(false);
  const [activityExpanded, setActivityExpanded] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [notePhotoUri, setNotePhotoUri] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [notificationsExpanded, setNotificationsExpanded] = useState(false);
  const [assignedWorkers, setAssignedWorkers] = useState([]);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedWorkers, setSelectedWorkers] = useState([]);
  const [savingAssignments, setSavingAssignments] = useState(false);

  // Handle note text changes and detect @mentions
  const handleNoteTextChange = (text) => {
    setNoteText(text);
    
    // Find the last @ symbol and check if we're typing a mention
    const lastAtIndex = text.lastIndexOf('@');
    if (lastAtIndex >= 0) {
      const textAfterAt = text.substring(lastAtIndex + 1);
      // Check if there's no space after @ (still typing the name)
      if (!textAfterAt.includes(' ') && textAfterAt.length >= 0) {
        const searchTerm = textAfterAt.toLowerCase();
        // Use allTeamMembers which is fetched from the API
        const members = Array.isArray(allTeamMembers) ? allTeamMembers : [];
        const filtered = members.filter(m => 
          m.name?.toLowerCase().includes(searchTerm) || 
          (m.username && m.username.toLowerCase().includes(searchTerm))
        );
        setMentionSuggestions(filtered.slice(0, 5));
        setShowMentionDropdown(filtered.length > 0);
        return;
      }
    }
    setShowMentionDropdown(false);
    setMentionSuggestions([]);
  };

  // Insert selected mention into note text
  const handleSelectMention = (member) => {
    const lastAtIndex = noteText.lastIndexOf('@');
    if (lastAtIndex >= 0) {
      const newText = noteText.substring(0, lastAtIndex) + '@' + member.name + ' ';
      setNoteText(newText);
    }
    setShowMentionDropdown(false);
    setMentionSuggestions([]);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleCopyDoorCode = async () => {
    const codeText = job?.door_code || job?.key_location || '';
    if (codeText) {
      await Clipboard.setStringAsync(codeText);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setCodeCopied(true);
      setTimeout(() => setCodeCopied(false), 2000);
    }
  };

  const loadJob = useCallback(async () => {
    if (!token || !jobId) return;
    
    try {
      const data = await api.getJobDetails(token, jobId);
      setJob(data);
      
      // Load assigned workers from the job data
      if (data.assigned_trades) {
        setAssignedWorkers(data.assigned_trades);
        setSelectedWorkers(data.assigned_trades.map(w => w.id));
      }
      
      const activityData = await api.getJobActivity(token, jobId);
      setActivities(activityData.activities || []);
      
      try {
        const notifData = await api.getNotificationHistory(token, jobId);
        setNotifications(notifData.notifications || []);
      } catch (e) {
        console.log('Notification history not available:', e.message);
      }
    } catch (error) {
      console.error('Load job error:', error);
      toast.error('Failed to load job details');
    } finally {
      setLoading(false);
    }
  }, [token, jobId, toast]);

  useEffect(() => {
    loadJob();
  }, [loadJob]);

  // Listen for voice command refresh events
  useEffect(() => {
    const subscription = DeviceEventEmitter.addListener(VOICE_REFRESH_EVENT, () => {
      console.log('Voice refresh event received - reloading job details');
      loadJob();
    });
    return () => subscription?.remove();
  }, [loadJob]);

  useEffect(() => {
    const loadVoiceContext = async () => {
      try {
        const jobsData = await api.getJobs(token, {});
        setAllJobs(jobsData || []);
        
        const usersData = await api.getTradeUsers(token);
        setAllTeamMembers(usersData?.trades || []);
      } catch (error) {
        console.error('Failed to load voice context:', error);
      }
    };
    
    if (token) {
      loadVoiceContext();
    }
  }, [token]);

  const handleAddTask = async () => {
    if (!noteText.trim() && !notePhotoUri) {
      toast.error('Please enter a task');
      return;
    }
    
    // Check if there's an @mention
    const hasMention = noteText.includes('@');
    if (!hasMention) {
      toast.error('Please @mention someone to assign the task (e.g. @bob)');
      return;
    }

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setSubmitting(true);

    try {
      // Use FormData to support photo upload
      const formData = new FormData();
      formData.append('text', noteText || '(photo)');
      
      if (notePhotoUri) {
        if (Platform.OS === 'web') {
          const response = await fetch(notePhotoUri);
          const blob = await response.blob();
          formData.append('photo', blob, 'note_photo.jpg');
        } else {
          formData.append('photo', {
            uri: notePhotoUri,
            type: 'image/jpeg',
            name: 'note_photo.jpg',
          });
        }
      }
      
      const uploadResponse = await fetch(`${api.BASE_URL}/api/jobs/${jobId}/notes`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
      
      const response = await uploadResponse.json();
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setNoteText('');
      setNotePhotoUri(null);
      
      if (response.tasksCreated && response.tasksCreated.length > 0) {
        const names = response.tasksCreated.map(t => t.user.name).join(', ');
        toast.success(`Task assigned to: ${names}`);
      } else {
        toast.success('Task added');
      }
      
      await loadJob();
      if (onRefresh) onRefresh();
    } catch (error) {
      toast.error('Failed to add task');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVoiceResult = async (parsed) => {
    setShowVoice(false);
    
    console.log('Voice command result:', parsed);
    
    try {
      if (parsed.intent === 'add_task' && parsed.person_id) {
        await api.createTask(token, parsed.job_id || jobId, parsed.action, parsed.person_id);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        toast.success(`Task assigned to ${parsed.person_name}`);
        await loadJob();
        if (onRefresh) onRefresh();
      } else {
        const voiceNoteText = parsed.person_id 
          ? `@${parsed.person_name} ${parsed.action}` 
          : parsed.action;
        
        await api.addNote(token, parsed.job_id || jobId, voiceNoteText);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        toast.success('Note added');
        await loadJob();
        if (onRefresh) onRefresh();
      }
    } catch (error) {
      console.error('Voice command execution error:', error);
      toast.error('Failed to execute voice command. Please try again.');
    }
  };


  const handleDeleteJob = () => {
    setDeleteConfirm(true);
  };

  const handleFieldSave = async (field, value) => {
    try {
      const fieldMap = {
        'door_code': 'doorCode',
        'key_location': 'keyLocation',
        'client_email': 'clientEmail',
        'client_name': 'customerName',
        'customer_name': 'customerName',
      };
      const apiField = fieldMap[field] || field;
      await api.updateJob(token, jobId, { [apiField]: value });
      setJob(prev => ({ ...prev, [field]: value }));
      await loadJob();
      if (onRefresh) onRefresh();
      toast.success('Saved');
    } catch (error) {
      console.error('Save field error:', error);
      toast.error('Failed to save');
      throw error;
    }
  };

  const confirmDeleteJob = async () => {
    setDeleteConfirm(false);
    try {
      await api.deleteJob(token, jobId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      emit(JOBS_UPDATED_EVENT);
      if (onRefresh) onRefresh();
      navigation.goBack();
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Failed to delete job');
    }
  };

  const toggleWorkerSelection = (userId) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (selectedWorkers.includes(userId)) {
      setSelectedWorkers(selectedWorkers.filter(id => id !== userId));
    } else {
      setSelectedWorkers([...selectedWorkers, userId]);
    }
  };

  const handleSaveAssignments = async () => {
    setSavingAssignments(true);
    try {
      const result = await api.updateJobAssignments(token, jobId, selectedWorkers);
      setAssignedWorkers(result.assigned_trades || []);
      setShowAssignModal(false);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('Worker visibility updated');
      await loadJob();
      if (onRefresh) onRefresh();
    } catch (error) {
      console.error('Save assignments error:', error);
      toast.error('Failed to update assignments');
    } finally {
      setSavingAssignments(false);
    }
  };

  const openAssignModal = () => {
    setSelectedWorkers(assignedWorkers.map(w => w.id));
    setShowAssignModal(true);
  };

  const handleChangeStatus = async (newStatus) => {
    const statusLabels = {
      estimate: 'Needs Estimate',
      active: 'In Progress',
      completed: 'Completed',
      on_hold: 'On Hold',
      closed: 'Closed (Archived)'
    };
    
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.updateJobStatus(token, jobId, newStatus);
      await loadJob();
      if (onRefresh) onRefresh();
      
      toast.success(`Job status changed to ${statusLabels[newStatus]}`);
    } catch (error) {
      console.error('Status update error:', error);
      toast.error('Failed to update status');
    }
  };

  const handleToggleUrgent = async () => {
    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      const newUrgent = !job.urgent;
      await fetch(`${api.BASE_URL}/api/jobs/${jobId}/urgent`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ urgent: newUrgent })
      });
      await loadJob();
      if (onRefresh) onRefresh();
      
      toast.success(newUrgent ? 'Job marked as URGENT!' : 'Urgent status removed');
    } catch (error) {
      console.error('Urgent toggle error:', error);
      toast.error('Failed to update urgent status');
    }
  };

  const handleToggleTask = async (taskId) => {
    if (!isAdmin()) {
      toast.error('Only admin can mark tasks complete');
      return;
    }

    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.toggleTask(token, taskId);
      await loadJob();
      if (onRefresh) onRefresh();
    } catch (error) {
      toast.error('Failed to update task');
    }
  };

  const handleDeleteTask = async (taskId, taskDescription) => {
    if (!isAdmin()) {
      toast.error('Only admin can delete tasks');
      return;
    }

    const confirmed = Platform.OS === 'web'
      ? window.confirm(`Delete task: "${taskDescription}"?`)
      : await new Promise((resolve) => {
          Alert.alert(
            'Delete Task',
            `Delete task: "${taskDescription}"?`,
            [
              { text: 'Cancel', style: 'cancel', onPress: () => resolve(false) },
              { text: 'Delete', style: 'destructive', onPress: () => resolve(true) }
            ]
          );
        });

    if (!confirmed) return;

    try {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      await api.deleteTask(token, taskId);
      toast.success('Task deleted');
      await loadJob();
      if (onRefresh) onRefresh();
    } catch (error) {
      toast.error('Failed to delete task');
    }
  };

  const handleTakePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      toast.info('Camera access is needed to take photos');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      quality: 0.8,
      allowsEditing: true,
    });

    if (!result.canceled) {
      await uploadPhoto(result.assets[0].uri);
    }
  };

  const handlePickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      toast.info('Photo library access is needed');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 0.8,
      allowsEditing: true,
    });

    if (!result.canceled) {
      await uploadPhoto(result.assets[0].uri);
    }
  };

  // Attach photo to note (not upload immediately)
  const handleAttachNotePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      toast.info('Camera access is needed to take photos');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      quality: 0.8,
      allowsEditing: true,
    });

    if (!result.canceled) {
      setNotePhotoUri(result.assets[0].uri);
      toast.success('Photo attached to note');
    }
  };

  const handlePickNotePhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      toast.info('Photo library access is needed');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      quality: 0.8,
      allowsEditing: true,
    });

    if (!result.canceled) {
      setNotePhotoUri(result.assets[0].uri);
      toast.success('Photo attached to note');
    }
  };

  const handleDeletePhoto = async (photoId) => {
    const confirmDelete = Platform.OS === 'web' 
      ? window.confirm('Are you sure you want to delete this photo?')
      : await new Promise(resolve => {
          Alert.alert(
            'Delete Photo',
            'Are you sure you want to delete this photo?',
            [
              { text: 'Cancel', style: 'cancel', onPress: () => resolve(false) },
              { text: 'Delete', style: 'destructive', onPress: () => resolve(true) },
            ]
          );
        });
    
    if (!confirmDelete) return;
    
    try {
      await fetch(`${api.BASE_URL}/api/photos/${photoId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('Photo deleted');
      await loadJob();
    } catch (error) {
      toast.error('Failed to delete photo');
    }
  };

  const handleDeleteNote = async (noteId) => {
    const confirmDelete = Platform.OS === 'web' 
      ? window.confirm('Are you sure you want to delete this note?')
      : await new Promise(resolve => {
          Alert.alert(
            'Delete Note',
            'Are you sure you want to delete this note?',
            [
              { text: 'Cancel', style: 'cancel', onPress: () => resolve(false) },
              { text: 'Delete', style: 'destructive', onPress: () => resolve(true) },
            ]
          );
        });
    
    if (!confirmDelete) return;
    
    try {
      await fetch(`${api.BASE_URL}/api/notes/${noteId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('Note deleted');
      await loadJob();
    } catch (error) {
      toast.error('Failed to delete note');
    }
  };

  const handleDeleteActivity = async (activityId) => {
    const confirmDelete = Platform.OS === 'web' 
      ? window.confirm('Are you sure you want to delete this activity log entry?')
      : await new Promise(resolve => {
          Alert.alert(
            'Delete Activity',
            'Are you sure you want to delete this activity log entry?',
            [
              { text: 'Cancel', style: 'cancel', onPress: () => resolve(false) },
              { text: 'Delete', style: 'destructive', onPress: () => resolve(true) },
            ]
          );
        });
    
    if (!confirmDelete) return;
    
    try {
      await fetch(`${api.BASE_URL}/api/activity/${activityId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('Activity deleted');
      await loadJob();
      // Reload activities
      const activitiesResponse = await api.getActivities(token, jobId);
      setActivities(activitiesResponse.activities || []);
    } catch (error) {
      toast.error('Failed to delete activity');
    }
  };

  const uploadPhoto = async (uri) => {
    try {
      setSubmitting(true);
      const formData = new FormData();
      
      // For web: fetch the blob from URI and append to FormData
      if (Platform.OS === 'web') {
        const response = await fetch(uri);
        const blob = await response.blob();
        formData.append('photo', blob, 'photo.jpg');
      } else {
        // For native mobile
        formData.append('photo', {
          uri,
          type: 'image/jpeg',
          name: 'photo.jpg',
        });
      }

      const uploadResponse = await fetch(`${api.BASE_URL}/api/jobs/${jobId}/photos`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error('Upload failed');
      }

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success('Photo uploaded successfully');
      await loadJob();
    } catch (error) {
      console.error('Photo upload error:', error);
      toast.error('Failed to upload photo');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCall = () => {
    if (job?.phone) {
      Linking.openURL(`tel:${job.phone}`);
    }
  };

  const handleNavigate = () => {
    if (job?.address) {
      const query = encodeURIComponent(job.address);
      Linking.openURL(`https://maps.google.com/?q=${query}`);
    }
  };

  // Group tasks by assignee - now includes user info for avatar
  const tasksByPerson = useMemo(() => {
    if (!job?.tasks) return {};
    
    return job.tasks.reduce((acc, task) => {
      const key = task.assignee_id || 'unassigned';
      if (!acc[key]) {
        acc[key] = {
          name: task.assignee_name || 'Unassigned',
          trade: task.assignee_trade,
          profile_picture_url: task.assignee_profile_picture_url,
          tasks: []
        };
      }
      acc[key].tasks.push(task);
      return acc;
    }, {});
  }, [job?.tasks]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Loading job...</Text>
      </View>
    );
  }

  if (!job) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.emptyText}>Job not found</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
        keyboardVerticalOffset={90}
      >
        <ScrollView
          ref={scrollViewRef}
          style={styles.scrollView}
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          {/* JOB INFO CARD - AT TOP */}
          <View style={styles.jobCard}>
            {/* Client Name - Editable for Admin */}
            <View style={styles.cardHeader}>
              <Image source={require('../assets/protrack-icon.png')} style={styles.headerLogo} />
              <View style={styles.headerText}>
                {isAdmin() ? (
                  <EditableField
                    value={job.customer_name || job.client_name}
                    onSave={(val) => handleFieldSave('client_name', val)}
                    isAdmin={true}
                    placeholder="Client name"
                    fontSize={32}
                    fontWeight="700"
                    color="#ffffff"
                    darkMode={true}
                  />
                ) : (
                  <Text style={styles.clientName}>{job.customer_name || job.client_name}</Text>
                )}
                <Text style={styles.statusBadge}>{job.status || 'Active'}</Text>
              </View>
            </View>

            {/* Address - Editable for Admin */}
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>📍</Text>
              <View style={styles.infoContent}>
                {isAdmin() ? (
                  <EditableField
                    value={job.address}
                    onSave={(val) => handleFieldSave('address', val)}
                    isAdmin={true}
                    type="address"
                    placeholder="Enter address"
                    fontSize={22}
                    fontWeight="500"
                    color="#ffffff"
                    darkMode={true}
                  />
                ) : (
                  <TouchableOpacity onPress={handleNavigate}>
                    <Text style={styles.infoText}>{job.address}</Text>
                  </TouchableOpacity>
                )}
                {!isAdmin() && job.address && (
                  <TouchableOpacity onPress={handleNavigate}>
                    <Text style={styles.mapLink}>Open in Maps →</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {/* Phone - Editable for Admin */}
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>📱</Text>
              <View style={styles.infoContent}>
                {isAdmin() ? (
                  <EditableField
                    value={job.phone}
                    onSave={(val) => handleFieldSave('phone', val)}
                    isAdmin={true}
                    type="tel"
                    placeholder="Enter phone number"
                    fontSize={20}
                    fontWeight="500"
                    color="#ffffff"
                    darkMode={true}
                  />
                ) : job.phone ? (
                  <TouchableOpacity onPress={handleCall}>
                    <Text style={[styles.infoText, styles.linkText]}>{job.phone}</Text>
                  </TouchableOpacity>
                ) : (
                  <Text style={styles.infoTextMuted}>No phone number</Text>
                )}
              </View>
            </View>

            {/* Client Email - Editable for Admin */}
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>✉️</Text>
              <View style={styles.infoContent}>
                {isAdmin() ? (
                  <EditableField
                    value={job.client_email}
                    onSave={(val) => handleFieldSave('client_email', val)}
                    isAdmin={true}
                    type="email"
                    placeholder="Enter client email"
                    fontSize={20}
                    fontWeight="500"
                    color="#ffffff"
                    darkMode={true}
                  />
                ) : job.client_email ? (
                  <TouchableOpacity onPress={() => Linking.openURL(`mailto:${job.client_email}`)}>
                    <Text style={[styles.infoText, styles.linkText]}>{job.client_email}</Text>
                  </TouchableOpacity>
                ) : (
                  <Text style={styles.infoTextMuted}>No email</Text>
                )}
              </View>
            </View>
          </View>

          {/* DOOR CODE - BELOW JOB INFO */}
          <View style={styles.doorCodeSection}>
            <View style={styles.doorCodeHeader}>
              <Text style={styles.doorCodeLabel}>🔑 ACCESS CODE</Text>
              <TouchableOpacity style={styles.copyBadge} onPress={handleCopyDoorCode}>
                <Text style={styles.copyBadgeText}>
                  {codeCopied ? '✓ Copied!' : '📋 Tap to Copy'}
                </Text>
              </TouchableOpacity>
            </View>
            
            {isAdmin() ? (
              <EditableField
                value={job.door_code ?? ''}
                onSave={(val) => handleFieldSave('door_code', val)}
                isAdmin={true}
                placeholder="Enter door code (optional)"
                fontSize={52}
                fontWeight="700"
                color="#ffffff"
                darkMode={true}
              />
            ) : (
              <Text style={styles.doorCodeText}>
                {job.door_code || job.key_location || 'Key in lockbox'}
              </Text>
            )}
            
            {job.key_location && job.door_code && (
              <Text style={styles.keyLocationNote}>📍 {job.key_location}</Text>
            )}
          </View>

          {/* ADMIN JOB ACTIONS */}
          {isAdmin() && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>⚙️ Job Actions</Text>
              <View style={styles.statusButtonsRow}>
                <TouchableOpacity 
                  style={[styles.statusButton, styles.estimateBtn, job.status === 'estimate' && styles.statusButtonActive]}
                  onPress={() => handleChangeStatus('estimate')}
                >
                  <Text style={[styles.statusButtonText, job.status !== 'estimate' && styles.estimateBtnText]}>📝 Estimate</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.statusButton, styles.activeBtn, job.status === 'active' && styles.statusButtonActive]}
                  onPress={() => handleChangeStatus('active')}
                >
                  <Text style={[styles.statusButtonText, job.status !== 'active' && styles.activeBtnText]}>🔄 Active</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.statusButton, styles.doneBtn, job.status === 'completed' && styles.statusButtonActive]}
                  onPress={() => handleChangeStatus('completed')}
                >
                  <Text style={[styles.statusButtonText, job.status !== 'completed' && styles.doneBtnText]}>✅ Done</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.statusButtonsRow}>
                <TouchableOpacity 
                  style={[styles.statusButton, styles.holdBtn, job.status === 'on_hold' && styles.statusButtonActive]}
                  onPress={() => handleChangeStatus('on_hold')}
                >
                  <Text style={[styles.statusButtonText, job.status !== 'on_hold' && styles.holdBtnText]}>⏸️ On Hold</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={[styles.statusButton, styles.archiveBtn, job.status === 'closed' && styles.statusButtonActive]}
                  onPress={() => handleChangeStatus('closed')}
                >
                  <Text style={[styles.statusButtonText, job.status !== 'closed' && styles.archiveBtnText]}>📁 Close/Archive</Text>
                </TouchableOpacity>
              </View>
              
              {/* Urgent Toggle */}
              <TouchableOpacity 
                style={[styles.urgentToggleButton, job.urgent && styles.urgentToggleButtonActive]}
                onPress={handleToggleUrgent}
              >
                <Text style={[styles.urgentToggleText, job.urgent && styles.urgentToggleTextActive]}>
                  {job.urgent ? '🚨 URGENT - Tap to Remove' : '🚨 Mark as URGENT'}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.deleteJobButton}
                onPress={handleDeleteJob}
              >
                <Text style={styles.deleteJobButtonText}>🗑️ Delete Job</Text>
              </TouchableOpacity>
              
              {/* Export Button */}
              <TouchableOpacity 
                style={styles.exportButton}
                onPress={async () => {
                  try {
                    const url = `${api.BASE_URL}/api/jobs/${jobId}/export`;
                    await Linking.openURL(url + '?token=' + encodeURIComponent(token));
                    toast.success('Export started');
                  } catch (error) {
                    toast.error('Export failed');
                  }
                }}
              >
                <Text style={styles.exportButtonText}>📄 Export to Google Docs Format</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ASSIGNED WORKERS - WHO CAN SEE THIS JOB */}
          {isAdmin() && (
            <View style={styles.section}>
              <View style={styles.sectionHeaderRow}>
                <Text style={styles.sectionTitle}>👷 Who Can See This Job</Text>
                <TouchableOpacity 
                  style={styles.editAssignBtn}
                  onPress={openAssignModal}
                >
                  <Text style={styles.editAssignBtnText}>✏️ Edit</Text>
                </TouchableOpacity>
              </View>
              
              {assignedWorkers.length === 0 ? (
                <View style={styles.noWorkersBox}>
                  <Text style={styles.noWorkersText}>No workers assigned yet</Text>
                  <Text style={styles.noWorkersHint}>Tap Edit to choose who can see this job</Text>
                </View>
              ) : (
                <View style={styles.workersList}>
                  {assignedWorkers.map((worker) => (
                    <View key={worker.id} style={styles.workerChip}>
                      <UserAvatar user={worker} size={32} />
                      <Text style={styles.workerChipName}>{worker.name}</Text>
                      {worker.trade && (
                        <Text style={styles.workerChipTrade}>{worker.trade}</Text>
                      )}
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* TASKS BY PERSON */}
          {Object.keys(tasksByPerson).length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>📋 Tasks</Text>
              {Object.entries(tasksByPerson).map(([personId, personData]) => (
                <View key={personId} style={styles.personGroup}>
                  <View style={styles.personHeader}>
                    <UserAvatar 
                      user={{ 
                        name: personData.name, 
                        trade: personData.trade, 
                        profile_picture_url: personData.profile_picture_url 
                      }} 
                      size={40} 
                    />
                    <Text style={[styles.personName, { marginLeft: 8 }]}>
                      {personData.name}{personData.trade ? ` - ${personData.trade}` : ''}
                    </Text>
                  </View>
                  {personData.tasks.map((task) => (
                    <View key={task.id} style={styles.taskRow}>
                      <TouchableOpacity
                        style={styles.taskItem}
                        onPress={() => handleToggleTask(task.id)}
                        disabled={!isAdmin()}
                      >
                        <View style={[
                          styles.checkbox,
                          task.completed && styles.checkboxCompleted
                        ]}>
                          {task.completed && <Text style={styles.checkmark}>✓</Text>}
                        </View>
                        <View style={styles.taskContent}>
                          <Text style={[
                            styles.taskText,
                            task.completed && styles.taskTextCompleted
                          ]}>
                            {task.description}
                          </Text>
                          {task.completed && task.completed_at && (
                            <Text style={styles.completedDate}>
                              ✅ Done {new Date(task.completed_at).toLocaleDateString()}
                            </Text>
                          )}
                        </View>
                      </TouchableOpacity>
                      {isAdmin() && (
                        <TouchableOpacity
                          style={styles.deleteTaskBtn}
                          onPress={() => handleDeleteTask(task.id, task.description)}
                        >
                          <Text style={styles.deleteTaskBtnText}>🗑️</Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  ))}
                </View>
              ))}
            </View>
          )}

          {/* Notes section removed - tasks are now created via @mentions */}


          {/* ACTIVITY LOG - COLLAPSIBLE */}
          {activities.length > 0 && (
            <View style={styles.section}>
              <View style={styles.activityHeader}>
                <TouchableOpacity 
                  style={styles.activityHeaderLeft}
                  onPress={() => setActivityExpanded(!activityExpanded)}
                >
                  <Text style={styles.sectionTitle}>📋 Activity History</Text>
                  <Text style={styles.expandArrow}>{activityExpanded ? '▲' : '▼'}</Text>
                </TouchableOpacity>
                
                {/* Quick minimize button */}
                {activityExpanded && (
                  <TouchableOpacity 
                    style={styles.minimizeBtn}
                    onPress={() => setActivityExpanded(false)}
                  >
                    <Text style={styles.minimizeBtnText}>− Minimize</Text>
                  </TouchableOpacity>
                )}
              </View>
              
              {/* Always show most recent activity */}
              {activities.slice(0, 1).map((activity) => (
                <View key={activity.id} style={styles.activityItem}>
                  <View style={styles.activityRow}>
                    <Text style={styles.activityUser}>{activity.user_name || 'System'}</Text>
                    <Text style={styles.activityAction}>{activity.action}</Text>
                    {isAdmin() && (
                      <TouchableOpacity 
                        style={styles.deleteItemBtn}
                        onPress={() => handleDeleteActivity(activity.id)}
                      >
                        <Text style={styles.deleteItemBtnText}>🗑️</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                  {activity.details && (
                    <Text style={styles.activityDetails} numberOfLines={2}>{activity.details}</Text>
                  )}
                  <Text style={styles.activityTime}>
                    {new Date(activity.created_at).toLocaleString()}
                  </Text>
                </View>
              ))}
              
              {/* Show remaining activities when expanded */}
              {activityExpanded && activities.slice(1).map((activity) => (
                <View key={activity.id} style={styles.activityItem}>
                  <View style={styles.activityRow}>
                    <Text style={styles.activityUser}>{activity.user_name || 'System'}</Text>
                    <Text style={styles.activityAction}>{activity.action}</Text>
                    {isAdmin() && (
                      <TouchableOpacity 
                        style={styles.deleteItemBtn}
                        onPress={() => handleDeleteActivity(activity.id)}
                      >
                        <Text style={styles.deleteItemBtnText}>🗑️</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                  {activity.details && (
                    <Text style={styles.activityDetails} numberOfLines={2}>{activity.details}</Text>
                  )}
                  <Text style={styles.activityTime}>
                    {new Date(activity.created_at).toLocaleString()}
                  </Text>
                </View>
              ))}
              
              {activities.length > 1 && !activityExpanded && (
                <TouchableOpacity 
                  style={styles.showMoreBtn}
                  onPress={() => setActivityExpanded(true)}
                >
                  <Text style={styles.showMoreText}>Show {activities.length - 1} more...</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* NOTIFICATION HISTORY - Admin only */}
          {isAdmin() && notifications.length > 0 && (
            <View style={styles.section}>
              <View style={styles.activityHeader}>
                <TouchableOpacity 
                  style={styles.activityHeaderLeft}
                  onPress={() => setNotificationsExpanded(!notificationsExpanded)}
                >
                  <Text style={styles.sectionTitle}>📬 Notification History</Text>
                  <Text style={styles.expandArrow}>{notificationsExpanded ? '▲' : '▼'}</Text>
                </TouchableOpacity>
                
                {notificationsExpanded && (
                  <TouchableOpacity 
                    style={styles.minimizeBtn}
                    onPress={() => setNotificationsExpanded(false)}
                  >
                    <Text style={styles.minimizeBtnText}>− Minimize</Text>
                  </TouchableOpacity>
                )}
              </View>
              
              {(notificationsExpanded ? notifications : notifications.slice(0, 3)).map((notif) => {
                const extractTaskFromMessage = (msg) => {
                  if (!msg) return null;
                  const taskMatch = msg.match(/task.*?:\s*(.+?)(?:\.|$)/i);
                  return taskMatch ? taskMatch[1].trim().substring(0, 40) : null;
                };
                const taskPreview = extractTaskFromMessage(notif.message_content);
                
                return (
                  <View key={notif.id} style={[
                    styles.notificationItem,
                    notif.status === 'skipped' && styles.notificationSkipped,
                    notif.status === 'failed' && styles.notificationFailed
                  ]}>
                    <View style={styles.notificationRow}>
                      <Text style={styles.notificationIcon}>
                        {notif.status === 'sent' || notif.status === 'delivered' ? '✓' : 
                         notif.status === 'skipped' ? '⊘' : 
                         notif.status === 'pending' ? '⏳' : '✗'}
                      </Text>
                      <View style={styles.notificationContent}>
                        <Text style={styles.notificationRecipient}>
                          {notif.status === 'skipped' ? 'Skipped' : 'Sent to'} {notif.recipient_name}
                        </Text>
                        {notif.skip_reason && (
                          <Text style={styles.notificationSkipReason}>{notif.skip_reason}</Text>
                        )}
                        {taskPreview && !notif.skip_reason && (
                          <Text style={styles.notificationMessage} numberOfLines={1}>
                            "{taskPreview}"
                          </Text>
                        )}
                      </View>
                      <Text style={styles.notificationTime}>
                        {new Date(notif.sent_at).toLocaleDateString('en-US', { 
                          month: 'numeric', 
                          day: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit'
                        })}
                      </Text>
                    </View>
                  </View>
                );
              })}
              
              {notifications.length > 3 && !notificationsExpanded && (
                <TouchableOpacity 
                  style={styles.showMoreBtn}
                  onPress={() => setNotificationsExpanded(true)}
                >
                  <Text style={styles.showMoreText}>Show {notifications.length - 3} more...</Text>
                </TouchableOpacity>
              )}
            </View>
          )}

          {/* PHOTOS */}
          {job.photos && job.photos.length > 0 && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>📷 Photos</Text>
              <View style={styles.photoGrid}>
                {job.photos.map((photo) => (
                  <View key={photo.id} style={styles.photoContainer}>
                    <TouchableOpacity onPress={() => setSelectedPhoto(photo)}>
                      <Image
                        source={{ uri: `${api.BASE_URL}${photo.path}` }}
                        style={styles.photoThumb}
                        resizeMode="cover"
                      />
                    </TouchableOpacity>
                    {isAdmin() && (
                      <TouchableOpacity
                        style={styles.photoDeleteBtn}
                        onPress={() => handleDeletePhoto(photo.id)}
                      >
                        <Text style={styles.photoDeleteText}>×</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* WORKER ASSIGNMENT MODAL */}
          <Modal
            visible={showAssignModal}
            transparent={true}
            animationType="slide"
            onRequestClose={() => setShowAssignModal(false)}
          >
            <View style={styles.assignModalOverlay}>
              <View style={styles.assignModalContent}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <Text style={styles.assignModalTitle}>👷 Select Who Can See This Job</Text>
                  <TouchableOpacity
                    style={styles.selectAllButton}
                    onPress={() => {
                      if (selectedWorkers.length === allTeamMembers.length) {
                        setSelectedWorkers([]);
                      } else {
                        setSelectedWorkers(allTeamMembers.map(m => m.id));
                      }
                    }}
                  >
                    <Text style={styles.selectAllText}>
                      {selectedWorkers.length === allTeamMembers.length ? 'Clear All' : 'Select All'}
                    </Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.assignModalSubtitle}>
                  These workers will see this job on their dashboard
                </Text>
                
                <ScrollView style={styles.assignWorkerList}>
                  {allTeamMembers.map((member) => {
                    const isSelected = selectedWorkers.includes(member.id);
                    return (
                      <TouchableOpacity
                        key={member.id}
                        style={[styles.assignWorkerItem, isSelected && styles.assignWorkerItemSelected]}
                        onPress={() => toggleWorkerSelection(member.id)}
                        activeOpacity={0.7}
                      >
                        <View style={[styles.assignCheckbox, isSelected && styles.assignCheckboxChecked]}>
                          {isSelected && <Text style={styles.assignCheckmark}>✓</Text>}
                        </View>
                        <UserAvatar user={member} size={40} />
                        <View style={styles.assignWorkerInfo}>
                          <Text style={styles.assignWorkerName}>{member.name}</Text>
                          {member.trade && (
                            <Text style={styles.assignWorkerTrade}>{member.trade}</Text>
                          )}
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
                
                <View style={styles.assignModalButtons}>
                  <TouchableOpacity 
                    style={styles.assignCancelBtn}
                    onPress={() => setShowAssignModal(false)}
                  >
                    <Text style={styles.assignCancelBtnText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.assignSaveBtn, savingAssignments && styles.assignSaveBtnDisabled]}
                    onPress={handleSaveAssignments}
                    disabled={savingAssignments}
                  >
                    {savingAssignments ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Text style={styles.assignSaveBtnText}>Save ({selectedWorkers.length} selected)</Text>
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Modal>

          {/* PHOTO LIGHTBOX MODAL */}
          <Modal
            visible={!!selectedPhoto}
            transparent={true}
            animationType="fade"
            onRequestClose={() => setSelectedPhoto(null)}
          >
            <View style={styles.lightboxContainer}>
              {/* Backdrop - tapping here closes the modal */}
              <TouchableOpacity 
                style={styles.lightboxBackdrop}
                activeOpacity={1}
                onPress={() => setSelectedPhoto(null)}
              />
              
              {/* Photo content - sits above backdrop, doesn't trigger close */}
              <View style={styles.lightboxContent} pointerEvents="box-none">
                {selectedPhoto && (
                  <Image
                    source={{ uri: `${api.BASE_URL}${selectedPhoto.path}` }}
                    style={styles.lightboxImage}
                    resizeMode="contain"
                  />
                )}
              </View>
              
              {/* Close button */}
              <TouchableOpacity 
                style={styles.lightboxCloseBtn}
                onPress={() => setSelectedPhoto(null)}
              >
                <Text style={styles.lightboxCloseBtnText}>✕</Text>
              </TouchableOpacity>
              
              <Text style={styles.lightboxHint}>Tap outside photo to close</Text>
            </View>
          </Modal>

          {/* ADD TASK SECTION */}
          <View style={styles.addNoteSection}>
            <Text style={styles.sectionTitle}>📋 Add Task</Text>
            
            <View style={{ position: 'relative', zIndex: 1000 }}>
              <TextInput
                style={styles.noteInput}
                placeholder="Type @name then the task (e.g. @bob fix the drain) - Press Enter to send"
                placeholderTextColor={colors.textTertiary}
                value={noteText}
                onChangeText={handleNoteTextChange}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                onKeyPress={(e) => {
                  if (Platform.OS === 'web' && e.nativeEvent.key === 'Enter' && !e.nativeEvent.shiftKey) {
                    e.preventDefault();
                    if (noteText.trim() && !submitting) {
                      handleAddTask();
                    }
                  }
                }}
                blurOnSubmit={false}
              />
              
              {/* @Mention Autocomplete Dropdown */}
              {showMentionDropdown && mentionSuggestions.length > 0 && (
                <View style={styles.mentionDropdown}>
                  {mentionSuggestions.map((member) => (
                    <TouchableOpacity
                      key={member.id}
                      style={styles.mentionItem}
                      onPress={() => handleSelectMention(member)}
                    >
                      <Text style={styles.mentionName}>{member.name}</Text>
                      {member.trade && (
                        <Text style={styles.mentionTrade}>{member.trade}</Text>
                      )}
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>

            {/* Attached Photo Preview */}
            {notePhotoUri && (
              <View style={styles.notePhotoPreview}>
                <Image source={{ uri: notePhotoUri }} style={styles.notePhotoThumb} />
                <TouchableOpacity 
                  style={styles.removePhotoBtn}
                  onPress={() => setNotePhotoUri(null)}
                >
                  <Text style={styles.removePhotoBtnText}>✕ Remove</Text>
                </TouchableOpacity>
              </View>
            )}

            <View style={styles.buttonRow}>
              <TouchableOpacity
                style={[styles.secondaryButton, { flex: 1, marginRight: spacing.sm }]}
                onPress={() => setShowVoice(true)}
              >
                <Text style={styles.secondaryButtonText}>🎤 Voice</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.secondaryButton, { flex: 1, marginRight: spacing.sm }, notePhotoUri && styles.secondaryButtonActive]}
                onPress={handleAttachNotePhoto}
              >
                <Text style={styles.secondaryButtonText}>📷 Camera</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.secondaryButton, { flex: 1 }, notePhotoUri && styles.secondaryButtonActive]}
                onPress={handlePickNotePhoto}
              >
                <Text style={styles.secondaryButtonText}>🖼️ Gallery</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={[styles.addButton, (submitting || (!noteText.trim() && !notePhotoUri)) && styles.addButtonDisabled]}
              onPress={handleAddTask}
              disabled={submitting || (!noteText.trim() && !notePhotoUri)}
            >
              {submitting ? (
                <ActivityIndicator size="small" color={colors.textInverse} />
              ) : (
                <Text style={styles.addButtonText}>Add Task</Text>
              )}
            </TouchableOpacity>
          </View>

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>

      {/* VOICE DICTATION MODAL */}
      {showVoice && (
        <VoiceDictation
          onResult={handleVoiceResult}
          onClose={() => setShowVoice(false)}
          teamMembers={allTeamMembers}
          jobs={allJobs}
          currentJobId={jobId}
        />
      )}

      <ConfirmModal
        visible={deleteConfirm}
        title="Delete Job"
        message={`Are you sure you want to delete this job?\n\nThis will permanently remove "${job?.customer_name || job?.client_name}" and all its notes, tasks, and history.`}
        confirmText="Delete"
        cancelText="Cancel"
        confirmStyle="danger"
        onConfirm={confirmDeleteJob}
        onCancel={() => setDeleteConfirm(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    ...typography.body,
    color: colors.textTertiary,
    marginTop: spacing.md,
  },
  emptyText: {
    ...typography.headline,
    color: colors.textSecondary,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
  },
  
  // Job Info Card
  jobCard: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    ...shadows.medium,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  headerLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: spacing.md,
  },
  headerText: {
    flex: 1,
  },
  appName: {
    ...typography.headline,
    color: colors.textInverse,
    fontWeight: '600',
  },
  statusBadge: {
    ...typography.caption1,
    color: 'rgba(255,255,255,0.8)',
    marginTop: spacing.xs,
    textTransform: 'capitalize',
  },
  clientName: {
    fontSize: 32,
    lineHeight: 38,
    letterSpacing: -0.35,
    color: colors.textInverse,
    marginBottom: spacing.md,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  infoIcon: {
    fontSize: 20,
    marginRight: spacing.sm,
  },
  infoText: {
    fontSize: 22,
    lineHeight: 28,
    color: colors.textInverse,
    flex: 1,
  },
  linkText: {
    textDecorationLine: 'underline',
  },
  infoContent: {
    flex: 1,
  },
  mapLink: {
    color: '#60a5fa',
    fontSize: 16,
    marginTop: 4,
    fontWeight: '500',
  },
  infoTextMuted: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 18,
    fontStyle: 'italic',
  },
  doorCodeSection: {
    backgroundColor: '#1C3B59',
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    ...shadows.medium,
    borderWidth: 3,
    borderColor: '#FFD700',
  },
  doorCodeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  doorCodeLabel: {
    ...typography.headline,
    color: '#FFD700',
    fontWeight: '700',
    letterSpacing: 1,
  },
  copyBadge: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: borderRadius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
  },
  copyBadgeText: {
    ...typography.footnote,
    color: '#fff',
    fontWeight: '600',
  },
  doorCodeText: {
    fontSize: 52,
    fontWeight: '900',
    color: '#FFFFFF',
    textAlign: 'center',
    letterSpacing: 4,
    paddingVertical: spacing.md,
  },
  keyLocationNote: {
    ...typography.body,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: spacing.sm,
  },

  // Sections
  section: {
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: -0.24,
    lineHeight: 25,
    color: colors.text,
    marginBottom: spacing.md,
  },

  // Tasks
  personGroup: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    ...shadows.small,
  },
  personHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  personName: {
    fontSize: 18,
    lineHeight: 24,
    color: colors.primary,
    fontWeight: '600',
  },
  taskRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
  },
  taskItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingVertical: spacing.sm,
  },
  deleteTaskBtn: {
    padding: spacing.sm,
    marginLeft: spacing.xs,
  },
  deleteTaskBtnText: {
    fontSize: 18,
  },
  checkbox: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  checkboxCompleted: {
    backgroundColor: colors.success,
    borderColor: colors.success,
  },
  checkmark: {
    color: colors.textInverse,
    fontSize: 18,
    fontWeight: '700',
  },
  taskContent: {
    flex: 1,
  },
  taskText: {
    fontSize: 18,
    lineHeight: 24,
    color: colors.text,
  },
  taskTextCompleted: {
    textDecorationLine: 'line-through',
    color: colors.textTertiary,
    opacity: 0.6,
  },
  completedDate: {
    ...typography.footnote,
    color: colors.success,
    marginTop: spacing.xs,
  },

  // Notes
  noteItem: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    ...shadows.small,
  },
  noteHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xs,
  },
  noteAuthor: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  noteDate: {
    fontSize: 14,
    color: colors.textTertiary,
  },
  noteText: {
    fontSize: 18,
    lineHeight: 26,
    color: colors.textSecondary,
  },
  notePhotoImage: {
    width: '100%',
    height: 200,
    borderRadius: borderRadius.md,
    marginTop: spacing.sm,
  },
  notePhotoPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundTertiary,
    padding: spacing.sm,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
  },
  notePhotoThumb: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.sm,
    marginRight: spacing.sm,
  },
  removePhotoBtn: {
    backgroundColor: colors.danger,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.sm,
  },
  removePhotoBtnText: {
    color: colors.textInverse,
    fontSize: 14,
    fontWeight: '600',
  },
  secondaryButtonActive: {
    backgroundColor: colors.success,
  },
  deleteItemBtn: {
    marginLeft: 'auto',
    padding: spacing.xs,
  },
  deleteItemBtnText: {
    fontSize: 16,
  },

  // Activity Log - LARGER TEXT
  activityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  activityHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  expandArrow: {
    fontSize: 20,
    color: colors.textSecondary,
    paddingHorizontal: spacing.sm,
  },
  minimizeBtn: {
    backgroundColor: colors.textSecondary,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 6,
  },
  minimizeBtnText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  demoNotifBanner: {
    backgroundColor: '#f0fdf4',
    borderRadius: borderRadius.lg,
    borderWidth: 2,
    borderColor: '#22c55e',
    padding: spacing.lg,
    marginHorizontal: spacing.md,
    marginBottom: spacing.lg,
    shadowColor: '#22c55e',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  demoNotifHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  demoNotifIcon: {
    fontSize: 22,
    marginTop: 1,
  },
  demoNotifTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#15803d',
  },
  demoNotifDetail: {
    fontSize: 14,
    color: '#374151',
    marginTop: 2,
  },
  demoNotifClose: {
    fontSize: 18,
    color: '#6b7280',
    padding: spacing.xs,
  },
  demoNotifTime: {
    fontSize: 12,
    color: '#9ca3af',
    marginTop: spacing.sm,
    marginLeft: 34,
  },
  activityItem: {
    backgroundColor: '#f5f5f5',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: spacing.xs,
  },
  activityUser: {
    ...typography.headline,
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
  },
  activityAction: {
    ...typography.body,
    color: colors.textSecondary,
    fontSize: 18,
  },
  activityDetails: {
    ...typography.body,
    color: colors.textTertiary,
    marginTop: 4,
    fontStyle: 'italic',
    fontSize: 16,
  },
  activityTime: {
    ...typography.subhead,
    color: '#374151',
    marginTop: 6,
    fontSize: 15,
  },
  showMoreBtn: {
    paddingVertical: spacing.sm,
    alignItems: 'center',
  },
  showMoreText: {
    ...typography.headline,
    color: colors.primary,
    fontSize: 17,
  },

  // Notification History
  notificationItem: {
    backgroundColor: '#e8f5e9',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  notificationSkipped: {
    backgroundColor: '#fff3e0',
  },
  notificationFailed: {
    backgroundColor: '#ffebee',
  },
  notificationRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
  },
  notificationIcon: {
    fontSize: 18,
    marginTop: 2,
  },
  notificationContent: {
    flex: 1,
  },
  notificationRecipient: {
    ...typography.headline,
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
  },
  notificationSkipReason: {
    ...typography.body,
    color: colors.textSecondary,
    fontSize: 14,
    fontStyle: 'italic',
  },
  notificationMessage: {
    ...typography.body,
    color: colors.textTertiary,
    fontSize: 14,
    marginTop: 2,
  },
  notificationTime: {
    ...typography.subhead,
    color: colors.textSecondary,
    fontSize: 13,
  },

  // Photos
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  photoContainer: {
    position: 'relative',
  },
  photoThumb: {
    width: 150,
    height: 150,
    borderRadius: 0,
  },
  photoDeleteBtn: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(220, 38, 38, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoDeleteText: {
    color: '#fff',
    fontSize: 22,
    fontWeight: 'bold',
    lineHeight: 24,
  },

  // Photo Lightbox
  lightboxContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lightboxBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
  },
  lightboxContent: {
    width: Dimensions.get('window').width - 40,
    height: Dimensions.get('window').height - 200,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  lightboxImage: {
    width: '100%',
    height: '100%',
  },
  lightboxCloseBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 20,
  },
  lightboxCloseBtnText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  lightboxHint: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 16,
    position: 'absolute',
    bottom: 50,
    zIndex: 20,
  },

  // Add Note
  addNoteSection: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.small,
    zIndex: 100,
    overflow: 'visible',
  },
  noteInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.borderLight,
    padding: spacing.md,
    ...typography.body,
    color: colors.text,
    minHeight: 100,
    marginBottom: spacing.md,
    textAlignVertical: 'top',
  },
  mentionDropdown: {
    position: 'absolute',
    top: 105,
    left: 0,
    right: 0,
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.primary,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 1000,
    maxHeight: 200,
  },
  mentionItem: {
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 48,
    cursor: 'pointer',
  },
  mentionName: {
    ...typography.body,
    color: colors.text,
    fontWeight: '600',
  },
  mentionTrade: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  buttonRow: {
    flexDirection: 'row',
    marginBottom: spacing.md,
  },
  secondaryButton: {
    backgroundColor: colors.backgroundTertiary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    minHeight: 48,
    justifyContent: 'center',
  },
  secondaryButtonText: {
    ...typography.subheadBold,
    color: colors.text,
  },
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    minHeight: 56,
    justifyContent: 'center',
    ...shadows.small,
  },
  addButtonDisabled: {
    opacity: 0.5,
  },
  addButtonText: {
    ...typography.headline,
    color: colors.textInverse,
    fontWeight: '600',
  },

  // Quick Add Task
  quickTaskCard: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.small,
  },
  quickTaskLabel: {
    ...typography.subheadBold,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  assigneePickerButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    minHeight: 52,
  },
  assigneePickerText: {
    ...typography.body,
    color: colors.text,
  },
  assigneePlaceholder: {
    color: colors.textTertiary,
  },
  dropdownArrow: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  assigneeDropdown: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderRadius: borderRadius.md,
    marginTop: spacing.xs,
    maxHeight: 200,
  },
  assigneeOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    minHeight: 48,
  },
  assigneeOptionSelected: {
    backgroundColor: `${colors.primary}15`,
  },
  assigneeOptionText: {
    ...typography.body,
    color: colors.text,
  },
  checkIcon: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: 'bold',
  },
  quickTaskInput: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.borderLight,
    padding: spacing.md,
    ...typography.body,
    color: colors.text,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  addTaskButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginTop: spacing.md,
    minHeight: 52,
    justifyContent: 'center',
  },
  addTaskButtonDisabled: {
    opacity: 0.5,
  },
  addTaskButtonText: {
    ...typography.headline,
    color: '#fff',
    fontWeight: '600',
  },
  statusButtonsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  statusButton: {
    flex: 1,
    minWidth: 100,
    borderRadius: borderRadius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    alignItems: 'center',
    borderWidth: 2,
    minHeight: 56,
    justifyContent: 'center',
  },
  statusButtonActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  // Estimate button - Orange/Amber (darker text for contrast)
  estimateBtn: {
    backgroundColor: '#FEF3E7',
    borderColor: '#B35A22',
  },
  estimateBtnText: {
    color: '#6B3810',
  },
  // Active button - Blue
  activeBtn: {
    backgroundColor: '#E8F0F7',
    borderColor: '#1C3B59',
  },
  activeBtnText: {
    color: '#0C2B49',
  },
  // Done button - Green (darker text for contrast)
  doneBtn: {
    backgroundColor: '#E8F5EC',
    borderColor: '#1E5D3A',
  },
  doneBtnText: {
    color: '#145530',
  },
  // On Hold button - Gray (darker text for contrast)
  holdBtn: {
    backgroundColor: '#F3F4F6',
    borderColor: '#4B5563',
  },
  holdBtnText: {
    color: '#374151',
  },
  // Archive button - Dark gray (darker text for contrast)
  archiveBtn: {
    backgroundColor: '#E5E7EB',
    borderColor: '#374151',
  },
  archiveBtnText: {
    color: '#1F2937',
  },
  statusButtonText: {
    ...typography.headline,
    color: colors.textInverse,
    fontWeight: '700',
    fontSize: 16,
  },
  urgentToggleButton: {
    backgroundColor: '#fef3c7',
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    marginTop: spacing.md,
    borderWidth: 2,
    borderColor: '#f59e0b',
    minHeight: 56,
    justifyContent: 'center',
  },
  urgentToggleButtonActive: {
    backgroundColor: '#ef4444',
    borderColor: '#dc2626',
  },
  urgentToggleText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#b45309',
  },
  urgentToggleTextActive: {
    color: '#ffffff',
  },
  deleteJobButton: {
    backgroundColor: '#fee2e2',
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: '#fca5a5',
  },
  deleteJobButtonText: {
    ...typography.headline,
    color: '#dc2626',
    fontWeight: '600',
  },
  exportButton: {
    backgroundColor: '#dbeafe',
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    marginTop: spacing.md,
    borderWidth: 1,
    borderColor: '#93c5fd',
  },
  exportButtonText: {
    ...typography.headline,
    color: '#1d4ed8',
    fontWeight: '600',
  },
  
  // Worker Assignment Section
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  editAssignBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  editAssignBtnText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  noWorkersBox: {
    backgroundColor: colors.backgroundTertiary,
    padding: spacing.lg,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  noWorkersText: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  noWorkersHint: {
    ...typography.caption1,
    color: colors.textTertiary,
  },
  workersList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  workerChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundTertiary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.lg,
    gap: spacing.sm,
  },
  workerChipName: {
    ...typography.body,
    fontWeight: '600',
    color: colors.text,
  },
  workerChipTrade: {
    ...typography.caption1,
    color: colors.textSecondary,
  },
  
  // Worker Assignment Modal
  assignModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  assignModalContent: {
    backgroundColor: colors.background,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xl,
    maxHeight: '80%',
  },
  assignModalTitle: {
    ...typography.title2,
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.xs,
    paddingHorizontal: spacing.lg,
  },
  assignModalSubtitle: {
    ...typography.caption1,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.lg,
    paddingHorizontal: spacing.lg,
  },
  selectAllButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  selectAllText: {
    ...typography.caption1,
    color: '#fff',
    fontWeight: '600',
  },
  assignWorkerList: {
    maxHeight: 400,
    paddingHorizontal: spacing.lg,
  },
  assignWorkerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.md,
    marginBottom: spacing.sm,
    gap: spacing.md,
  },
  assignWorkerItemSelected: {
    backgroundColor: '#dcfce7',
    borderWidth: 2,
    borderColor: '#22c55e',
  },
  assignCheckbox: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  assignCheckboxChecked: {
    backgroundColor: '#22c55e',
    borderColor: '#22c55e',
  },
  assignCheckmark: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  assignWorkerInfo: {
    flex: 1,
  },
  assignWorkerName: {
    ...typography.body,
    fontWeight: '600',
    color: colors.text,
  },
  assignWorkerTrade: {
    ...typography.caption1,
    color: colors.textSecondary,
    marginTop: 2,
  },
  assignModalButtons: {
    flexDirection: 'row',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
  },
  assignCancelBtn: {
    flex: 1,
    backgroundColor: colors.backgroundTertiary,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  assignCancelBtnText: {
    ...typography.body,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  assignSaveBtn: {
    flex: 2,
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  assignSaveBtnDisabled: {
    opacity: 0.6,
  },
  assignSaveBtnText: {
    ...typography.body,
    fontWeight: '700',
    color: '#fff',
  },
});
