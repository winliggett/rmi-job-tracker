import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from '../utils/haptics';
import { useUser } from '../contexts/UserContext';
import { createJob, getTradeUsers } from '../utils/api';
import { colors, typography, spacing, borderRadius, shadows } from '../utils/theme';
import { useToast } from '../components/Toast';
import AddressAutocomplete from '../components/AddressAutocomplete';
import { emit, JOBS_UPDATED_EVENT } from '../utils/events';

export default function CreateJobScreen({ navigation, route }) {
  const { user, token, isAdmin } = useUser();
  const toast = useToast();
  const { onRefresh } = route.params || {};

  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [address, setAddress] = useState('');
  const [doorCode, setDoorCode] = useState('');
  const [lockboxKey, setLockboxKey] = useState('');
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [tradeUsers, setTradeUsers] = useState([]);
  const [assignedTrades, setAssignedTrades] = useState([]);

  useEffect(() => {
    const loadTradeUsers = async () => {
      try {
        const data = await getTradeUsers(token);
        setTradeUsers(data.trades || []);
      } catch (error) {
        console.error('Failed to load trade users:', error);
      }
    };
    if (token) loadTradeUsers();
  }, [token]);

  const toggleTradeAssignment = (userId) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (assignedTrades.includes(userId)) {
      setAssignedTrades(assignedTrades.filter(id => id !== userId));
    } else {
      setAssignedTrades([...assignedTrades, userId]);
    }
  };

  if (!isAdmin()) {
    return (
      <SafeAreaView style={styles.container} edges={['bottom']}>
        <View style={styles.accessDenied}>
          <Text style={styles.accessDeniedIcon}>🚫</Text>
          <Text style={styles.accessDeniedTitle}>Access Denied</Text>
          <Text style={styles.accessDeniedText}>
            Only administrators can create new jobs
          </Text>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              navigation.goBack();
            }}
          >
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleCreate = async () => {
    if (!clientName.trim()) {
      toast.error('Please enter the client name');
      return;
    }
    if (!address.trim()) {
      toast.error('Please enter the job address');
      return;
    }

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setLoading(true);
    
    try {
      await createJob(token, {
        customerName: clientName,
        phone,
        clientEmail,
        address,
        doorCode,
        keyLocation: lockboxKey,
        description,
        assignedTrades,
      });
      
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      toast.success(`New job for ${clientName} has been created`);
      emit(JOBS_UPDATED_EVENT);
      if (onRefresh) onRefresh();
      navigation.goBack();
    } catch (error) {
      toast.error(error.message || 'Failed to create job');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.flex}
      >
        <ScrollView 
          style={styles.scrollView} 
          contentContainerStyle={styles.content}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Client Information</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Client Name <Text style={styles.required}>*</Text></Text>
              <TextInput
                style={styles.input}
                placeholder="Enter client name"
                placeholderTextColor={colors.textTertiary}
                value={clientName}
                onChangeText={setClientName}
                autoCapitalize="words"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Phone</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter phone number"
                placeholderTextColor={colors.textTertiary}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter client email"
                placeholderTextColor={colors.textTertiary}
                value={clientEmail}
                onChangeText={setClientEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            
            <View style={[styles.inputGroup, { zIndex: 100 }]}>
              <Text style={styles.inputLabel}>Address <Text style={styles.required}>*</Text></Text>
              <AddressAutocomplete
                value={address}
                onChangeText={setAddress}
                onSelectAddress={(data) => {
                  setAddress(data.address);
                }}
                placeholder="Start typing address..."
                inputStyle={styles.input}
              />
              <Text style={styles.helperText}>Start typing for address suggestions</Text>
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Access Information</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Door Code <Text style={styles.optional}>(optional)</Text></Text>
              <TextInput
                style={styles.input}
                placeholder="Enter door code"
                placeholderTextColor={colors.textTertiary}
                value={doorCode}
                onChangeText={setDoorCode}
                autoComplete="off"
                autoCorrect={false}
                textContentType="none"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Lockbox Key <Text style={styles.optional}>(optional)</Text></Text>
              <TextInput
                style={styles.input}
                placeholder="Enter lockbox key"
                placeholderTextColor={colors.textTertiary}
                value={lockboxKey}
                onChangeText={setLockboxKey}
                autoComplete="off"
                autoCorrect={false}
                textContentType="none"
              />
            </View>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Job Details</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Description</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Describe the scope of work"
                placeholderTextColor={colors.textTertiary}
                value={description}
                onChangeText={setDescription}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Job Notes</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Add any job notes"
                placeholderTextColor={colors.textTertiary}
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
          </View>

          {/* TRADE ASSIGNMENT */}
          {tradeUsers.length > 0 && (
            <View style={styles.card}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm }}>
                <Text style={styles.cardTitle}>Assign Trades</Text>
                <TouchableOpacity
                  style={styles.selectAllButton}
                  onPress={() => {
                    if (assignedTrades.length === tradeUsers.length) {
                      setAssignedTrades([]);
                    } else {
                      setAssignedTrades(tradeUsers.map(u => u.id));
                    }
                  }}
                >
                  <Text style={styles.selectAllText}>
                    {assignedTrades.length === tradeUsers.length ? 'Clear All' : 'Select All'}
                  </Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.assignHint}>Select trade workers who will work on this job</Text>
              
              {tradeUsers.map((tradeUser) => {
                const isSelected = assignedTrades.includes(tradeUser.id);
                return (
                  <TouchableOpacity
                    key={tradeUser.id}
                    style={[styles.tradeCheckbox, isSelected && styles.tradeCheckboxSelected]}
                    onPress={() => toggleTradeAssignment(tradeUser.id)}
                    activeOpacity={0.7}
                  >
                    <View style={[styles.checkbox, isSelected && styles.checkboxChecked]}>
                      {isSelected && <Text style={styles.checkmark}>✓</Text>}
                    </View>
                    <View style={styles.tradeInfo}>
                      <Text style={styles.tradeName}>{tradeUser.name}</Text>
                      <Text style={styles.tradeRole}>
                        {tradeUser.trade || '(no trade)'}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}

          <TouchableOpacity
            style={[styles.createButton, loading && styles.createButtonDisabled]}
            onPress={handleCreate}
            disabled={loading}
            activeOpacity={0.8}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.createButtonText}>Create Job</Text>
            )}
          </TouchableOpacity>

          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  flex: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
  },
  card: {
    backgroundColor: colors.backgroundSecondary,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    marginBottom: spacing.md,
    ...shadows.small,
  },
  cardTitle: {
    ...typography.headline,
    color: colors.text,
    marginBottom: spacing.md,
  },
  inputGroup: {
    marginBottom: spacing.md,
  },
  inputLabel: {
    ...typography.subhead,
    color: colors.textSecondary,
    fontWeight: '500',
    marginBottom: spacing.xs,
  },
  required: {
    color: colors.danger,
  },
  optional: {
    color: colors.textTertiary,
    fontWeight: '400',
    fontSize: 14,
  },
  helperText: {
    fontSize: 13,
    color: colors.textTertiary,
    marginTop: 6,
  },
  input: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    ...typography.body,
    color: colors.text,
    minHeight: 48,
  },
  textArea: {
    minHeight: 80,
    paddingTop: spacing.md,
  },
  createButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    padding: spacing.md + 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: spacing.sm,
    minHeight: 56,
    ...shadows.medium,
  },
  createButtonDisabled: {
    opacity: 0.7,
  },
  createButtonText: {
    ...typography.headline,
    color: '#fff',
    fontWeight: '600',
  },
  accessDenied: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  accessDeniedIcon: {
    fontSize: 64,
    marginBottom: spacing.md,
  },
  accessDeniedTitle: {
    ...typography.title2,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  accessDeniedText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: spacing.lg,
  },
  backButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.md,
  },
  backButtonText: {
    ...typography.headline,
    color: '#fff',
  },
  assignHint: {
    ...typography.caption1,
    color: colors.textTertiary,
    marginBottom: spacing.md,
  },
  selectAllButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  selectAllText: {
    ...typography.caption1,
    color: '#fff',
    fontWeight: '600',
  },
  tradeCheckbox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    minHeight: 56,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  tradeCheckboxSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight || '#E8F4FF',
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.borderLight,
    marginRight: spacing.md,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  checkboxChecked: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  checkmark: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  tradeInfo: {
    flex: 1,
  },
  tradeName: {
    ...typography.body,
    color: colors.text,
    fontWeight: '600',
  },
  tradeRole: {
    ...typography.caption1,
    color: colors.textTertiary,
    marginTop: 2,
  },
});
