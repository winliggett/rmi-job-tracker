const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Exclude server-side packages from the web bundle
config.resolver.blockList = [
  /node_modules\/twilio\/.*/,
  /node_modules\/@anthropic-ai\/.*/,
  /node_modules\/nodemailer\/.*/,
  /node_modules\/pg\/.*/,
  /node_modules\/bcryptjs\/.*/,
  /node_modules\/jsonwebtoken\/.*/,
  /node_modules\/multer\/.*/,
  /node_modules\/express\/.*/,
  /node_modules\/cors\/.*/,
  /node_modules\/dotenv\/.*/,
  /server\/.*/,
];

module.exports = config;
