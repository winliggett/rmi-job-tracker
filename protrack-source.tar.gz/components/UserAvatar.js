import React from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';

const TRADE_COLORS = {
  'Plumbing': '#60a5fa',
  'Electrical': '#fbbf24',
  'Framing': '#a78bfa',
  'Painting': '#f87171',
  'Tile': '#34d399',
  'HVAC': '#06b6d4',
  'Landscaping': '#84cc16',
  'Masonry': '#fb923c',
  'Roofing': '#78716c',
  'Drywall': '#94a3b8',
  'Carpentry': '#0891b2',
  'Flooring': '#a1a1aa'
};

const getInitials = (name) => {
  if (!name) return '?';
  const parts = name.trim().split(' ').filter(Boolean);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};

const getTradeColor = (trade) => {
  return TRADE_COLORS[trade] || '#9ca3af';
};

export default function UserAvatar({ user, size = 40 }) {
  const initials = getInitials(user?.name);
  const backgroundColor = getTradeColor(user?.trade);
  const fontSize = size * 0.4;

  if (user?.profile_picture_url) {
    return (
      <Image
        source={{ uri: user.profile_picture_url }}
        style={[
          styles.image,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
          }
        ]}
      />
    );
  }

  return (
    <View
      style={[
        styles.initialsContainer,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor,
        }
      ]}
    >
      <Text style={[styles.initials, { fontSize }]}>{initials}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  image: {
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  initialsContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  initials: {
    color: '#ffffff',
    fontWeight: '600',
  },
});
