import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  Modal,
  ActivityIndicator,
  Linking,
} from 'react-native';
import * as Haptics from '../utils/haptics';
import { apiRequest } from '../utils/api';
import { colors, typography, spacing, borderRadius, shadows } from '../utils/theme';
import { useToast } from './Toast';

const WIZARD_STEPS = {
  CREATE_ACCOUNT: 1,
  GET_CREDENTIALS: 2,
  GET_PHONE: 3,
  TEST: 4,
};

export default function NotificationSettings({ token }) {
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [emailStatus, setEmailStatus] = useState('not_configured');
  const [emailProvider, setEmailProvider] = useState(null);
  const [emailAddress, setEmailAddress] = useState('');
  
  const [smsStatus, setSmsStatus] = useState('not_configured');
  const [twilioPhone, setTwilioPhone] = useState('');
  
  const [showTwilioWizard, setShowTwilioWizard] = useState(false);
  const [twilioStep, setTwilioStep] = useState(WIZARD_STEPS.CREATE_ACCOUNT);
  const [twilioSid, setTwilioSid] = useState('');
  const [twilioToken, setTwilioToken] = useState('');
  const [twilioPhoneInput, setTwilioPhoneInput] = useState('');
  const [testPhone, setTestPhone] = useState('');
  const [testingTwilio, setTestingTwilio] = useState(false);
  
  const [showSmtpModal, setShowSmtpModal] = useState(false);
  const [smtpEmail, setSmtpEmail] = useState('');
  const [smtpServer, setSmtpServer] = useState('');
  const [smtpPort, setSmtpPort] = useState('587');
  const [smtpUsername, setSmtpUsername] = useState('');
  const [smtpPassword, setSmtpPassword] = useState('');
  const [testingSmtp, setTestingSmtp] = useState(false);

  useEffect(() => {
    loadNotificationConfig();
  }, []);

  const loadNotificationConfig = async () => {
    try {
      setLoading(true);
      const res = await apiRequest('/api/notifications/config', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      if (res.email?.configured) {
        setEmailStatus('configured');
        setEmailProvider(res.email.provider);
        setEmailAddress(res.email.address || '');
      }
      
      if (res.sms?.configured) {
        setSmsStatus('configured');
        setTwilioPhone(res.sms.phone || '');
      }
    } catch (error) {
      console.log('No notification config yet');
    } finally {
      setLoading(false);
    }
  };

  const handleTwilioNext = () => {
    if (twilioStep === WIZARD_STEPS.CREATE_ACCOUNT) {
      setTwilioStep(WIZARD_STEPS.GET_CREDENTIALS);
    } else if (twilioStep === WIZARD_STEPS.GET_CREDENTIALS) {
      if (!twilioSid.startsWith('AC') || !twilioToken) {
        toast.error('Please enter valid Twilio credentials');
        return;
      }
      setTwilioStep(WIZARD_STEPS.GET_PHONE);
    } else if (twilioStep === WIZARD_STEPS.GET_PHONE) {
      if (!twilioPhoneInput.startsWith('+')) {
        toast.error('Phone number must start with + (e.g., +12055551234)');
        return;
      }
      setTwilioStep(WIZARD_STEPS.TEST);
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleTwilioBack = () => {
    if (twilioStep > 1) {
      setTwilioStep(twilioStep - 1);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleTwilioTest = async () => {
    if (!testPhone) {
      toast.error('Enter a phone number to test');
      return;
    }
    
    setTestingTwilio(true);
    try {
      const res = await apiRequest('/api/notifications/test-sms', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          accountSid: twilioSid,
          authToken: twilioToken,
          fromPhone: twilioPhoneInput,
          toPhone: testPhone
        })
      });
      
      if (res.success) {
        toast.success('Test message sent!');
      } else {
        toast.error(res.error || 'Failed to send test message');
      }
    } catch (error) {
      toast.error('Failed to send test message');
    } finally {
      setTestingTwilio(false);
    }
  };

  const handleTwilioFinish = async () => {
    setSaving(true);
    try {
      await apiRequest('/api/notifications/config/sms', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          accountSid: twilioSid,
          authToken: twilioToken,
          fromPhone: twilioPhoneInput
        })
      });
      
      setSmsStatus('configured');
      setTwilioPhone(twilioPhoneInput);
      setShowTwilioWizard(false);
      toast.success('SMS notifications enabled!');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      toast.error('Failed to save Twilio configuration');
    } finally {
      setSaving(false);
    }
  };

  const handleSmtpTest = async () => {
    if (!smtpEmail || !smtpServer || !smtpUsername || !smtpPassword) {
      toast.error('Please fill in all fields');
      return;
    }
    
    setTestingSmtp(true);
    try {
      const res = await apiRequest('/api/notifications/test-email', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: smtpEmail,
          server: smtpServer,
          port: parseInt(smtpPort),
          username: smtpUsername,
          password: smtpPassword
        })
      });
      
      if (res.success) {
        toast.success('Connection successful!');
      } else {
        toast.error(res.error || 'Connection failed');
      }
    } catch (error) {
      toast.error('Connection test failed');
    } finally {
      setTestingSmtp(false);
    }
  };

  const handleSmtpSave = async () => {
    setSaving(true);
    try {
      await apiRequest('/api/notifications/config/email', {
        method: 'POST',
        headers: { 
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          provider: 'smtp',
          email: smtpEmail,
          server: smtpServer,
          port: parseInt(smtpPort),
          username: smtpUsername,
          password: smtpPassword
        })
      });
      
      setEmailStatus('configured');
      setEmailProvider('smtp');
      setEmailAddress(smtpEmail);
      setShowSmtpModal(false);
      toast.success('Email notifications enabled!');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      toast.error('Failed to save email configuration');
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnectEmail = async () => {
    setSaving(true);
    try {
      await apiRequest('/api/notifications/config/email', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setEmailStatus('not_configured');
      setEmailProvider(null);
      setEmailAddress('');
      toast.success('Email disconnected');
    } catch (error) {
      toast.error('Failed to disconnect');
    } finally {
      setSaving(false);
    }
  };

  const handleDisconnectSms = async () => {
    setSaving(true);
    try {
      await apiRequest('/api/notifications/config/sms', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setSmsStatus('not_configured');
      setTwilioPhone('');
      toast.success('SMS disconnected');
    } catch (error) {
      toast.error('Failed to disconnect');
    } finally {
      setSaving(false);
    }
  };

  const handleSendTestEmail = async () => {
    try {
      const res = await apiRequest('/api/notifications/send-test-email', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.success) {
        toast.success('Test email sent!');
      } else {
        toast.error(res.error || 'Failed to send');
      }
    } catch (error) {
      toast.error('Failed to send test email');
    }
  };

  const handleSendTestSms = async () => {
    try {
      const res = await apiRequest('/api/notifications/send-test-sms', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.success) {
        toast.success('Test SMS sent!');
      } else {
        toast.error(res.error || 'Failed to send');
      }
    } catch (error) {
      toast.error('Failed to send test SMS');
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="small" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionIcon}>📧</Text>
          <Text style={styles.sectionTitle}>Email Notifications</Text>
        </View>
        
        {emailStatus === 'configured' ? (
          <View style={styles.configuredBox}>
            <Text style={styles.configuredStatus}>✅ Connected as {emailAddress}</Text>
            <View style={styles.configuredActions}>
              <TouchableOpacity style={styles.testButton} onPress={handleSendTestEmail}>
                <Text style={styles.testButtonText}>Send Test</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.disconnectButton} onPress={handleDisconnectEmail}>
                <Text style={styles.disconnectButtonText}>Disconnect</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.notConfiguredBox}>
            <Text style={styles.notConfiguredStatus}>❌ Not configured</Text>
            <Text style={styles.helpText}>
              To send email notifications, connect your email account:
            </Text>
            <View style={styles.buttonRow}>
              <TouchableOpacity 
                style={styles.providerButton}
                onPress={() => {
                  setSmtpServer('smtp.gmail.com');
                  setSmtpPort('587');
                  setSmtpEmail('');
                  setSmtpUsername('');
                  setSmtpPassword('');
                  setShowSmtpModal(true);
                }}
              >
                <Text style={styles.providerButtonText}>Use Gmail</Text>
                <Text style={styles.comingSoon}>App Password required</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.providerButton}
                onPress={() => {
                  setSmtpServer('smtp.office365.com');
                  setSmtpPort('587');
                  setSmtpEmail('');
                  setSmtpUsername('');
                  setSmtpPassword('');
                  setShowSmtpModal(true);
                }}
              >
                <Text style={styles.providerButtonText}>Use Outlook</Text>
                <Text style={styles.comingSoon}>App Password required</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.providerButton}
                onPress={() => {
                  setSmtpServer('');
                  setSmtpPort('587');
                  setSmtpEmail('');
                  setSmtpUsername('');
                  setSmtpPassword('');
                  setShowSmtpModal(true);
                }}
              >
                <Text style={styles.providerButtonText}>Other Email</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>

      <View style={styles.divider} />

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionIcon}>📱</Text>
          <Text style={styles.sectionTitle}>SMS Text Notifications</Text>
        </View>
        
        {smsStatus === 'configured' ? (
          <View style={styles.configuredBox}>
            <Text style={styles.configuredStatus}>✅ Active - sending from {twilioPhone}</Text>
            <View style={styles.configuredActions}>
              <TouchableOpacity style={styles.testButton} onPress={handleSendTestSms}>
                <Text style={styles.testButtonText}>Send Test</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.disconnectButton} onPress={handleDisconnectSms}>
                <Text style={styles.disconnectButtonText}>Disconnect</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.notConfiguredBox}>
            <Text style={styles.notConfiguredStatus}>❌ Not configured</Text>
            <Text style={styles.helpText}>
              To send text message notifications, you need a Twilio account.
            </Text>
            <Text style={styles.costText}>
              Cost: ~$1/month + $0.01 per text
            </Text>
            <TouchableOpacity 
              style={styles.setupButton}
              onPress={() => {
                setTwilioStep(WIZARD_STEPS.CREATE_ACCOUNT);
                setShowTwilioWizard(true);
              }}
            >
              <Text style={styles.setupButtonText}>Setup Twilio</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <Modal visible={showTwilioWizard} animationType="slide" transparent onRequestClose={() => setShowTwilioWizard(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowTwilioWizard(false)}>
          <TouchableOpacity style={styles.wizardModal} activeOpacity={1} onPress={(e) => e.stopPropagation()}>
            <View style={styles.wizardHeader}>
              <Text style={styles.wizardTitle}>SMS Setup</Text>
              <Text style={styles.wizardStep}>Step {twilioStep} of 4</Text>
            </View>
            
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${(twilioStep / 4) * 100}%` }]} />
            </View>

            <ScrollView style={styles.wizardContent}>
              {twilioStep === WIZARD_STEPS.CREATE_ACCOUNT && (
                <View>
                  <Text style={styles.wizardStepTitle}>Create Twilio Account</Text>
                  <Text style={styles.wizardText}>
                    Twilio is a service that sends text messages. It costs about $1/month + $0.01 per text.
                  </Text>
                  <View style={styles.wizardSteps}>
                    <Text style={styles.wizardStepItem}>1. Go to twilio.com/try-twilio</Text>
                    <Text style={styles.wizardStepItem}>2. Sign up for free (no credit card needed to start)</Text>
                    <Text style={styles.wizardStepItem}>3. Verify your email and phone number</Text>
                  </View>
                  <TouchableOpacity 
                    style={styles.linkButton}
                    onPress={() => Linking.openURL('https://www.twilio.com/try-twilio')}
                  >
                    <Text style={styles.linkButtonText}>Open Twilio Website →</Text>
                  </TouchableOpacity>
                </View>
              )}

              {twilioStep === WIZARD_STEPS.GET_CREDENTIALS && (
                <View>
                  <Text style={styles.wizardStepTitle}>Get Your Credentials</Text>
                  <Text style={styles.wizardText}>
                    On your Twilio dashboard, you'll see Account SID and Auth Token
                  </Text>
                  
                  <Text style={styles.inputLabel}>Account SID</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="starts with AC..."
                    placeholderTextColor={colors.textTertiary}
                    value={twilioSid}
                    onChangeText={setTwilioSid}
                    autoCapitalize="none"
                  />
                  
                  <Text style={styles.inputLabel}>Auth Token</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="click 'Show' on Twilio to reveal it"
                    placeholderTextColor={colors.textTertiary}
                    value={twilioToken}
                    onChangeText={setTwilioToken}
                    secureTextEntry
                  />
                </View>
              )}

              {twilioStep === WIZARD_STEPS.GET_PHONE && (
                <View>
                  <Text style={styles.wizardStepTitle}>Get a Phone Number</Text>
                  <Text style={styles.wizardText}>
                    In Twilio, go to Phone Numbers → Buy a Number
                  </Text>
                  <View style={styles.wizardSteps}>
                    <Text style={styles.wizardStepItem}>1. Click "Get your first Twilio phone number"</Text>
                    <Text style={styles.wizardStepItem}>2. Copy the number you receive</Text>
                  </View>
                  
                  <Text style={styles.inputLabel}>Phone Number</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="+12055551234"
                    placeholderTextColor={colors.textTertiary}
                    value={twilioPhoneInput}
                    onChangeText={setTwilioPhoneInput}
                    keyboardType="phone-pad"
                  />
                </View>
              )}

              {twilioStep === WIZARD_STEPS.TEST && (
                <View>
                  <Text style={styles.wizardStepTitle}>Test It!</Text>
                  <Text style={styles.wizardText}>
                    Let's make sure it works. Enter your phone number to receive a test message.
                  </Text>
                  
                  <Text style={styles.inputLabel}>Send test text to:</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="your phone number"
                    placeholderTextColor={colors.textTertiary}
                    value={testPhone}
                    onChangeText={setTestPhone}
                    keyboardType="phone-pad"
                  />
                  
                  <TouchableOpacity 
                    style={styles.testSmsButton}
                    onPress={handleTwilioTest}
                    disabled={testingTwilio}
                  >
                    {testingTwilio ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Text style={styles.testSmsButtonText}>Send Test Message</Text>
                    )}
                  </TouchableOpacity>
                </View>
              )}
            </ScrollView>

            <View style={styles.wizardFooter}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setShowTwilioWizard(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <View style={styles.wizardNavButtons}>
                {twilioStep > 1 && (
                  <TouchableOpacity style={styles.backButton} onPress={handleTwilioBack}>
                    <Text style={styles.backButtonText}>← Back</Text>
                  </TouchableOpacity>
                )}
                
                {twilioStep < 4 ? (
                  <TouchableOpacity style={styles.nextButton} onPress={handleTwilioNext}>
                    <Text style={styles.nextButtonText}>Next →</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity 
                    style={[styles.finishButton, saving && styles.buttonDisabled]}
                    onPress={handleTwilioFinish}
                    disabled={saving}
                  >
                    {saving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <Text style={styles.finishButtonText}>Finish</Text>
                    )}
                  </TouchableOpacity>
                )}
              </View>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      <Modal visible={showSmtpModal} animationType="slide" transparent onRequestClose={() => setShowSmtpModal(false)}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setShowSmtpModal(false)}>
          <TouchableOpacity style={styles.smtpModal} activeOpacity={1} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.modalTitle}>Email Setup (SMTP)</Text>
            <Text style={styles.wizardText}>
              Enter your email server settings. If you're not sure, contact your email provider.
            </Text>
            
            <ScrollView style={styles.smtpForm}>
              <Text style={styles.inputLabel}>Email Address</Text>
              <TextInput
                style={styles.input}
                placeholder="your@email.com"
                placeholderTextColor={colors.textTertiary}
                value={smtpEmail}
                onChangeText={setSmtpEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
              
              <Text style={styles.inputLabel}>SMTP Server</Text>
              <TextInput
                style={styles.input}
                placeholder="smtp.gmail.com"
                placeholderTextColor={colors.textTertiary}
                value={smtpServer}
                onChangeText={setSmtpServer}
                autoCapitalize="none"
              />
              
              <Text style={styles.inputLabel}>Port</Text>
              <TextInput
                style={styles.input}
                placeholder="587"
                placeholderTextColor={colors.textTertiary}
                value={smtpPort}
                onChangeText={setSmtpPort}
                keyboardType="number-pad"
              />
              
              <Text style={styles.inputLabel}>Username</Text>
              <TextInput
                style={styles.input}
                placeholder="usually your email"
                placeholderTextColor={colors.textTertiary}
                value={smtpUsername}
                onChangeText={setSmtpUsername}
                autoCapitalize="none"
              />
              
              <Text style={styles.inputLabel}>Password</Text>
              <TextInput
                style={styles.input}
                placeholder="app password recommended"
                placeholderTextColor={colors.textTertiary}
                value={smtpPassword}
                onChangeText={setSmtpPassword}
                secureTextEntry
              />
              
              <View style={styles.smtpHint}>
                {smtpServer.includes('gmail') ? (
                  <>
                    <Text style={styles.hintText}>
                      ℹ️ Gmail requires an "App Password" (not your regular password)
                    </Text>
                    <Text style={styles.hintSteps}>
                      1. Go to Google Account → Security{'\n'}
                      2. Enable 2-Step Verification{'\n'}
                      3. Create an App Password for "Mail"
                    </Text>
                    <TouchableOpacity 
                      onPress={() => Linking.openURL('https://myaccount.google.com/apppasswords')}
                    >
                      <Text style={styles.hintLink}>Create Gmail App Password →</Text>
                    </TouchableOpacity>
                  </>
                ) : smtpServer.includes('office365') || smtpServer.includes('outlook') ? (
                  <>
                    <Text style={styles.hintText}>
                      ℹ️ Outlook/Office365 requires an "App Password"
                    </Text>
                    <Text style={styles.hintSteps}>
                      1. Go to Microsoft Account → Security{'\n'}
                      2. Enable Two-Step Verification{'\n'}
                      3. Create an App Password
                    </Text>
                    <TouchableOpacity 
                      onPress={() => Linking.openURL('https://account.live.com/proofs/AppPassword')}
                    >
                      <Text style={styles.hintLink}>Create Outlook App Password →</Text>
                    </TouchableOpacity>
                  </>
                ) : (
                  <Text style={styles.hintText}>
                    ℹ️ Tip: Use an "App Password" instead of your regular password for better security
                  </Text>
                )}
              </View>
            </ScrollView>

            <View style={styles.smtpFooter}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setShowSmtpModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <View style={styles.smtpActions}>
                <TouchableOpacity 
                  style={[styles.testConnectionButton, (!smtpEmail || !smtpServer || !smtpPort || !smtpUsername || !smtpPassword) && styles.buttonDisabled]}
                  onPress={handleSmtpTest}
                  disabled={testingSmtp || !smtpEmail || !smtpServer || !smtpPort || !smtpUsername || !smtpPassword}
                >
                  {testingSmtp ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : (
                    <Text style={[styles.testConnectionText, (!smtpEmail || !smtpServer || !smtpPort || !smtpUsername || !smtpPassword) && styles.disabledText]}>Test Connection</Text>
                  )}
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[styles.saveButton, (saving || !smtpEmail || !smtpServer || !smtpPort || !smtpUsername || !smtpPassword) && styles.buttonDisabled]}
                  onPress={handleSmtpSave}
                  disabled={saving || !smtpEmail || !smtpServer || !smtpPort || !smtpUsername || !smtpPassword}
                >
                  {saving ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <Text style={styles.saveButtonText}>Save</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.backgroundSecondary || '#ffffff',
    borderRadius: borderRadius?.lg || 16,
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08), 0 1px 2px rgba(0, 0, 0, 0.06)',
    padding: spacing?.lg || 24,
  },
  loadingContainer: {
    padding: spacing.xl,
    alignItems: 'center',
  },
  section: {
    marginBottom: spacing.md,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  sectionIcon: {
    fontSize: 24,
    marginRight: spacing.sm,
  },
  sectionTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.lg,
  },
  configuredBox: {
    backgroundColor: '#e8f5e9',
    borderRadius: borderRadius.md,
    padding: spacing.md,
  },
  configuredStatus: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: '#2e7d32',
    marginBottom: spacing.sm,
  },
  configuredActions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  testButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
  },
  testButtonText: {
    color: '#fff',
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },
  disconnectButton: {
    backgroundColor: '#fff',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  disconnectButtonText: {
    color: colors.textSecondary,
    fontSize: typography.sizes.sm,
  },
  notConfiguredBox: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
  },
  notConfiguredStatus: {
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  helpText: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.md,
    lineHeight: 20,
  },
  costText: {
    fontSize: typography.sizes.sm,
    color: colors.textTertiary,
    marginBottom: spacing.md,
  },
  buttonRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  providerButton: {
    backgroundColor: '#fff',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  providerButtonText: {
    color: colors.primary,
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },
  disabledButton: {
    borderColor: colors.border,
    opacity: 0.6,
  },
  comingSoon: {
    fontSize: typography.sizes.xs,
    color: colors.textTertiary,
    marginTop: 2,
  },
  setupButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignSelf: 'flex-start',
  },
  setupButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  wizardModal: {
    backgroundColor: '#fff',
    borderRadius: borderRadius.xl,
    width: '100%',
    maxWidth: 500,
    maxHeight: '90%',
  },
  wizardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  wizardTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
  },
  wizardStep: {
    fontSize: typography.sizes.sm,
    color: colors.textSecondary,
  },
  progressBar: {
    height: 4,
    backgroundColor: colors.border,
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
  },
  wizardContent: {
    padding: spacing.lg,
    maxHeight: 400,
  },
  wizardStepTitle: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
    marginBottom: spacing.md,
  },
  wizardText: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
    lineHeight: 24,
    marginBottom: spacing.md,
  },
  wizardSteps: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  wizardStepItem: {
    fontSize: typography.sizes.md,
    color: colors.text,
    lineHeight: 28,
  },
  linkButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignSelf: 'flex-start',
  },
  linkButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
  },
  inputLabel: {
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
    color: colors.text,
    marginBottom: spacing.xs,
    marginTop: spacing.md,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    fontSize: typography.sizes.md,
    color: colors.text,
    backgroundColor: '#fff',
  },
  testSmsButton: {
    backgroundColor: '#4caf50',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  testSmsButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
  },
  wizardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  wizardNavButtons: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  cancelButton: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  cancelButtonText: {
    color: colors.textSecondary,
    fontSize: typography.sizes.md,
  },
  backButton: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  backButtonText: {
    color: colors.primary,
    fontSize: typography.sizes.md,
  },
  nextButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
  },
  nextButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
  },
  finishButton: {
    backgroundColor: '#4caf50',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
  },
  finishButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.semibold,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  disabledText: {
    opacity: 0.5,
  },
  smtpModal: {
    backgroundColor: '#fff',
    borderRadius: borderRadius.xl,
    width: '100%',
    maxWidth: 500,
    maxHeight: '90%',
  },
  modalTitle: {
    fontSize: typography.sizes.xl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  smtpForm: {
    padding: spacing.lg,
    maxHeight: 400,
  },
  smtpHint: {
    backgroundColor: '#fff3cd',
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginTop: spacing.lg,
  },
  hintText: {
    fontSize: typography.sizes.sm,
    color: '#856404',
    lineHeight: 20,
  },
  hintSteps: {
    fontSize: typography.sizes.sm,
    color: '#856404',
    lineHeight: 22,
    marginTop: spacing.xs,
    marginBottom: spacing.sm,
  },
  hintLink: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
    marginTop: spacing.xs,
    textDecorationLine: 'underline',
  },
  smtpFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  smtpActions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  testConnectionButton: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: borderRadius.md,
  },
  testConnectionText: {
    color: colors.primary,
    fontSize: typography.sizes.sm,
    fontWeight: typography.weights.medium,
  },
  saveButton: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.md,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: typography.sizes.md,
    fontWeight: typography.weights.medium,
  },
});
