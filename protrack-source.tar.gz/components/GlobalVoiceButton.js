import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  DeviceEventEmitter,
  ActivityIndicator,
  Animated,
  Platform,
  TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { navigationRef } from '../utils/navigation';
import api from '../utils/api';
import * as Haptics from '../utils/haptics';
import { shadows, colors } from '../utils/theme';
import { useUser } from '../contexts/UserContext';
import { useCompany } from '../contexts/CompanyContext';
import { useVoiceToast } from './VoiceToast';

import { VOICE_REFRESH_EVENT } from '../utils/events';

const { width: screenWidth } = Dimensions.get('window');
const isMobile = screenWidth <= 768;

const SpeechRecognition = Platform.OS === 'web' 
  ? window.SpeechRecognition || window.webkitSpeechRecognition
  : null;

const MAX_RECORDING_SECONDS = 300;
const isAndroid = Platform.OS === 'android' || (Platform.OS === 'web' && typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent));


export default function GlobalVoiceButton({ navigation: navProp, currentJobId, onRefresh, onTeamRefresh }) {
  const navHook = useNavigation();
  const navigation = navProp || navHook;
  const { user, isAdmin, token: userToken } = useUser();
  const { settings } = useCompany();
  const toast = useVoiceToast();
  
  const [jobs, setJobs] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [token, setToken] = useState(null);
  
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [showTextInput, setShowTextInput] = useState(false);
  const [manualText, setManualText] = useState('');
  
  const recognitionRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const timerRef = useRef(null);
  const autoStopRef = useRef(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      terminateRecognition();
    };
  }, []);

  const terminateRecognition = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (autoStopRef.current) {
      clearTimeout(autoStopRef.current);
      autoStopRef.current = null;
    }
    
    const recog = recognitionRef.current;
    if (recog) {
      recognitionRef.current = null;
      try { recog.abort(); } catch (e) {}
      try { recog.stop(); } catch (e) {}
      try {
        recog.onstart = null;
        recog.onresult = null;
        recog.onerror = null;
        recog.onend = null;
      } catch (e) {}
    }
    
    const stream = mediaStreamRef.current;
    if (stream) {
      mediaStreamRef.current = null;
      try {
        stream.getTracks().forEach(track => track.stop());
      } catch (e) {}
    }
    
    if (mountedRef.current) {
      setIsListening(false);
      setRecordingSeconds(0);
    }
  }, []);

  useEffect(() => {
    if (isListening) {
      const pulse = () => {
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.3,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }),
        ]).start(() => {
          if (isListening) pulse();
        });
      };
      pulse();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isListening, pulseAnim]);

  useEffect(() => {
    if (isListening) {
      timerRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isListening]);

  const reloadTeam = useCallback(async () => {
    try {
      const storedToken = token || await AsyncStorage.getItem('token');
      if (storedToken) {
        const usersData = await api.getTradeUsers(storedToken);
        const teamData = usersData?.trades || usersData || [];
        const freshTeam = Array.isArray(teamData) ? teamData : [];
        setTeamMembers(freshTeam);
        return freshTeam;
      }
    } catch (error) {
      console.error('Failed to reload team:', error);
    }
    return null;
  }, [token]);

  useEffect(() => {
    const loadContext = async () => {
      if (!isAdmin()) return;
      
      try {
        const storedToken = await AsyncStorage.getItem('token');
        setToken(storedToken);
        
        if (storedToken) {
          const [jobsData, usersData] = await Promise.all([
            api.getJobs(storedToken, {}),
            api.getTradeUsers(storedToken)
          ]);
          
          setJobs(Array.isArray(jobsData) ? jobsData : []);
          
          const teamData = usersData?.trades || usersData || [];
          setTeamMembers(Array.isArray(teamData) ? teamData : []);
        }
      } catch (error) {
        console.error('Failed to load voice context:', error);
      }
    };
    
    loadContext();
  }, [user]);

  const findJobMatches = useCallback((identifier) => {
    console.log('findJobMatches called with:', identifier, 'currentJobId:', currentJobId, 'jobs count:', jobs.length);
    
    if (!identifier) {
      if (currentJobId) {
        const job = jobs.find(j => j.id === currentJobId);
        console.log('Found job by currentJobId:', job?.id);
        return job ? [job] : [];
      }
      return [];
    }
    
    const searchTerm = identifier.toLowerCase().trim();
    const matches = [];
    
    for (const j of jobs) {
      const clientName = (j.client_name || j.customer_name || '').toLowerCase();
      const address = (j.address || '').toLowerCase();
      const jobNumber = (j.job_number || '').toLowerCase();
      
      // Exact match (highest priority)
      if (clientName === searchTerm || address === searchTerm) {
        matches.unshift(j);
        continue;
      }
      
      // Partial match - check customer name, address, first word, job number
      const firstWord = clientName.split(' ')[0];
      if (
        clientName.includes(searchTerm) || 
        searchTerm.includes(clientName) ||
        address.includes(searchTerm) ||
        firstWord === searchTerm ||
        jobNumber.includes(searchTerm)
      ) {
        matches.push(j);
      }
    }
    
    console.log('Found job matches:', matches.length, 'search term:', searchTerm);
    return matches;
  }, [jobs, currentJobId]);
  
  const findJob = useCallback((identifier) => {
    const matches = findJobMatches(identifier);
    return matches.length > 0 ? matches[0] : null;
  }, [findJobMatches]);

  const findPersonMatches = useCallback((name, liveTeam = null) => {
    if (!name) return [];
    const searchList = liveTeam || teamMembers;
    const searchTerm = name.toLowerCase().trim();
    const matches = [];
    
    // Phonetic/nickname mappings
    const nicknames = {
      'win': ['wynn', 'wyn', 'winn', 'when'],
      'bob': ['bobby', 'robert', 'rob'],
      'joe': ['joey', 'joseph'],
      'mike': ['michael', 'mikey'],
      'bill': ['billy', 'william', 'will'],
      'lee': ['leigh', 'li'],
      'rosa': ['rosales', 'rose'],
      'eric': ['erik', 'erick'],
    };
    
    for (const person of searchList) {
      const fullName = person.name.toLowerCase();
      const firstName = fullName.split(' ')[0];
      const lastName = fullName.split(' ').slice(-1)[0];
      
      // Exact or partial match
      if (
        fullName === searchTerm ||
        fullName.includes(searchTerm) ||
        searchTerm.includes(firstName) ||
        firstName === searchTerm ||
        lastName === searchTerm ||
        firstName.startsWith(searchTerm) ||
        lastName.startsWith(searchTerm)
      ) {
        matches.push(person);
        continue;
      }
      
      // Nickname/phonetic match
      for (const [canonical, variants] of Object.entries(nicknames)) {
        if (
          (firstName === canonical || variants.includes(firstName)) &&
          (searchTerm === canonical || variants.includes(searchTerm))
        ) {
          matches.push(person);
          break;
        }
      }
    }
    
    console.log('Found person matches:', matches.length, 'search term:', searchTerm);
    return matches;
  }, [teamMembers]);

  const findPerson = useCallback((name, liveTeam = null) => {
    const matches = findPersonMatches(name, liveTeam);
    return matches.length > 0 ? matches[0] : null;
  }, [findPersonMatches]);

  const handleUndo = useCallback(async () => {
    try {
      const storedToken = await AsyncStorage.getItem('token');
      const response = await fetch('/api/undo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${storedToken}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        toast.showSuccess(data.message || 'Action undone');
        DeviceEventEmitter.emit(VOICE_REFRESH_EVENT);
        onRefresh?.();
      } else {
        toast.showError('Could not undo');
      }
    } catch (error) {
      console.error('Undo failed:', error);
      toast.showError('Undo failed');
    }
  }, [toast, onRefresh]);

  const executeCommand = useCallback(async (cmd, liveTeam = null, resolvedJob = null, resolvedPerson = null) => {
    console.log('=== VOICE COMMAND EXECUTION ===');
    console.log('Raw command:', JSON.stringify(cmd, null, 2));
    
    const storedToken = await AsyncStorage.getItem('token');
    if (!storedToken) throw new Error('Not logged in');
    
    const jobSearch = cmd.job_identifier || cmd.job_name || cmd.job_address;
    const personSearch = cmd.assignee || cmd.person;
    console.log('Job search term:', jobSearch || '(none - using current job)');
    console.log('Person search term:', personSearch);
    
    // Use resolved values or find matches
    const jobMatches = resolvedJob ? [resolvedJob] : findJobMatches(jobSearch);
    const personMatches = resolvedPerson ? [resolvedPerson] : findPersonMatches(personSearch, liveTeam);
    
    console.log('Job matches found:', jobMatches.length, jobMatches.map(j => j.client_name || j.customer_name));
    console.log('Person matches found:', personMatches.length, personMatches.map(p => p.name));
    
    const job = jobMatches[0] || null;
    const person = personMatches[0] || null;
    
    // Handle ambiguity - multiple matches
    if (jobMatches.length > 1 && ['add_task', 'add_note', 'change_status', 'toggle_urgent'].includes(cmd.action)) {
      console.log('Multiple job matches - need picker');
      return { 
        needsPicker: true, 
        type: 'job',
        message: 'Which job?',
        options: jobMatches.slice(0, 5).map(j => ({
          label: j.client_name || j.customer_name || j.address,
          value: j
        })),
        cmd,
        liveTeam
      };
    }
    
    if (personMatches.length > 1 && ['add_task', 'assign_job'].includes(cmd.action)) {
      console.log('Multiple person matches - need picker');
      return {
        needsPicker: true,
        type: 'person', 
        message: 'Which team member?',
        options: personMatches.slice(0, 5).map(p => ({
          label: p.name,
          value: p
        })),
        cmd,
        liveTeam
      };
    }

    switch (cmd.action) {
      case 'add_task':
        if (!job) {
          console.log('ERROR: Job not found for search:', jobSearch);
          throw new Error(`Couldn't find job "${jobSearch || 'current'}". Try saying the client name or address.`);
        }
        if (!person) {
          console.log('ERROR: Person not found for search:', personSearch);
          throw new Error(`Couldn't find "${personSearch}". Check team member spelling.`);
        }
        console.log('Creating task:', cmd.content, 'for', person.name, 'on job', job.id);
        await api.createTask(storedToken, job.id, cmd.content, person.id, 'voice');
        return { msg: `Task assigned to ${person.name}` };
        
      case 'add_note':
        if (!job) throw new Error('Job not found');
        await api.addNote(storedToken, job.id, cmd.content);
        return { msg: 'Note added' };
        
      case 'change_status':
        if (!job) throw new Error('Job not found');
        await api.updateJobStatus(storedToken, job.id, cmd.status);
        return { msg: `Status changed to ${cmd.status}` };
        
      case 'toggle_urgent':
        if (!job) throw new Error('Job not found');
        await api.updateJob(storedToken, job.id, { is_urgent: cmd.urgent });
        return { msg: cmd.urgent ? 'Marked urgent' : 'Removed urgent' };
        
      case 'create_job':
        const newJob = await api.createJob(storedToken, {
          client_name: cmd.client_name || cmd.customerName,
          address: cmd.address || '',
          status: 'active'
        });
        return { msg: `Job created for ${cmd.client_name || cmd.customerName}`, jobId: newJob.id };
        
      case 'navigate':
        if (cmd.destination === 'dashboard') {
          navigation.navigate('Dashboard');
        } else if (cmd.destination === 'settings') {
          navigation.navigate('Settings');
        } else if (cmd.job_id || cmd.job_name) {
          const targetJob = findJob(cmd.job_name) || jobs.find(j => j.id === cmd.job_id);
          if (targetJob) {
            navigation.navigate('JobDetails', { jobId: targetJob.id });
          }
        }
        return { msg: `Navigating to ${cmd.destination || 'job'}` };
        
      case 'add_team_member':
        await api.createUser(storedToken, {
          username: cmd.name.toLowerCase().replace(/\s+/g, '_'),
          name: cmd.name,
          trade: cmd.trade || '',
          role: 'trade'
        });
        onTeamRefresh?.();
        return { msg: `Added ${cmd.name} to team` };
        
      case 'remove_team_member':
        const memberToRemove = findPerson(cmd.name, liveTeam);
        if (!memberToRemove) throw new Error('Team member not found');
        await api.deleteUser(storedToken, memberToRemove.id);
        onTeamRefresh?.();
        return { msg: `Removed ${memberToRemove.name}` };
        
      case 'edit_job':
        if (!job) throw new Error('Job not found');
        const updates = {};
        if (cmd.address) updates.address = cmd.address;
        if (cmd.client_name) updates.client_name = cmd.client_name;
        if (cmd.door_code) updates.door_code = cmd.door_code;
        await api.updateJob(storedToken, job.id, updates);
        return { msg: 'Job updated' };
        
      default:
        throw new Error("I didn't understand that");
    }
  }, [findJob, findJobMatches, findPerson, findPersonMatches, jobs, navigation, onTeamRefresh]);

  const handlePickerSelection = useCallback(async (pickerResult, selectedValue) => {
    console.log('Picker selection:', selectedValue.label || selectedValue.name);
    try {
      let result;
      if (pickerResult.type === 'job') {
        result = await executeCommand(pickerResult.cmd, pickerResult.liveTeam, selectedValue, null);
      } else {
        result = await executeCommand(pickerResult.cmd, pickerResult.liveTeam, null, selectedValue);
      }
      
      if (result.needsPicker) {
        // Nested picker needed
        toast.showPicker(result.message, result.options, (selected) => handlePickerSelection(result, selected));
      } else {
        toast.showSuccess(result.msg, handleUndo);
        DeviceEventEmitter.emit(VOICE_REFRESH_EVENT);
        onRefresh?.();
      }
    } catch (err) {
      toast.showError(err.message || 'Command failed');
    }
  }, [executeCommand, toast, handleUndo, onRefresh]);

  const handleVoiceResult = useCallback(async (parsed) => {
    console.log('=== VOICE RESULT PROCESSING ===');
    console.log('Parsed result:', JSON.stringify(parsed, null, 2));
    
    const commands = parsed.commands || [parsed];
    
    let liveTeam = teamMembers;
    
    for (const cmd of commands) {
      if (cmd.action === 'add_team_member') {
        try {
          const result = await executeCommand(cmd, liveTeam);
          if (result.needsPicker) {
            toast.showPicker(result.message, result.options, (selected) => handlePickerSelection(result, selected));
            return;
          }
          toast.showSuccess(result.msg, handleUndo);
          const freshTeam = await reloadTeam();
          if (freshTeam) liveTeam = freshTeam;
        } catch (err) {
          console.error('Command failed:', err.message);
          toast.showError(err.message || 'Command failed');
          break;
        }
        continue;
      }
      
      try {
        const result = await executeCommand(cmd, liveTeam);
        if (result.needsPicker) {
          toast.showPicker(result.message, result.options, (selected) => handlePickerSelection(result, selected));
          return;
        }
        toast.showSuccess(result.msg, handleUndo);
      } catch (err) {
        console.error('Command failed:', err.message);
        toast.showError(err.message || 'Command failed');
        break;
      }
    }
    
    DeviceEventEmitter.emit(VOICE_REFRESH_EVENT);
    onRefresh?.();
  }, [executeCommand, toast, handleUndo, teamMembers, reloadTeam, onRefresh, handlePickerSelection]);

  const processWithAI = async (text) => {
    if (!text.trim()) {
      setError('No speech detected');
      return;
    }
    
    setProcessing(true);
    setError(null);
    
    console.log('=== VOICE COMMAND STARTED ===');
    console.log('Raw transcription:', text);
    
    try {
      const storedToken = await AsyncStorage.getItem('token');
      
      // Get current job info if viewing one
      const currentJob = currentJobId ? jobs.find(j => j.id === currentJobId) : null;
      const currentJobInfo = currentJob ? {
        id: currentJob.id,
        name: currentJob.client_name || currentJob.customer_name,
        address: currentJob.address
      } : null;
      
      console.log('Current job context:', currentJobInfo);
      console.log('Available jobs:', jobs.length);
      console.log('Available team members:', teamMembers.length);
      
      const response = await fetch('/api/voice/parse', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${storedToken}`
        },
        body: JSON.stringify({ 
          transcript: text,
          jobId: currentJobId,
          currentJob: currentJobInfo,
          context: {
            currentJobId,
            currentJob: currentJobInfo,
            teamMembers: teamMembers.map(t => ({ id: t.id, name: t.name })),
            jobs: jobs.map(j => ({ id: j.id, client_name: j.client_name || j.customer_name, address: j.address }))
          }
        })
      });
      
      const data = await response.json();
      console.log('Claude parsed result:', JSON.stringify(data, null, 2));
      
      const commands = data.commands || [data];
      
      if (!commands.length || commands[0].action === 'unknown') {
        console.log('ERROR: Command not understood');
        toast.showError("I didn't understand that — try again");
        return;
      }
      
      const cmd = commands[0];
      if (cmd.clarification_needed) {
        console.log('Clarification needed:', cmd.clarification_needed);
        toast.showWarning(cmd.clarification_needed);
        return;
      }
      
      await handleVoiceResult({ commands, originalText: text });
      
    } catch (err) {
      console.error('Parse error:', err);
      toast.showError("Something went wrong — try again");
    } finally {
      setProcessing(false);
      setShowTextInput(false);
      setManualText('');
    }
  };

  const startListening = async () => {
    if (isListening || processing) return;
    terminateRecognition();
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      
      if (!SpeechRecognition) {
        setError('Voice not available in this browser');
        terminateRecognition();
        return;
      }
      
      const recog = new SpeechRecognition();
      recog.continuous = true;
      recog.interimResults = true;
      recog.lang = 'en-US';
      recog.maxAlternatives = 1;

      recog.onstart = () => {
        if (mountedRef.current) {
          setIsListening(true);
          setError(null);
          setTranscript('');
          setRecordingSeconds(0);
        }
      };

      recog.onresult = (event) => {
        let fullTranscript = '';
        for (let i = 0; i < event.results.length; i++) {
          fullTranscript += event.results[i][0].transcript;
        }
        if (fullTranscript && mountedRef.current) {
          setTranscript(fullTranscript);
        }
      };

      recog.onerror = (event) => {
        if (!mountedRef.current) return;
        switch (event.error) {
          case 'not-allowed':
            setError('Microphone access denied');
            break;
          case 'no-speech':
            setError('No speech detected');
            break;
          case 'aborted':
            break;
          default:
            setError('Could not hear you');
        }
        setIsListening(false);
        setProcessing(false);
        terminateRecognition();
      };

      recog.onend = () => {
        if (mountedRef.current) {
          setIsListening(false);
        }
        terminateRecognition();
      };

      recognitionRef.current = recog;
      
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      setError(null);
      setTranscript('');
      
      autoStopRef.current = setTimeout(() => {
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }
      }, MAX_RECORDING_SECONDS * 1000);
      
      recog.start();
      
    } catch (err) {
      console.error('Microphone error:', err);
      setError('Please allow microphone access');
      terminateRecognition();
    }
  };

  const stopAndProcess = () => {
    const currentTranscript = transcript;
    
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
    terminateRecognition();
    
    if (currentTranscript && currentTranscript.trim()) {
      processWithAI(currentTranscript.trim());
    } else {
      setError('No speech detected');
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleManualSubmit = () => {
    if (!manualText.trim()) return;
    processWithAI(manualText.trim());
  };

  const handleToast = useCallback((type, message) => {
    if (type === 'success') {
      toast.showSuccess(message, handleUndo);
    } else if (type === 'error') {
      toast.showError(message);
    } else if (type === 'warning') {
      toast.showWarning(message);
    }
  }, [toast, handleUndo]);

  const handlePicker = useCallback((message, options, onSelect) => {
    toast.showPicker(message, options, onSelect);
  }, [toast]);

  if (!isAdmin()) {
    return null;
  }

  const showOverlay = isListening || processing || error || showTextInput;

  return (
    <>
      {showOverlay && (
        <View style={styles.overlay}>
          <TouchableOpacity 
            style={styles.backdrop} 
            onPress={() => {
              terminateRecognition();
              setError(null);
              setShowTextInput(false);
              setManualText('');
            }} 
            activeOpacity={1} 
          />
          
          <View style={styles.card}>
            {processing ? (
              <View style={styles.processingContainer}>
                <ActivityIndicator size="large" color={colors.primary} />
                <Text style={styles.processingText}>Processing...</Text>
                {transcript && (
                  <Text style={styles.transcriptPreview}>"{transcript}"</Text>
                )}
              </View>
            ) : isListening ? (
              <View style={styles.listeningContainer}>
                <Text style={styles.liveTranscript}>
                  {transcript || 'Listening...'}
                </Text>
                
                <View style={styles.micContainer}>
                  <Animated.View style={[styles.pulseOuter, { transform: [{ scale: pulseAnim }] }]} />
                  <TouchableOpacity 
                    style={styles.micButtonActive}
                    onPressOut={stopAndProcess}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.micIcon}>🎤</Text>
                  </TouchableOpacity>
                </View>
                
                <Text style={styles.timer}>{formatTime(recordingSeconds)}</Text>
                <Text style={styles.hint}>Release to send</Text>
              </View>
            ) : showTextInput ? (
              <View style={styles.textInputContainer}>
                <TextInput
                  style={styles.textInput}
                  value={manualText}
                  onChangeText={setManualText}
                  placeholder="Type your command..."
                  placeholderTextColor="#9ca3af"
                  multiline
                  autoFocus
                />
                <TouchableOpacity style={styles.submitButton} onPress={handleManualSubmit}>
                  <Text style={styles.submitButtonText}>Send</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.cancelButton} 
                  onPress={() => {
                    setShowTextInput(false);
                    setManualText('');
                  }}
                >
                  <Text style={styles.cancelText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            ) : error ? (
              <View style={styles.errorContainer}>
                <View style={styles.errorBox}>
                  <Text style={styles.errorBoxText}>{error}</Text>
                </View>
                <TouchableOpacity
                  style={styles.recordButton}
                  onPressIn={startListening}
                  delayPressIn={0}
                >
                  <Text style={styles.recordIcon}>🎤</Text>
                  <Text style={styles.recordText}>Hold to Speak</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.switchButton} onPress={() => setShowTextInput(true)}>
                  <Text style={styles.switchButtonText}>Type instead</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.cancelButton} 
                  onPress={() => setError(null)}
                >
                  <Text style={styles.cancelText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            ) : null}
          </View>
        </View>
      )}
      
      <TouchableOpacity
        style={[styles.fab, isListening && styles.fabRecording]}
        onPressIn={startListening}
        onPressOut={isListening ? stopAndProcess : undefined}
        onLongPress={() => setShowTextInput(true)}
        delayLongPress={800}
        delayPressIn={0}
        activeOpacity={0.8}
      >
        {isListening ? (
          <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
            <Text style={styles.fabIcon}>🎤</Text>
          </Animated.View>
        ) : (
          <Text style={styles.fabIcon}>🎤</Text>
        )}
      </TouchableOpacity>
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    bottom: isMobile ? 210 : 140,
    right: isMobile ? 28 : 28,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#475569',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    elevation: 8,
    ...shadows.large,
  },
  fabRecording: {
    backgroundColor: '#ef4444',
    width: 70,
    height: 70,
    borderRadius: 35,
    bottom: isMobile ? 205 : 135,
    right: isMobile ? 23 : 23,
  },
  fabIcon: {
    fontSize: 28,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
  },
  backdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 24,
    width: '90%',
    maxWidth: 360,
    alignItems: 'center',
    ...Platform.select({
      web: {
        boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
      },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 20,
        elevation: 15,
      },
    }),
  },
  processingContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  processingText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  transcriptPreview: {
    fontSize: 15,
    color: '#6b7280',
    marginTop: 12,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  listeningContainer: {
    alignItems: 'center',
    width: '100%',
  },
  liveTranscript: {
    fontSize: 18,
    color: colors.text,
    textAlign: 'center',
    minHeight: 50,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  micContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  pulseOuter: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  micButtonActive: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ef4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  micIcon: {
    fontSize: 36,
  },
  timer: {
    fontSize: 24,
    fontWeight: '600',
    color: '#ef4444',
    marginTop: 16,
  },
  hint: {
    fontSize: 14,
    color: '#9ca3af',
    marginTop: 8,
  },
  errorContainer: {
    alignItems: 'center',
    width: '100%',
  },
  errorBox: {
    backgroundColor: '#fef2f2',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 16,
    width: '100%',
  },
  errorBoxText: {
    color: '#dc2626',
    fontSize: 15,
    textAlign: 'center',
  },
  recordButton: {
    backgroundColor: colors.primary,
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  recordIcon: {
    fontSize: 24,
  },
  recordText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
  textInputContainer: {
    width: '100%',
    gap: 12,
  },
  textInput: {
    backgroundColor: '#f3f4f6',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: '700',
  },
  switchButton: {
    paddingVertical: 12,
  },
  switchButtonText: {
    color: colors.primary,
    fontSize: 15,
    fontWeight: '600',
  },
  cancelButton: {
    paddingVertical: 16,
    marginTop: 8,
  },
  cancelText: {
    color: '#6b7280',
    fontSize: 16,
    fontWeight: '500',
  },
});
