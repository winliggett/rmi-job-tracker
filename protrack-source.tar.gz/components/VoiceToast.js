import React, { useState, useEffect, useRef, createContext, useContext, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  Dimensions,
  Platform,
} from 'react-native';
import * as Haptics from '../utils/haptics';

const { width: screenWidth } = Dimensions.get('window');
const isMobile = screenWidth < 768;

const VoiceToastContext = createContext();

export const useVoiceToast = () => {
  const context = useContext(VoiceToastContext);
  if (!context) {
    console.warn('useVoiceToast must be used within a VoiceToastProvider');
    return {
      showSuccess: () => {},
      showError: () => {},
      showPicker: () => {},
      dismiss: () => {},
    };
  }
  return context;
};

const UNDO_COUNTDOWN = 10;

const VoiceToastItem = ({ 
  id, 
  message, 
  type, 
  onRemove, 
  onUndo, 
  options, 
  onOptionSelect,
  showUndo = false 
}) => {
  const translateY = useRef(new Animated.Value(100)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const [countdown, setCountdown] = useState(UNDO_COUNTDOWN);
  const countdownRef = useRef(null);
  const autoRemoveRef = useRef(null);

  const styles_map = {
    success: { bg: '#22c55e', icon: '✓' },
    error: { bg: '#ef4444', icon: '✕' },
    warning: { bg: '#f59e0b', icon: '⚠' },
    picker: { bg: '#3b82f6', icon: '?' },
  };

  const style = styles_map[type] || styles_map.success;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(translateY, {
        toValue: 0,
        friction: 8,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();

    if (showUndo) {
      countdownRef.current = setInterval(() => {
        setCountdown(prev => {
          if (prev <= 1) {
            clearInterval(countdownRef.current);
            animateOut();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (type !== 'picker') {
      autoRemoveRef.current = setTimeout(() => {
        animateOut();
      }, 4000);
    }

    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
      if (autoRemoveRef.current) clearTimeout(autoRemoveRef.current);
    };
  }, []);

  const animateOut = () => {
    Animated.parallel([
      Animated.timing(translateY, {
        toValue: 100,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => onRemove(id));
  };

  const handleUndo = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (countdownRef.current) clearInterval(countdownRef.current);
    onUndo?.();
    animateOut();
  };

  const handleDismiss = () => {
    if (countdownRef.current) clearInterval(countdownRef.current);
    if (autoRemoveRef.current) clearTimeout(autoRemoveRef.current);
    animateOut();
  };

  const handleOptionSelect = (option) => {
    Haptics.selectionAsync();
    onOptionSelect?.(option);
    animateOut();
  };

  return (
    <Animated.View
      style={[
        styles.toastItem,
        { 
          backgroundColor: style.bg, 
          transform: [{ translateY }], 
          opacity,
        },
      ]}
    >
      <View style={styles.toastContent}>
        <View style={styles.toastIconContainer}>
          <Text style={styles.toastIcon}>{style.icon}</Text>
        </View>
        <Text style={styles.toastMessage}>{message}</Text>
      </View>
      
      {type === 'picker' && options?.length > 0 && (
        <View style={styles.optionsContainer}>
          {options.map((option, index) => (
            <TouchableOpacity
              key={index}
              style={styles.optionButton}
              onPress={() => handleOptionSelect(option)}
            >
              <Text style={styles.optionText}>{option.label || option}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
      
      <View style={styles.actionsRow}>
        {showUndo && (
          <TouchableOpacity style={styles.undoButton} onPress={handleUndo}>
            <Text style={styles.undoText}>Undo ({countdown}s)</Text>
          </TouchableOpacity>
        )}
        {type === 'error' && (
          <TouchableOpacity style={styles.dismissButton} onPress={handleDismiss}>
            <Text style={styles.dismissText}>Dismiss</Text>
          </TouchableOpacity>
        )}
      </View>
    </Animated.View>
  );
};

export const VoiceToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  const undoCallbackRef = useRef(null);
  const optionCallbackRef = useRef(null);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const dismiss = useCallback(() => {
    setToasts([]);
  }, []);

  const showSuccess = useCallback((message, onUndo = null) => {
    const id = Date.now() + Math.random();
    undoCallbackRef.current = onUndo;
    setToasts([{ id, message, type: 'success', showUndo: !!onUndo }]);
  }, []);

  const showError = useCallback((message) => {
    const id = Date.now() + Math.random();
    setToasts([{ id, message, type: 'error', showUndo: false }]);
  }, []);

  const showWarning = useCallback((message) => {
    const id = Date.now() + Math.random();
    setToasts([{ id, message, type: 'warning', showUndo: false }]);
  }, []);

  const showPicker = useCallback((message, options, onSelect) => {
    const id = Date.now() + Math.random();
    optionCallbackRef.current = onSelect;
    setToasts([{ id, message, type: 'picker', options, showUndo: false }]);
  }, []);

  const handleUndo = useCallback(() => {
    undoCallbackRef.current?.();
    undoCallbackRef.current = null;
  }, []);

  const handleOptionSelect = useCallback((option) => {
    optionCallbackRef.current?.(option);
    optionCallbackRef.current = null;
  }, []);

  const toast = {
    showSuccess,
    showError,
    showWarning,
    showPicker,
    dismiss,
  };

  return (
    <VoiceToastContext.Provider value={toast}>
      {children}
      {toasts.length > 0 && (
        <View style={styles.container} pointerEvents="box-none">
          {toasts.map((t) => (
            <VoiceToastItem 
              key={t.id} 
              {...t} 
              onRemove={removeToast}
              onUndo={handleUndo}
              onOptionSelect={handleOptionSelect}
            />
          ))}
        </View>
      )}
    </VoiceToastContext.Provider>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    zIndex: 10000,
    bottom: 100,
    left: 16,
    right: 16,
  },
  toastItem: {
    padding: 16,
    borderRadius: 16,
    marginBottom: 10,
    ...Platform.select({
      web: {
        boxShadow: '0 4px 20px rgba(0,0,0,0.25)',
      },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.25,
        shadowRadius: 10,
        elevation: 10,
      },
    }),
  },
  toastContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  toastIconContainer: {
    width: 32,
    height: 32,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  toastIcon: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  toastMessage: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: '600',
    flex: 1,
    lineHeight: 22,
  },
  actionsRow: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 10,
  },
  undoButton: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  undoText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '700',
  },
  dismissButton: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  dismissText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  optionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 12,
    gap: 8,
  },
  optionButton: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  optionText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '600',
  },
});

export default VoiceToastProvider;
