import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Platform,
  ScrollView,
} from 'react-native';
import { colors, spacing, borderRadius } from '../utils/theme';
import { useUser } from '../contexts/UserContext';
import { getPlacesAutocomplete } from '../utils/api';

const EditableField = ({
  value,
  onSave,
  isAdmin = false,
  type = 'text',
  label,
  placeholder,
  fontSize = 16,
  fontWeight = '400',
  color = '#1e293b',
  darkMode = false,
}) => {
  const { token } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value ?? '');
  const [saving, setSaving] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    setEditValue(value ?? '');
  }, [value]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  useEffect(() => {
    return () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
    };
  }, []);

  const fetchAddressSuggestions = useCallback(async (input) => {
    if (!input || input.length < 3 || !token || type !== 'address') {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setLoadingSuggestions(true);
    try {
      const data = await getPlacesAutocomplete(token, input);
      setSuggestions(data.predictions || []);
      setShowSuggestions((data.predictions || []).length > 0);
    } catch (error) {
      console.error('Address autocomplete error:', error);
      setSuggestions([]);
    } finally {
      setLoadingSuggestions(false);
    }
  }, [token, type]);

  const handleTextChange = (text) => {
    setEditValue(text);
    
    if (type === 'address') {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }
      debounceRef.current = setTimeout(() => {
        fetchAddressSuggestions(text);
      }, 300);
    }
  };

  const handleSelectSuggestion = (suggestion) => {
    setEditValue(suggestion.description);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const handleSave = async () => {
    const normalizedEdit = editValue ?? '';
    const normalizedValue = value ?? '';
    
    if (normalizedEdit === normalizedValue) {
      setIsEditing(false);
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    setSaving(true);
    try {
      await onSave(editValue);
      setIsEditing(false);
      setSuggestions([]);
      setShowSuggestions(false);
    } catch (error) {
      console.error('Save failed:', error);
      setEditValue(value ?? '');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setEditValue(value ?? '');
    setIsEditing(false);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const getKeyboardType = () => {
    switch (type) {
      case 'tel':
        return 'phone-pad';
      case 'number':
        return 'numeric';
      default:
        return 'default';
    }
  };

  if (!isAdmin) {
    return (
      <View>
        <Text style={{ fontSize, fontWeight, color }}>
          {value || <Text style={{ color: '#9ca3af' }}>Not set</Text>}
        </Text>
      </View>
    );
  }

  if (isEditing) {
    const inputStyle = {
      ...styles.input,
      fontSize: Math.min(fontSize, 20),
      fontWeight,
      backgroundColor: darkMode ? '#0f172a' : '#ffffff',
      color: darkMode ? '#ffffff' : '#1e293b',
      borderColor: '#1c3b59',
    };

    return (
      <View style={styles.editContainer}>
        {label && (
          <Text style={[styles.label, darkMode && styles.labelDark]}>
            {label}
          </Text>
        )}

        <View style={styles.inputWrapper}>
          <TextInput
            ref={inputRef}
            style={inputStyle}
            value={editValue}
            onChangeText={handleTextChange}
            placeholder={placeholder}
            placeholderTextColor="#9ca3af"
            keyboardType={getKeyboardType()}
            multiline={type === 'textarea'}
            numberOfLines={type === 'textarea' ? 3 : 1}
            autoCapitalize={type === 'tel' ? 'none' : 'sentences'}
          />
          {loadingSuggestions && (
            <ActivityIndicator style={styles.inputLoader} size="small" color="#1c3b59" />
          )}
        </View>

        {showSuggestions && suggestions.length > 0 && (
          <View style={[styles.suggestionsDropdown, darkMode && styles.suggestionsDropdownDark]}>
            <ScrollView 
              style={styles.suggestionsScroll}
              keyboardShouldPersistTaps="handled"
              nestedScrollEnabled
            >
              {suggestions.map((suggestion, index) => (
                <TouchableOpacity
                  key={suggestion.place_id || index}
                  style={styles.suggestionItem}
                  onPress={() => handleSelectSuggestion(suggestion)}
                >
                  <Text style={styles.suggestionIcon}>📍</Text>
                  <View style={styles.suggestionTextContainer}>
                    <Text style={[styles.suggestionMainText, darkMode && styles.suggestionTextDark]} numberOfLines={1}>
                      {suggestion.main_text || suggestion.description?.split(',')[0]}
                    </Text>
                    {suggestion.secondary_text && (
                      <Text style={styles.suggestionSecondaryText} numberOfLines={1}>
                        {suggestion.secondary_text}
                      </Text>
                    )}
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.saveButton}
            onPress={handleSave}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator size="small" color="#ffffff" />
            ) : (
              <Text style={styles.saveButtonText}>Save</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>

        {type === 'address' && !showSuggestions && (
          <Text style={[styles.hint, darkMode && styles.hintDark]}>Start typing for address suggestions</Text>
        )}
      </View>
    );
  }

  return (
    <TouchableOpacity
      style={[styles.displayContainer, darkMode && styles.displayContainerDark]}
      onPress={() => setIsEditing(true)}
      activeOpacity={0.7}
    >
      <View style={styles.displayContent}>
        <Text style={{ fontSize, fontWeight, color, flex: 1 }}>
          {value || (
            <Text style={{ color: darkMode ? 'rgba(255,255,255,0.5)' : '#9ca3af', fontStyle: 'italic' }}>
              {placeholder || 'Tap to add'}
            </Text>
          )}
        </Text>
        <Text style={styles.editIcon}>✏️</Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  editContainer: {
    width: '100%',
  },
  label: {
    fontSize: 13,
    color: '#64748b',
    marginBottom: 6,
    fontWeight: '600',
  },
  labelDark: {
    color: 'rgba(255,255,255,0.6)',
  },
  input: {
    width: '100%',
    padding: 14,
    paddingHorizontal: 18,
    borderWidth: 2,
    borderRadius: 10,
    minHeight: 52,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 10,
  },
  saveButton: {
    backgroundColor: '#1c3b59',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    minWidth: 80,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  cancelButton: {
    backgroundColor: '#f1f5f9',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  cancelButtonText: {
    color: '#475569',
    fontSize: 14,
    fontWeight: '600',
  },
  hint: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 8,
  },
  hintDark: {
    color: 'rgba(255,255,255,0.5)',
  },
  inputWrapper: {
    position: 'relative',
  },
  inputLoader: {
    position: 'absolute',
    right: 16,
    top: '50%',
    marginTop: -10,
  },
  suggestionsDropdown: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    marginTop: 4,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    maxHeight: 200,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  suggestionsDropdownDark: {
    backgroundColor: '#1e293b',
    borderColor: '#334155',
  },
  suggestionsScroll: {
    maxHeight: 200,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  suggestionIcon: {
    fontSize: 16,
    marginRight: 10,
  },
  suggestionTextContainer: {
    flex: 1,
  },
  suggestionMainText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1e293b',
  },
  suggestionTextDark: {
    color: '#ffffff',
  },
  suggestionSecondaryText: {
    fontSize: 13,
    color: '#64748b',
    marginTop: 2,
  },
  displayContainer: {
    padding: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: 'transparent',
    marginHorizontal: -14,
    marginVertical: -10,
  },
  displayContainerDark: {
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  displayContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  editIcon: {
    fontSize: 18,
    opacity: 0.6,
  },
});

export default EditableField;
