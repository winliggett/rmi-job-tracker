import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { useUser } from '../contexts/UserContext';
import { getPlacesAutocomplete, getPlaceDetails } from '../utils/api';

const AddressAutocomplete = ({
  value,
  onChangeText,
  onSelectAddress,
  placeholder = 'Enter address',
  style,
  inputStyle,
}) => {
  const { token } = useUser();
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const debounceTimer = useRef(null);

  const fetchSuggestions = useCallback(async (input) => {
    if (!input || input.length < 3 || !token) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }

    setLoading(true);
    try {
      const data = await getPlacesAutocomplete(token, input);
      setSuggestions(data.predictions || []);
      setShowDropdown((data.predictions || []).length > 0);
    } catch (error) {
      console.error('Address autocomplete error:', error);
      setSuggestions([]);
    } finally {
      setLoading(false);
    }
  }, [token]);

  const handleTextChange = (text) => {
    onChangeText(text);
    
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    
    debounceTimer.current = setTimeout(() => {
      fetchSuggestions(text);
    }, 300);
  };

  const handleSelectSuggestion = async (suggestion) => {
    setShowDropdown(false);
    setSuggestions([]);
    
    if (suggestion.description) {
      onChangeText(suggestion.description);
    }
    
    if (onSelectAddress && suggestion.place_id) {
      try {
        const details = await getPlaceDetails(token, suggestion.place_id);
        onSelectAddress({
          address: details.formatted_address || suggestion.description,
          placeId: suggestion.place_id,
          location: details.location,
          components: details.address_components,
        });
      } catch (error) {
        console.error('Failed to get place details:', error);
        onSelectAddress({
          address: suggestion.description,
          placeId: suggestion.place_id,
        });
      }
    }
  };

  return (
    <View style={[styles.container, style]}>
      <View style={styles.inputContainer}>
        <TextInput
          style={[styles.input, inputStyle]}
          value={value}
          onChangeText={handleTextChange}
          placeholder={placeholder}
          placeholderTextColor="#9ca3af"
          autoCapitalize="words"
          onFocus={() => {
            if (suggestions.length > 0) {
              setShowDropdown(true);
            }
          }}
        />
        {loading && (
          <ActivityIndicator style={styles.loader} size="small" color="#1c3b59" />
        )}
      </View>
      
      {showDropdown && suggestions.length > 0 && (
        <View style={styles.dropdown}>
          <ScrollView 
            style={styles.dropdownScroll}
            keyboardShouldPersistTaps="handled"
            nestedScrollEnabled
          >
            {suggestions.map((suggestion, index) => (
              <TouchableOpacity
                key={suggestion.place_id || index}
                style={styles.suggestionItem}
                onPress={() => handleSelectSuggestion(suggestion)}
              >
                <Text style={styles.suggestionIcon}>📍</Text>
                <View style={styles.suggestionText}>
                  <Text style={styles.mainText} numberOfLines={1}>
                    {suggestion.main_text || suggestion.description?.split(',')[0]}
                  </Text>
                  {suggestion.secondary_text && (
                    <Text style={styles.secondaryText} numberOfLines={1}>
                      {suggestion.secondary_text}
                    </Text>
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    zIndex: 100,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    paddingHorizontal: 18,
    fontSize: 17,
    color: '#1e293b',
    minHeight: 56,
  },
  loader: {
    position: 'absolute',
    right: 16,
  },
  dropdown: {
    position: 'absolute',
    top: '100%',
    left: 0,
    right: 0,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginTop: 4,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
    maxHeight: 240,
    zIndex: 1000,
  },
  dropdownScroll: {
    maxHeight: 240,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  suggestionIcon: {
    fontSize: 18,
    marginRight: 12,
  },
  suggestionText: {
    flex: 1,
  },
  mainText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  secondaryText: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
});

export default AddressAutocomplete;
