import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Platform,
  Animated,
  TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from '../utils/haptics';
import { colors, typography, spacing, borderRadius } from '../utils/theme';

const SpeechRecognition = Platform.OS === 'web' 
  ? window.SpeechRecognition || window.webkitSpeechRecognition
  : null;

const MAX_RECORDING_SECONDS = 300;
const isAndroid = Platform.OS === 'android' || (Platform.OS === 'web' && typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent));

export default function VoiceDictation({ 
  onResult, 
  onClose, 
  currentJobId = null,
  onToast,
  onPicker,
}) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [showTextInput, setShowTextInput] = useState(false);
  const [manualText, setManualText] = useState('');
  
  const recognitionRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const timerRef = useRef(null);
  const autoStopRef = useRef(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      terminateRecognition();
    };
  }, []);

  const terminateRecognition = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (autoStopRef.current) {
      clearTimeout(autoStopRef.current);
      autoStopRef.current = null;
    }
    
    const recog = recognitionRef.current;
    if (recog) {
      recognitionRef.current = null;
      try { recog.abort(); } catch (e) {}
      try { recog.stop(); } catch (e) {}
      try {
        recog.onstart = null;
        recog.onresult = null;
        recog.onerror = null;
        recog.onend = null;
      } catch (e) {}
    }
    
    const stream = mediaStreamRef.current;
    if (stream) {
      mediaStreamRef.current = null;
      try {
        stream.getTracks().forEach(track => track.stop());
      } catch (e) {}
    }
    
    if (mountedRef.current) {
      setIsListening(false);
      setRecordingSeconds(0);
    }
  }, []);

  useEffect(() => {
    if (isListening) {
      const pulse = () => {
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.15,
            duration: 600,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }),
        ]).start(() => {
          if (isListening) pulse();
        });
      };
      pulse();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isListening, pulseAnim]);

  useEffect(() => {
    if (isListening) {
      timerRef.current = setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isListening]);

  const getCommandDescription = (cmd) => {
    if (!cmd) return '';
    switch (cmd.action) {
      case 'add_task': 
        const jobRef = cmd.job_address || cmd.job_name || '';
        return `Task assigned to ${cmd.assignee}${jobRef ? ` on ${jobRef}` : ''}`;
      case 'add_note': return `Note added`;
      case 'change_status': return `Status changed to ${cmd.status}`;
      case 'toggle_urgent': return cmd.urgent ? 'Marked urgent' : 'Removed urgent';
      case 'create_job': return `Job created: ${cmd.client_name || cmd.customerName}`;
      case 'navigate': return `Navigating to ${cmd.destination}`;
      default: return 'Action completed';
    }
  };

  const handleParsedResult = async (parsed) => {
    const commands = parsed.commands || [parsed];
    const cmd = commands[0];
    
    if (cmd.clarification_needed) {
      onToast?.('warning', `${cmd.clarification_needed}`);
      onClose?.();
      return;
    }
    
    if (cmd.ambiguous_jobs && cmd.ambiguous_jobs.length > 1) {
      const options = cmd.ambiguous_jobs.map(job => ({
        label: job.address || job.client_name,
        value: job
      }));
      onPicker?.('Which job?', options, (selected) => {
        const updatedCmd = { ...cmd, job_id: selected.value.id, job_address: selected.label };
        delete updatedCmd.ambiguous_jobs;
        onResult?.({ commands: [updatedCmd], originalText: parsed.originalText });
      });
      onClose?.();
      return;
    }
    
    onResult?.(parsed);
    onClose?.();
  };

  const processWithAI = async (text) => {
    setProcessing(true);
    setError(null);
    
    try {
      const token = await AsyncStorage.getItem('token');
      
      const response = await fetch('/api/voice/parse', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          transcript: text,
          jobId: currentJobId,
        })
      });

      if (!response.ok) {
        throw new Error('Failed to parse command');
      }

      const parsed = await response.json();
      console.log('Parsed result:', parsed);
      
      const commands = parsed.commands || [parsed];
      
      if (!commands.length || commands[0].action === 'unknown') {
        onToast?.('error', "I didn't understand that — try again");
        onClose?.();
        return;
      }
      
      await handleParsedResult({ commands, originalText: text });
      
    } catch (err) {
      console.error('Parse error:', err);
      onToast?.('error', "Something went wrong — try again");
      onClose?.();
    } finally {
      setProcessing(false);
    }
  };

  const handleManualTextSubmit = () => {
    if (!manualText.trim()) return;
    processWithAI(manualText.trim());
  };

  const startListening = async () => {
    if (isListening || processing) return;
    terminateRecognition();
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      
      if (!SpeechRecognition) {
        setError('Voice not available in this browser');
        terminateRecognition();
        return;
      }
      
      const recog = new SpeechRecognition();
      recog.continuous = true;
      recog.interimResults = true;
      recog.lang = 'en-US';
      recog.maxAlternatives = 1;

      recog.onstart = () => {
        if (mountedRef.current) {
          setIsListening(true);
          setError(null);
          setTranscript('');
          setRecordingSeconds(0);
        }
      };

      recog.onresult = (event) => {
        let fullTranscript = '';
        for (let i = 0; i < event.results.length; i++) {
          fullTranscript += event.results[i][0].transcript;
        }
        if (fullTranscript && mountedRef.current) {
          setTranscript(fullTranscript);
        }
      };

      recog.onerror = (event) => {
        if (!mountedRef.current) return;
        switch (event.error) {
          case 'not-allowed':
            setError('Microphone access denied');
            break;
          case 'no-speech':
            setError('No speech detected');
            break;
          case 'aborted':
            break;
          default:
            setError('Could not hear you');
        }
        setIsListening(false);
        setProcessing(false);
        terminateRecognition();
      };

      recog.onend = () => {
        if (mountedRef.current) {
          setIsListening(false);
        }
        terminateRecognition();
      };

      recognitionRef.current = recog;
      
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      setError(null);
      setTranscript('');
      
      autoStopRef.current = setTimeout(() => {
        if (recognitionRef.current) {
          recognitionRef.current.stop();
        }
      }, MAX_RECORDING_SECONDS * 1000);
      
      recog.start();
      
    } catch (err) {
      console.error('Microphone error:', err);
      setError('Please allow microphone access');
      terminateRecognition();
    }
  };

  const stopAndProcess = () => {
    const currentTranscript = transcript;
    
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
    terminateRecognition();
    
    if (currentTranscript && currentTranscript.trim()) {
      processWithAI(currentTranscript.trim());
    } else {
      setError('No speech detected');
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleClose = () => {
    terminateRecognition();
    onClose?.();
  };

  if (!SpeechRecognition) {
    return (
      <View style={styles.container}>
        <View style={styles.card}>
          <Text style={styles.errorIcon}>🎤</Text>
          <Text style={styles.errorTitle}>Voice Not Available</Text>
          <Text style={styles.errorMessage}>Use Chrome or Safari browser</Text>
          <TouchableOpacity style={styles.closeButton} onPress={handleClose}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backdrop} onPress={handleClose} activeOpacity={1} />
      
      <View style={styles.card}>
        {processing ? (
          <View style={styles.processingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={styles.processingText}>Processing...</Text>
            {transcript && (
              <Text style={styles.transcriptPreview}>"{transcript}"</Text>
            )}
          </View>
        ) : isListening ? (
          <View style={styles.listeningContainer}>
            <Text style={styles.liveTranscript}>
              {transcript || 'Listening...'}
            </Text>
            
            <View style={styles.micContainer}>
              <Animated.View style={[styles.pulseOuter, { transform: [{ scale: pulseAnim }] }]} />
              <TouchableOpacity 
                style={styles.micButton}
                onPressOut={stopAndProcess}
                activeOpacity={0.9}
              >
                <Text style={styles.micIcon}>🎤</Text>
              </TouchableOpacity>
            </View>
            
            <Text style={styles.timer}>{formatTime(recordingSeconds)}</Text>
            <Text style={styles.hint}>Release to send</Text>
          </View>
        ) : (
          <View style={styles.readyContainer}>
            {error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorBoxText}>{error}</Text>
              </View>
            )}
            
            {showTextInput ? (
              <View style={styles.textInputContainer}>
                <TextInput
                  style={styles.textInput}
                  value={manualText}
                  onChangeText={setManualText}
                  placeholder="Type your command..."
                  placeholderTextColor="#9ca3af"
                  multiline
                  autoFocus
                />
                <TouchableOpacity style={styles.submitButton} onPress={handleManualTextSubmit}>
                  <Text style={styles.submitButtonText}>Send</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.switchButton} onPress={() => setShowTextInput(false)}>
                  <Text style={styles.switchButtonText}>🎤 Use voice</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <TouchableOpacity
                  style={styles.recordButton}
                  onPressIn={startListening}
                  delayPressIn={0}
                >
                  <Text style={styles.recordIcon}>🎤</Text>
                  <Text style={styles.recordText}>Hold to Speak</Text>
                </TouchableOpacity>
                
                {(error || isAndroid) && (
                  <TouchableOpacity style={styles.switchButton} onPress={() => setShowTextInput(true)}>
                    <Text style={styles.switchButtonText}>⌨️ Type instead</Text>
                  </TouchableOpacity>
                )}
              </>
            )}
            
            <TouchableOpacity style={styles.cancelButton} onPress={handleClose}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
  },
  backdrop: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 20,
    padding: 24,
    width: '90%',
    maxWidth: 360,
    alignItems: 'center',
    ...Platform.select({
      web: {
        boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
      },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.3,
        shadowRadius: 20,
        elevation: 15,
      },
    }),
  },
  processingContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  processingText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  transcriptPreview: {
    fontSize: 15,
    color: '#6b7280',
    marginTop: 12,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  listeningContainer: {
    alignItems: 'center',
    width: '100%',
  },
  liveTranscript: {
    fontSize: 18,
    color: colors.text,
    textAlign: 'center',
    minHeight: 50,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  micContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  pulseOuter: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  micButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ef4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  micIcon: {
    fontSize: 36,
  },
  timer: {
    fontSize: 24,
    fontWeight: '600',
    color: '#ef4444',
    marginTop: 16,
  },
  hint: {
    fontSize: 14,
    color: '#9ca3af',
    marginTop: 8,
  },
  readyContainer: {
    alignItems: 'center',
    width: '100%',
  },
  errorBox: {
    backgroundColor: '#fef2f2',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 16,
    width: '100%',
  },
  errorBoxText: {
    color: '#dc2626',
    fontSize: 15,
    textAlign: 'center',
  },
  recordButton: {
    backgroundColor: colors.primary,
    paddingVertical: 18,
    paddingHorizontal: 40,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  recordIcon: {
    fontSize: 24,
  },
  recordText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
  textInputContainer: {
    width: '100%',
    gap: 12,
  },
  textInput: {
    backgroundColor: '#f3f4f6',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: '700',
  },
  switchButton: {
    paddingVertical: 12,
  },
  switchButtonText: {
    color: colors.primary,
    fontSize: 15,
    fontWeight: '600',
  },
  cancelButton: {
    paddingVertical: 16,
    marginTop: 8,
  },
  cancelText: {
    color: '#6b7280',
    fontSize: 16,
    fontWeight: '500',
  },
  errorIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 8,
  },
  errorMessage: {
    fontSize: 15,
    color: '#6b7280',
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 10,
  },
  closeButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
});
