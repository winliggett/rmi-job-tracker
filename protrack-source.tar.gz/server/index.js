const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
require('dotenv').config();

const path = require('path');
const fs = require('fs');
const multer = require('multer');
const Anthropic = require('@anthropic-ai/sdk');
const Fuse = require('fuse.js');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const nameMatching = require('../utils/nameMatching');
const NotificationService = require('./notificationService');

const ENCRYPTION_KEY = process.env.JWT_SECRET || 'default-encryption-key-32chars!';
const IV_LENGTH = 16;

function encrypt(text) {
  if (!text) return '';
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return iv.toString('hex') + ':' + encrypted;
}

function decrypt(text) {
  if (!text || !text.includes(':')) return '';
  try {
    const [ivHex, encrypted] = text.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    console.error('Decryption failed:', e.message);
    return '';
  }
}

const anthropic = process.env.ANTHROPIC_API_KEY 
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

if (!anthropic) {
  console.warn('⚠️  ANTHROPIC_API_KEY not set - voice commands will use basic fallback parsing');
  console.warn('   AI-powered voice understanding is disabled. Add key to Replit Secrets for better accuracy.');
}

// Undo action tracking - stores last action per user for 60 seconds
const undoStore = new Map();
const UNDO_TIMEOUT_MS = 60000; // 60 seconds to undo

function storeUndoAction(userId, action) {
  const existing = undoStore.get(userId);
  if (existing?.timeout) {
    clearTimeout(existing.timeout);
  }
  
  const timeout = setTimeout(() => {
    undoStore.delete(userId);
  }, UNDO_TIMEOUT_MS);
  
  undoStore.set(userId, {
    ...action,
    timestamp: Date.now(),
    timeout
  });
  console.log(`📦 Undo action stored for user ${userId}: ${action.type}`);
}

function getUndoAction(userId) {
  const action = undoStore.get(userId);
  if (action) {
    clearTimeout(action.timeout);
    undoStore.delete(userId);
    return action;
  }
  return null;
}


const uploadsDir = path.join(__dirname, '..', 'uploads', 'profiles');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `profile-${req.params.id}-${Date.now()}${ext}`);
  }
});
const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed. Please upload JPG, PNG, or similar formats.'), false);
    }
  }
});

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET) {
  console.error('\n' + '═'.repeat(60));
  console.error('❌ CRITICAL ERROR: JWT_SECRET MISSING');
  console.error('═'.repeat(60));
  console.error('The JWT_SECRET environment variable is required for security.');
  console.error('Add it to Replit Secrets or your .env file.');
  console.error('Example: JWT_SECRET=your-random-secret-key-here');
  console.error('═'.repeat(60) + '\n');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const notificationService = new NotificationService(pool);

app.use(cors());
app.use(express.json());

// Simple request logger for debugging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const shouldLog = req.path.startsWith('/api') && req.method !== 'OPTIONS';
    if (shouldLog) {
      const status = res.statusCode;
      const emoji = status < 400 ? '✅' : '❌';
      console.log(`${emoji} ${req.method} ${req.path} - ${status} (${duration}ms)`);
    }
  });
  next();
});

// Disable caching for all API routes (prevents Safari from showing stale data)
app.use('/api', (req, res, next) => {
  res.set({
    'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
    'Surrogate-Control': 'no-store'
  });
  next();
});

async function sendSmsNotification(userId, message) {
  console.log('');
  console.log('📱 ═══════════════════════════════════════════════');
  console.log('📱 SMS NOTIFICATION');
  console.log('📱 ═══════════════════════════════════════════════');
  console.log(`📱 To User ID: ${userId}`);
  console.log(`📱 Message: ${message}`);
  console.log('📱 ═══════════════════════════════════════════════');
  console.log('');
  
  await sendNotification('sms', userId, message);
}

function sendMockSMS(to, message) {
  console.log('');
  console.log('📱 ═══════════════════════════════════════════════');
  console.log('📱 MOCK SMS NOTIFICATION');
  console.log('📱 ═══════════════════════════════════════════════');
  console.log(`📱 To: ${to || 'No phone number'}`);
  console.log(`📱 Message:`);
  console.log(`📱 ${message}`);
  console.log('📱 ═══════════════════════════════════════════════');
  console.log('');
}

async function logActivity(jobId, userId, action, details = null) {
  try {
    const userCompany = await pool.query('SELECT company_id FROM users WHERE id = $1', [userId]);
    const companyId = userCompany.rows[0]?.company_id || null;
    await pool.query(
      'INSERT INTO activity_logs (job_id, user_id, action, details, company_id) VALUES ($1, $2, $3, $4, $5)',
      [jobId, userId, action, details, companyId]
    );
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
}

async function sendTaskNotificationWithLog(pool, assigneeId, jobId, taskDescription, jobAddress, source = 'manual') {
  try {
    const userResult = await pool.query(
      'SELECT id, name, email, phone, notify_preference FROM users WHERE id = $1',
      [assigneeId]
    );
    const user = userResult.rows[0];
    if (!user) {
      console.log(`📬 Task notification skipped - user ${assigneeId} not found`);
      return { success: false, reason: 'User not found' };
    }
    
    const preference = user.notify_preference || 'email';
    const message = `New task: "${taskDescription}" at ${jobAddress}`;
    const taskHash = require('crypto').createHash('md5').update(taskDescription.toLowerCase().trim()).digest('hex').substring(0, 16);
    
    if (preference === 'disabled') {
      await pool.query(
        `INSERT INTO notifications_log 
         (recipient_id, recipient_name, recipient_contact, job_id, task_hash, message_content, status, skip_reason, source)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [assigneeId, user.name, user.email || user.phone, jobId, taskHash, message, 'skipped', 'Notifications disabled', source]
      );
      console.log(`📬 Task notification skipped for ${user.name} - notifications disabled`);
      return { success: false, reason: 'Notifications disabled' };
    }
    
    const windowStart = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const dupCheck = await pool.query(
      `SELECT id FROM notifications_log 
       WHERE recipient_id = $1 AND job_id = $2 AND task_hash = $3 
       AND sent_at > $4 AND status IN ('sent', 'delivered')
       LIMIT 1`,
      [assigneeId, jobId, taskHash, windowStart]
    );
    
    if (dupCheck.rows.length > 0) {
      await pool.query(
        `INSERT INTO notifications_log 
         (recipient_id, recipient_name, recipient_contact, job_id, task_hash, message_content, status, skip_reason, source)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [assigneeId, user.name, user.email || user.phone, jobId, taskHash, message, 'skipped', 'Duplicate within 24h', source]
      );
      console.log(`📬 Task notification skipped for ${user.name} - duplicate within 24 hours`);
      return { success: false, reason: 'Duplicate notification' };
    }
    
    const logResult = await pool.query(
      `INSERT INTO notifications_log 
       (recipient_id, recipient_name, recipient_contact, job_id, task_hash, message_content, status, source)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [assigneeId, user.name, user.email || user.phone, jobId, taskHash, message, 'pending', source]
    );
    const logId = logResult.rows[0].id;
    
    await sendNotification('task_assigned', assigneeId, message, 'ProTrack - New Task');
    
    await pool.query(
      'UPDATE notifications_log SET status = $1, sent_at = NOW() WHERE id = $2',
      ['sent', logId]
    );
    
    console.log(`📬 Task notification sent to ${user.name} (source: ${source})`);
    return { success: true };
    
  } catch (error) {
    console.error('sendTaskNotificationWithLog error:', error.message);
    return { success: false, reason: error.message };
  }
}

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access denied' });
  }
  
  try {
    const verified = jwt.verify(token, JWT_SECRET);
    const userCheck = await pool.query('SELECT id, role, company_id FROM users WHERE id = $1', [verified.id]);
    if (userCheck.rows.length === 0) {
      return res.status(403).json({ error: 'User not found - please re-login' });
    }
    const dbUser = userCheck.rows[0];
    verified.role = dbUser.role;
    verified.company_id = dbUser.company_id;
    verified.isAdmin = dbUser.role === 'admin' || dbUser.role === 'owner';
    req.user = verified;
    next();
  } catch (error) {
    res.status(403).json({ error: 'Invalid token' });
  }
};

function requireCompany(req, res) {
  if (!req.user.company_id) {
    res.status(403).json({ error: 'No company associated with this account' });
    return false;
  }
  return true;
}

async function verifyCompanyAccess(req, res, table, recordId) {
  const result = await pool.query(`SELECT company_id FROM ${table} WHERE id = $1`, [recordId]);
  if (result.rows.length === 0) {
    res.status(404).json({ error: 'Record not found' });
    return false;
  }
  if (result.rows[0].company_id !== req.user.company_id) {
    res.status(403).json({ error: 'Access denied - this record belongs to another company' });
    return false;
  }
  return true;
}

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, companyName, username } = req.body;
    const chosenUsername = username || email;
    
    if (!name || !email || !password || !companyName) {
      return res.status(400).json({ error: 'Name, email, password, and company name are required' });
    }
    
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    
    const existingEmail = await pool.query('SELECT id FROM users WHERE LOWER(email) = LOWER($1)', [email]);
    if (existingEmail.rows.length > 0) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }
    
    const existingUsername = await pool.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1)', [chosenUsername]);
    if (existingUsername.rows.length > 0) {
      return res.status(400).json({ error: 'This username is already taken' });
    }
    
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      
      const companyResult = await client.query(
        'INSERT INTO companies (name, email) VALUES ($1, $2) RETURNING id',
        [companyName, email]
      );
      const companyId = companyResult.rows[0].id;
      
      await client.query(
        `INSERT INTO company_settings (company_name, contact_email, setup_completed, company_id)
         VALUES ($1, $2, false, $3)`,
        [companyName, email, companyId]
      );
      
      const hashedPassword = await bcrypt.hash(password, 10);
      const userResult = await client.query(
        `INSERT INTO users (username, password_hash, name, role, email, company_id)
         VALUES ($1, $2, $3, 'owner', $4, $5) RETURNING id, username, name, role, email, company_id`,
        [chosenUsername, hashedPassword, name, email, companyId]
      );
      
      await client.query('COMMIT');
      
      const user = userResult.rows[0];
      const token = jwt.sign({ id: user.id, username: user.username, role: user.role, company_id: companyId }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          role: user.role,
          company_id: companyId,
        },
        token,
      });
    } catch (innerError) {
      await client.query('ROLLBACK');
      throw innerError;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Register error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/accept-invite', async (req, res) => {
  try {
    const { token: inviteToken, name, password, username } = req.body;
    
    if (!inviteToken || !name || !password) {
      return res.status(400).json({ error: 'Invite token, name, and password are required' });
    }
    
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    
    const inviteResult = await pool.query(
      'SELECT * FROM invites WHERE token = $1 AND accepted = false AND expires_at > NOW()',
      [inviteToken]
    );
    
    if (inviteResult.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid or expired invite link' });
    }
    
    const invite = inviteResult.rows[0];
    const chosenUsername = username || invite.email;
    
    const existingEmail = await pool.query('SELECT id FROM users WHERE LOWER(email) = LOWER($1)', [invite.email]);
    if (existingEmail.rows.length > 0) {
      return res.status(400).json({ error: 'An account with this email already exists. Please log in instead.' });
    }
    
    if (username) {
      const existingUsername = await pool.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1)', [username]);
      if (existingUsername.rows.length > 0) {
        return res.status(400).json({ error: 'This username is already taken' });
      }
    }
    
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      
      const hashedPassword = await bcrypt.hash(password, 10);
      const userResult = await client.query(
        `INSERT INTO users (username, password_hash, name, role, email, company_id)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, username, name, role, email, company_id`,
        [chosenUsername, hashedPassword, name, invite.role, invite.email, invite.company_id]
      );
      
      await client.query('UPDATE invites SET accepted = true WHERE id = $1', [invite.id]);
      
      await client.query('COMMIT');
      
      const user = userResult.rows[0];
      const jwtToken = jwt.sign({ id: user.id, username: user.username, role: user.role, company_id: user.company_id }, JWT_SECRET, { expiresIn: '7d' });
      
      res.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          role: user.role,
          company_id: user.company_id,
        },
        token: jwtToken,
      });
    } catch (innerError) {
      await client.query('ROLLBACK');
      throw innerError;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Accept invite error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/invites/verify/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const result = await pool.query(
      `SELECT i.*, c.name as company_name FROM invites i 
       JOIN companies c ON i.company_id = c.id 
       WHERE i.token = $1 AND i.accepted = false AND i.expires_at > NOW()`,
      [token]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Invalid or expired invite' });
    }
    const invite = result.rows[0];
    res.json({ success: true, email: invite.email, companyName: invite.company_name, role: invite.role });
  } catch (error) {
    console.error('Verify invite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/invites', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    const result = await pool.query(
      `SELECT id, email, role, token, expires_at, accepted, created_at 
       FROM invites WHERE company_id = $1 ORDER BY created_at DESC`,
      [req.user.company_id]
    );
    res.json({ success: true, invites: result.rows });
  } catch (error) {
    console.error('List invites error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/invites', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    const { email, role } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const existing = await pool.query(
      'SELECT id FROM invites WHERE email = $1 AND company_id = $2 AND accepted = false AND expires_at > NOW()',
      [email, req.user.company_id]
    );
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'An active invite already exists for this email' });
    }

    const crypto = require('crypto');
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const result = await pool.query(
      `INSERT INTO invites (company_id, email, role, token, expires_at)
       VALUES ($1, $2, $3, $4, $5) RETURNING id, email, role, token, expires_at, created_at`,
      [req.user.company_id, email, role || 'user', token, expiresAt]
    );

    const appUrl = process.env.REPLIT_DEV_DOMAIN
      ? `https://${process.env.REPLIT_DEV_DOMAIN}`
      : process.env.REPLIT_DOMAINS
        ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
        : 'http://localhost:5000';
    const inviteUrl = `${appUrl}/invite/${token}`;

    res.json({ success: true, invite: result.rows[0], inviteUrl });
  } catch (error) {
    console.error('Create invite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/invites/:id', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    await pool.query('DELETE FROM invites WHERE id = $1 AND company_id = $2', [req.params.id, req.user.company_id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete invite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }
    
    const result = await pool.query('SELECT * FROM users WHERE LOWER(username) = LOWER($1) OR LOWER(email) = LOWER($1)', [username]);
    const user = result.rows[0];
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ id: user.id, username: user.username, role: user.role, company_id: user.company_id }, JWT_SECRET, { expiresIn: '7d' });
    
    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role,
        company_id: user.company_id,
      },
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});


app.get('/api/jobs', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const { status, search, urgent } = req.query;
    const user = req.user;
    const companyId = user.company_id;
    let result;
    
    if (user.role === 'admin' || user.role === 'owner') {
      let query = `
        SELECT j.*, 
          array_agg(DISTINCT u.name) FILTER (WHERE u.id IS NOT NULL) as assigned_trade_names
        FROM jobs j
        LEFT JOIN job_assignments ja ON j.id = ja.job_id
        LEFT JOIN users u ON ja.user_id = u.id
      `;
      const params = [companyId];
      const conditions = [`j.company_id = $1`];
      
      if (status) {
        params.push(status);
        conditions.push(`j.status = $${params.length}`);
      }
      
      if (search) {
        params.push(`%${search}%`);
        conditions.push(`(j.customer_name ILIKE $${params.length} OR j.job_number ILIKE $${params.length} OR j.address ILIKE $${params.length})`);
      }
      
      if (urgent === 'true') {
        conditions.push(`j.urgent = TRUE`);
      }
      
      query += ' WHERE ' + conditions.join(' AND ');
      
      query += ' GROUP BY j.id ORDER BY j.created_at DESC';
      result = await pool.query(query, params);
    } else {
      let query = `
        SELECT j.*, 
          array_agg(DISTINCT u.name) FILTER (WHERE u.id IS NOT NULL) as assigned_trade_names
        FROM jobs j
        INNER JOIN job_assignments ja ON j.id = ja.job_id
        LEFT JOIN users u ON ja.user_id = u.id
        WHERE ja.user_id = $1 AND j.company_id = $2
      `;
      const params = [user.id, companyId];
      
      if (status) {
        params.push(status);
        query += ` AND j.status = $${params.length}`;
      }
      
      if (search) {
        params.push(`%${search}%`);
        query += ` AND (j.customer_name ILIKE $${params.length} OR j.job_number ILIKE $${params.length} OR j.address ILIKE $${params.length})`;
      }
      
      if (urgent === 'true') {
        query += ` AND j.urgent = TRUE`;
      }
      
      query += ' GROUP BY j.id ORDER BY j.created_at DESC';
      result = await pool.query(query, params);
    }
    
    const jobs = result.rows.map(row => ({
      id: row.id,
      jobNumber: row.job_number,
      customerName: row.customer_name,
      address: row.address,
      status: row.status,
      priority: row.priority,
      urgent: row.urgent ?? false,
      estimateAmount: parseFloat(row.estimate_amount) || 0,
      startDate: row.start_date,
      completedDate: row.completed_date,
      description: row.description,
      trades: row.trades || [],
      assignedTrades: row.assigned_trade_names || [],
      door_code: row.door_code,
      key_location: row.key_location,
    }));
    
    res.json({ success: true, jobs });
  } catch (error) {
    console.error('Get jobs error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/jobs/tv-view', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const jobsResult = await pool.query(`
      SELECT 
        j.*,
        (SELECT n.text FROM notes n WHERE n.job_id = j.id ORDER BY n.created_at DESC LIMIT 1) as latest_note,
        (SELECT u.name FROM notes n LEFT JOIN users u ON n.author = u.username WHERE n.job_id = j.id ORDER BY n.created_at DESC LIMIT 1) as latest_note_by,
        (SELECT COUNT(*) FROM tasks t WHERE t.job_id = j.id AND t.completed = false)::int as pending_tasks
      FROM jobs j
      WHERE j.company_id = $1
      ORDER BY 
        CASE j.status 
          WHEN 'active' THEN 1 
          WHEN 'on_hold' THEN 2 
          WHEN 'estimate' THEN 3 
          WHEN 'completed' THEN 4 
          WHEN 'closed' THEN 5 
          ELSE 6
        END,
        j.created_at DESC
    `, [req.user.company_id]);

    const jobs = await Promise.all(jobsResult.rows.map(async (row) => {
      const assignmentsResult = await pool.query(
        'SELECT u.id, u.name, u.trade FROM users u JOIN job_assignments ja ON u.id = ja.user_id WHERE ja.job_id = $1',
        [row.id]
      );

      const tasksResult = await pool.query(
        `SELECT t.id, t.description, t.assignee_id, t.created_at, u.name as assignee_name
         FROM tasks t
         LEFT JOIN users u ON t.assignee_id = u.id
         WHERE t.job_id = $1 
           AND t.completed = false 
           AND t.created_at >= NOW() - INTERVAL '7 days'
         ORDER BY t.created_at DESC
         LIMIT 5`,
        [row.id]
      );

      return {
        id: row.id,
        client_name: row.customer_name,
        address: row.address,
        status: row.status,
        door_code: row.door_code,
        latest_note: row.latest_note,
        latest_note_by: row.latest_note_by,
        pending_tasks: row.pending_tasks || 0,
        pending_tasks_list: tasksResult.rows.map(t => ({
          id: t.id,
          description: t.description,
          assignee: t.assignee_name,
          created_at: t.created_at
        })),
        assigned_trades: assignmentsResult.rows.map(a => ({ id: a.id, name: a.name, trade: a.trade })),
      };
    }));

    res.json({ success: true, jobs });
  } catch (error) {
    console.error('TV view error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/jobs/:id', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const { id } = req.params;
    const user = req.user;
    
    const jobResult = await pool.query('SELECT * FROM jobs WHERE id = $1 AND company_id = $2', [id, user.company_id]);
    if (jobResult.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    if (user.role !== 'admin' && user.role !== 'owner') {
      const assignmentCheck = await pool.query(
        'SELECT 1 FROM job_assignments WHERE job_id = $1 AND user_id = $2',
        [id, user.id]
      );
      if (assignmentCheck.rows.length === 0) {
        return res.status(403).json({ error: 'Not assigned to this job' });
      }
    }
    
    const row = jobResult.rows[0];
    const notesResult = await pool.query('SELECT n.*, u.name as author_name, u.trade as author_trade, u.profile_picture_url as author_profile_picture_url FROM notes n LEFT JOIN users u ON n.author = u.username WHERE n.job_id = $1 ORDER BY n.created_at DESC', [id]);
    const tasksResult = await pool.query('SELECT t.*, u.name as assignee_name, u.trade as assignee_trade, u.profile_picture_url as assignee_profile_picture_url FROM tasks t LEFT JOIN users u ON t.assignee_id = u.id WHERE t.job_id = $1 ORDER BY t.completed, t.created_at', [id]);
    const teamResult = await pool.query('SELECT id, name, phone, trade, profile_picture_url FROM users WHERE role NOT IN ($1, $2) AND company_id = $3', ['admin', 'owner', user.company_id]);
    const assignmentsResult = await pool.query(
      'SELECT u.id, u.name, u.trade FROM users u JOIN job_assignments ja ON u.id = ja.user_id WHERE ja.job_id = $1',
      [id]
    );
    const photosResult = await pool.query('SELECT * FROM photos WHERE job_id = $1 ORDER BY created_at DESC', [id]);
    
    const job = {
      id: row.id,
      jobNumber: row.job_number,
      customerName: row.customer_name,
      client_name: row.customer_name,
      address: row.address,
      phone: row.phone,
      client_email: row.client_email,
      status: row.status,
      priority: row.priority,
      urgent: row.urgent ?? false,
      estimateAmount: parseFloat(row.estimate_amount) || 0,
      startDate: row.start_date,
      completedDate: row.completed_date,
      description: row.description,
      trades: row.trades || [],
      door_code: row.door_code,
      key_location: row.key_location,
      notes: notesResult.rows.map(n => ({
        id: n.id,
        text: n.text,
        timestamp: n.created_at,
        author: n.author,
        author_name: n.author_name || n.author,
        author_trade: n.author_trade,
        author_profile_picture_url: n.author_profile_picture_url,
      })),
      tasks: tasksResult.rows.map(t => ({
        id: t.id,
        description: t.description,
        assignee_id: t.assignee_id,
        assignee_name: t.assignee_name || 'Unassigned',
        assignee_trade: t.assignee_trade,
        assignee_profile_picture_url: t.assignee_profile_picture_url,
        completed: t.completed,
        completed_at: t.completed_at,
      })),
      team_members: teamResult.rows,
      assigned_trades: assignmentsResult.rows,
      photos: photosResult.rows,
    };
    
    res.json({ success: true, job, ...job });
  } catch (error) {
    console.error('Get job error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/jobs', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const companyId = req.user.company_id;
    const { customerName, address, phone, clientEmail, status, priority, estimateAmount, startDate, description, trades, doorCode, keyLocation, assignedTrades } = req.body;
    
    const year = new Date().getFullYear();
    const maxResult = await pool.query(
      `SELECT MAX(CAST(SUBSTRING(job_number FROM 'PT-${year}-(\\d+)') AS INTEGER)) as max_num FROM jobs WHERE job_number LIKE $1 AND company_id = $2`,
      [`PT-${year}-%`, companyId]
    );
    const nextNum = (maxResult.rows[0].max_num || 0) + 1;
    const jobNumber = `PT-${year}-${String(nextNum).padStart(3, '0')}`;
    
    const result = await pool.query(
      `INSERT INTO jobs (job_number, customer_name, address, phone, client_email, status, priority, estimate_amount, start_date, description, trades, door_code, key_location, created_by, company_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING *`,
      [jobNumber, customerName, address, phone, clientEmail, status || 'estimate', priority || 'medium', estimateAmount, startDate, description, trades || [], doorCode, keyLocation, req.user.id, companyId]
    );
    
    const row = result.rows[0];
    const jobId = row.id;
    
    // Store undo action for job creation
    storeUndoAction(req.user.id, {
      type: 'create_job',
      jobId,
      jobNumber,
      customerName
    });
    
    if (assignedTrades && assignedTrades.length > 0) {
      for (const tradeUserId of assignedTrades) {
        await pool.query(
          'INSERT INTO job_assignments (job_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [jobId, tradeUserId]
        );
      }
    }
    
    await logActivity(jobId, req.user.id, 'created job', `Created job ${jobNumber} for ${customerName}`);
    
    const job = {
      id: row.id,
      jobNumber: row.job_number,
      customerName: row.customer_name,
      address: row.address,
      phone: row.phone,
      client_email: row.client_email,
      status: row.status,
      priority: row.priority,
      estimateAmount: parseFloat(row.estimate_amount) || 0,
      startDate: row.start_date,
      description: row.description,
      trades: row.trades || [],
      door_code: row.door_code,
      key_location: row.key_location,
      notes: [],
    };
    
    res.json({ success: true, job, undoAvailable: true });
  } catch (error) {
    console.error('Create job error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Undo last action endpoint
app.post('/api/undo', authenticateToken, async (req, res) => {
  try {
    const action = getUndoAction(req.user.id);
    
    if (!action) {
      return res.status(400).json({ error: 'No action to undo', message: 'Undo window has expired or no recent action' });
    }
    
    let undoneDescription = '';
    
    switch (action.type) {
      case 'create_task':
        // Delete the task
        await pool.query('DELETE FROM tasks WHERE id = $1', [action.taskId]);
        await logActivity(action.jobId, req.user.id, 'undone', `Undid task creation: "${action.description}"`);
        undoneDescription = `Deleted task: "${action.description}"`;
        console.log(`↩️ Undid task creation: ${action.taskId}`);
        break;
        
      case 'create_job':
        // Delete job assignments first (foreign key constraint)
        await pool.query('DELETE FROM job_assignments WHERE job_id = $1', [action.jobId]);
        // Delete tasks
        await pool.query('DELETE FROM tasks WHERE job_id = $1', [action.jobId]);
        // Delete notes
        await pool.query('DELETE FROM notes WHERE job_id = $1', [action.jobId]);
        // Delete activity log
        await pool.query('DELETE FROM activity_log WHERE job_id = $1', [action.jobId]);
        // Delete the job
        await pool.query('DELETE FROM jobs WHERE id = $1', [action.jobId]);
        undoneDescription = `Deleted job: ${action.jobNumber} (${action.customerName})`;
        console.log(`↩️ Undid job creation: ${action.jobId} (${action.jobNumber})`);
        break;
        
      case 'change_status':
        // Revert to previous status
        await pool.query('UPDATE jobs SET status = $1 WHERE id = $2', [action.previousStatus, action.jobId]);
        await logActivity(action.jobId, req.user.id, 'undone', `Undid status change: reverted to ${action.previousStatus}`);
        undoneDescription = `Reverted status to: ${action.previousStatus}`;
        console.log(`↩️ Undid status change: ${action.jobId} back to ${action.previousStatus}`);
        break;
        
      case 'add_note':
        // Delete the note
        await pool.query('DELETE FROM notes WHERE id = $1', [action.noteId]);
        await logActivity(action.jobId, req.user.id, 'undone', 'Undid note addition');
        undoneDescription = 'Deleted note';
        console.log(`↩️ Undid note addition: ${action.noteId}`);
        break;
        
      default:
        return res.status(400).json({ error: 'Unknown action type', message: `Cannot undo action type: ${action.type}` });
    }
    
    res.json({ success: true, message: `Action undone: ${undoneDescription}`, undoneAction: action.type });
  } catch (error) {
    console.error('Undo error:', error);
    res.status(500).json({ error: 'Failed to undo action' });
  }
});

// Get undo status (check if undo is available)
app.get('/api/undo/status', authenticateToken, async (req, res) => {
  try {
    const action = undoStore.get(req.user.id);
    if (action) {
      const timeRemaining = Math.max(0, UNDO_TIMEOUT_MS - (Date.now() - action.timestamp));
      res.json({ 
        available: true, 
        type: action.type, 
        timeRemaining,
        description: action.description || action.customerName || action.jobNumber
      });
    } else {
      res.json({ available: false });
    }
  } catch (error) {
    console.error('Undo status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/jobs/:id', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const { id } = req.params;
    const { customerName, address, phone, clientEmail, client_email, status, priority, estimateAmount, startDate, description, trades, doorCode, keyLocation } = req.body;
    const emailValue = clientEmail || client_email;
    
    const result = await pool.query(
      `UPDATE jobs SET customer_name = COALESCE($1, customer_name), address = COALESCE($2, address),
       phone = COALESCE($3, phone), client_email = COALESCE($4, client_email), status = COALESCE($5, status), priority = COALESCE($6, priority), 
       estimate_amount = COALESCE($7, estimate_amount), start_date = COALESCE($8, start_date), 
       description = COALESCE($9, description), trades = COALESCE($10, trades),
       door_code = COALESCE($11, door_code), key_location = COALESCE($12, key_location),
       updated_at = CURRENT_TIMESTAMP WHERE id = $13 AND company_id = $14 RETURNING *`,
      [customerName, address, phone, emailValue, status, priority, estimateAmount, startDate, description, trades, doorCode, keyLocation, id, req.user.company_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    const row = result.rows[0];
    const job = {
      id: row.id,
      jobNumber: row.job_number,
      customerName: row.customer_name,
      address: row.address,
      phone: row.phone,
      client_email: row.client_email,
      status: row.status,
      priority: row.priority,
      estimateAmount: parseFloat(row.estimate_amount) || 0,
      startDate: row.start_date,
      description: row.description,
      trades: row.trades || [],
      door_code: row.door_code,
      key_location: row.key_location,
    };
    
    const changes = [];
    if (customerName) changes.push('customer name');
    if (address) changes.push('address');
    if (phone) changes.push('phone');
    if (client_email) changes.push('client email');
    if (description) changes.push('description');
    if (doorCode) changes.push('door code');
    if (keyLocation) changes.push('key location');
    if (priority) changes.push('priority');
    if (estimateAmount) changes.push('estimate amount');
    
    if (changes.length > 0) {
      await logActivity(id, req.user.id, 'updated job', `Changed: ${changes.join(', ')}`);
    }
    
    res.json({ success: true, job });
  } catch (error) {
    console.error('Update job error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/jobs/:id', authenticateToken, async (req, res) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    
    await client.query('BEGIN');
    
    const jobInfo = await client.query('SELECT customer_name, job_number FROM jobs WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (jobInfo.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    await client.query('DELETE FROM job_assignments WHERE job_id = $1', [id]);
    await client.query('DELETE FROM tasks WHERE job_id = $1', [id]);
    await client.query('DELETE FROM notes WHERE job_id = $1', [id]);
    await client.query('DELETE FROM activity_logs WHERE job_id = $1', [id]);
    await client.query('DELETE FROM photos WHERE job_id = $1', [id]);
    await client.query('DELETE FROM jobs WHERE id = $1', [id]);
    
    await client.query('COMMIT');
    
    console.log(`Job ${jobInfo.rows[0].job_number} deleted by user ${req.user.id}`);
    
    res.json({ success: true, message: 'Job deleted successfully' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Delete job error:', error);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// Job Photos Upload
app.post('/api/jobs/:id/photos', authenticateToken, upload.single('photo'), async (req, res) => {
  try {
    const { id } = req.params;
    const file = req.file;
    
    if (!file) {
      return res.status(400).json({ error: 'No photo uploaded' });
    }
    
    const jobCheck = await pool.query('SELECT id FROM jobs WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (jobCheck.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    const photoPath = `/uploads/profiles/${file.filename}`;
    
    const result = await pool.query(
      'INSERT INTO photos (job_id, path, uploaded_by, company_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [id, photoPath, req.user.username, req.user.company_id]
    );
    
    await logActivity(id, req.user.id, 'added a photo');
    
    res.json({ success: true, photo: result.rows[0] });
  } catch (error) {
    console.error('Upload job photo error:', error);
    res.status(500).json({ error: 'Upload failed' });
  }
});

// Get Job Photos
app.get('/api/jobs/:id/photos', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT * FROM photos WHERE job_id = $1 ORDER BY created_at DESC',
      [id]
    );
    res.json({ success: true, photos: result.rows });
  } catch (error) {
    console.error('Get job photos error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete Photo
app.delete('/api/photos/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin only' });
    }
    
    const { id } = req.params;
    
    const photoResult = await pool.query('SELECT * FROM photos WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (photoResult.rows.length === 0) {
      return res.status(404).json({ error: 'Photo not found' });
    }
    
    const photo = photoResult.rows[0];
    
    // Delete file from filesystem
    const filePath = path.join(__dirname, '..', photo.path.replace(/^\//, ''));
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    
    await pool.query('DELETE FROM photos WHERE id = $1', [id]);
    await logActivity(photo.job_id, req.user.id, 'deleted a photo');
    
    res.json({ success: true });
  } catch (error) {
    console.error('Delete photo error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/jobs/:id/status', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    const validStatuses = ['estimate', 'active', 'completed', 'on_hold', 'closed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const previousResult = await pool.query('SELECT status FROM jobs WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    const previousStatus = previousResult.rows[0]?.status;
    
    let completedDate = null;
    if (status === 'completed' || status === 'closed') {
      completedDate = new Date();
    }
    
    const statusLabels = {
      estimate: 'Needs Estimate',
      active: 'In Progress',
      completed: 'Completed',
      on_hold: 'On Hold',
      closed: 'Closed (Archived)'
    };
    
    const result = await pool.query(
      'UPDATE jobs SET status = $1, completed_date = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 AND company_id = $4 RETURNING *',
      [status, completedDate, id, req.user.company_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    // Store undo action for status change
    if (previousStatus && previousStatus !== status) {
      storeUndoAction(req.user.id, {
        type: 'change_status',
        jobId: parseInt(id),
        previousStatus,
        newStatus: status
      });
    }
    
    await logActivity(id, req.user.id, `changed status to ${statusLabels[status] || status}`);
    
    res.json({ success: true, job: result.rows[0], undoAvailable: true });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/jobs/:id/urgent', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { urgent } = req.body;
    
    const result = await pool.query(
      'UPDATE jobs SET urgent = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND company_id = $3 RETURNING *',
      [urgent, id, req.user.company_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    await logActivity(id, req.user.id, urgent ? 'marked job as URGENT' : 'removed urgent status');
    
    if (urgent) {
      const tradesResult = await pool.query(`
        SELECT DISTINCT u.id, u.name FROM users u 
        JOIN job_trades jt ON u.trade = jt.trade_name 
        WHERE jt.job_id = $1 AND u.role != 'admin'
      `, [id]);
      
      const job = result.rows[0];
      for (const user of tradesResult.rows) {
        sendNotification('urgent', user.id,
          `URGENT: Job at ${job.address || 'Unknown'} (${job.customer_name || 'Unknown'}) marked as urgent!`,
          'ProTrack - URGENT JOB'
        );
      }
    }
    
    res.json({ success: true, job: result.rows[0] });
  } catch (error) {
    console.error('Update urgent error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/jobs/:id/trades', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { trades } = req.body;
    
    const result = await pool.query(
      'UPDATE jobs SET trades = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND company_id = $3 RETURNING *',
      [trades, id, req.user.company_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    if (trades && trades.length > 0) {
      await logActivity(id, req.user.id, 'assigned trades', `Assigned to: ${trades.join(', ')}`);
    }
    
    res.json({ success: true, job: result.rows[0] });
  } catch (error) {
    console.error('Update trades error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update job assignments (which workers can see this job)
app.put('/api/jobs/:id/assignments', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { assignedUserIds } = req.body;
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Only administrators can change job assignments' });
    }
    
    const jobResult = await pool.query('SELECT id, customer_name FROM jobs WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (jobResult.rows.length === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }
    
    // Get current assignments to compare
    const currentResult = await pool.query(
      'SELECT u.id, u.name FROM users u JOIN job_assignments ja ON u.id = ja.user_id WHERE ja.job_id = $1',
      [id]
    );
    const currentIds = currentResult.rows.map(r => r.id);
    const newIds = assignedUserIds || [];
    
    // Find added and removed
    const added = newIds.filter(uid => !currentIds.includes(uid));
    const removed = currentIds.filter(uid => !newIds.includes(uid));
    
    // Delete removed assignments
    if (removed.length > 0) {
      await pool.query(
        'DELETE FROM job_assignments WHERE job_id = $1 AND user_id = ANY($2)',
        [id, removed]
      );
    }
    
    // Insert new assignments
    for (const userId of added) {
      await pool.query(
        'INSERT INTO job_assignments (job_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [id, userId]
      );
    }
    
    // Get updated assignments with names
    const updatedResult = await pool.query(
      'SELECT u.id, u.name, u.trade FROM users u JOIN job_assignments ja ON u.id = ja.user_id WHERE ja.job_id = $1',
      [id]
    );
    
    // Log activity
    if (added.length > 0 || removed.length > 0) {
      const addedNames = await pool.query('SELECT name FROM users WHERE id = ANY($1)', [added]);
      const removedNames = await pool.query('SELECT name FROM users WHERE id = ANY($1)', [removed]);
      
      let details = [];
      if (addedNames.rows.length > 0) {
        details.push(`Added: ${addedNames.rows.map(r => r.name).join(', ')}`);
      }
      if (removedNames.rows.length > 0) {
        details.push(`Removed: ${removedNames.rows.map(r => r.name).join(', ')}`);
      }
      
      await logActivity(id, req.user.id, 'updated job visibility', details.join('; '));
    }
    
    res.json({ 
      success: true, 
      assigned_trades: updatedResult.rows 
    });
  } catch (error) {
    console.error('Update assignments error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all workers and their assigned jobs (admin overview)
app.get('/api/admin/worker-jobs', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    const result = await pool.query(`
      SELECT 
        u.id as user_id,
        u.name as user_name,
        u.trade,
        u.phone,
        u.email,
        COALESCE(
          json_agg(
            json_build_object(
              'id', j.id,
              'customer_name', j.customer_name,
              'address', j.address,
              'status', j.status,
              'urgent', j.urgent,
              'door_code', j.door_code
            ) ORDER BY j.urgent DESC NULLS LAST, j.updated_at DESC
          ) FILTER (WHERE j.id IS NOT NULL),
          '[]'
        ) as jobs
      FROM users u
      LEFT JOIN job_assignments ja ON u.id = ja.user_id
      LEFT JOIN jobs j ON ja.job_id = j.id
      WHERE u.role NOT IN ('admin', 'owner') AND u.company_id = $1
      GROUP BY u.id, u.name, u.trade, u.phone, u.email
      ORDER BY u.name
    `, [req.user.company_id]);
    
    res.json({ workers: result.rows });
  } catch (error) {
    console.error('Get worker jobs error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/jobs/:id/notes', authenticateToken, upload.array('photo', 10), async (req, res) => {
  try {
    const { id } = req.params;
    const { text } = req.body;
    const files = req.files || [];
    
    const userResult = await pool.query('SELECT name FROM users WHERE id = $1', [req.user.id]);
    const authorName = userResult.rows[0]?.name || req.user.username;
    
    // Handle file uploads - support multiple files
    let photoPath = null;
    let attachments = [];
    
    if (files.length > 0) {
      attachments = files.map(file => ({
        path: `/uploads/profiles/${file.filename}`,
        name: file.originalname,
        type: file.mimetype,
        size: file.size
      }));
      // Keep first image as photoPath for backwards compatibility
      const firstImage = files.find(f => f.mimetype.startsWith('image/'));
      if (firstImage) {
        photoPath = `/uploads/profiles/${firstImage.filename}`;
      }
    }
    
    const result = await pool.query(
      'INSERT INTO notes (job_id, user_id, text, author, photo_path, attachments, company_id) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [id, req.user.id, text, authorName, photoPath, JSON.stringify(attachments), req.user.company_id]
    );
    
    // Match @Name or @FirstName LastName (with optional space and second word)
    const mentionRegex = /@([A-Za-z]+(?:\s+[A-Za-z]+)?)/gi;
    const mentions = text.match(mentionRegex) || [];
    const tasksCreated = [];
    const mentionsForNotification = [];
    
    console.log('Checking mentions in note:', mentions);
    
    const allUsersResult = await pool.query(
      'SELECT id, name, phone, username FROM users WHERE company_id = $1',
      [req.user.company_id]
    );
    const allUsers = allUsersResult.rows;
    
    for (const mention of mentions) {
      const searchTerm = mention.substring(1).toLowerCase(); // Remove @ and lowercase
      
      const fuzzyMatch = nameMatching.findBestMatch(searchTerm, allUsers);
      let matchedUser = null;
      
      if (fuzzyMatch.match) {
        matchedUser = fuzzyMatch.match;
        console.log(`Fuzzy matched @${searchTerm} to ${fuzzyMatch.match.name} (confidence: ${fuzzyMatch.confidence}, reason: ${fuzzyMatch.matchType})`);
      } else {
        const fallbackResult = await pool.query(
          `SELECT id, name, phone, username FROM users 
           WHERE LOWER(name) LIKE $1 
           OR LOWER(username) LIKE $1
           OR LOWER(SPLIT_PART(name, ' ', 1)) = $2
           ORDER BY 
             CASE WHEN LOWER(SPLIT_PART(name, ' ', 1)) = $2 THEN 0
                  WHEN LOWER(username) = $2 THEN 1
                  ELSE 2 END
           LIMIT 1`,
          [`%${searchTerm}%`, searchTerm]
        );
        if (fallbackResult.rows.length > 0) {
          matchedUser = fallbackResult.rows[0];
          console.log(`Fallback search matched @${searchTerm}:`, matchedUser.name);
        }
      }
      
      if (matchedUser) {
        const taskText = text.replace(mention, '').trim().replace(/@\w+/g, '').trim();
        
        if (taskText) {
          const taskResult = await pool.query(
            'INSERT INTO tasks (job_id, description, assignee_id, created_by) VALUES ($1, $2, $3, $4) RETURNING *',
            [id, taskText, matchedUser.id, req.user.id]
          );
          tasksCreated.push({ task: taskResult.rows[0], user: matchedUser });
          
          mentionsForNotification.push({
            userId: matchedUser.id,
            name: matchedUser.name,
            phone: matchedUser.phone,
            task: taskText
          });
        } else {
          tasksCreated.push({ user: matchedUser, notificationOnly: true });
          mentionsForNotification.push({
            userId: matchedUser.id,
            name: matchedUser.name,
            phone: matchedUser.phone,
            action: `mentioned in note`
          });
        }
      }
    }
    
    let notificationResults = null;
    if (mentionsForNotification.length > 0) {
      notificationResults = await notificationService.processMentions(
        mentionsForNotification,
        id,
        authorName,
        text,
        attachments
      );
      console.log('Smart notification results:', JSON.stringify(notificationResults, null, 2));
    }
    
    // Store undo action for note creation
    storeUndoAction(req.user.id, {
      type: 'add_note',
      noteId: result.rows[0].id,
      jobId: parseInt(id),
      text: text?.substring(0, 50) || 'Note'
    });
    
    await logActivity(id, req.user.id, 'added note', text);
    
    const note = {
      id: result.rows[0].id,
      text: result.rows[0].text,
      date: result.rows[0].created_at.toISOString().split('T')[0],
      author: result.rows[0].author,
      attachments: attachments,
    };
    
    res.json({ success: true, note, tasksCreated, notificationResults, undoAvailable: true });
  } catch (error) {
    console.error('Add note error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/notes/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    const { id } = req.params;
    
    const noteResult = await pool.query('SELECT * FROM notes WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (noteResult.rows.length === 0) {
      return res.status(404).json({ error: 'Note not found' });
    }
    
    const note = noteResult.rows[0];
    
    // Delete the photo file if exists
    if (note.photo_path) {
      const filePath = path.join(__dirname, '..', note.photo_path.replace(/^\//, ''));
      fs.unlink(filePath, () => {});
    }
    
    await pool.query('DELETE FROM notes WHERE id = $1', [id]);
    await logActivity(note.job_id, req.user.id, 'deleted a note', `Note by ${note.author}`);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Delete note error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/activity/:id', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    const { id } = req.params;
    
    const result = await pool.query('DELETE FROM activity_logs WHERE id = $1 AND company_id = $2 RETURNING *', [id, req.user.company_id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Activity not found' });
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Delete activity error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/my-tasks', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT t.*, j.customer_name, j.address, j.job_number, u.name as assignee_name
      FROM tasks t
      JOIN jobs j ON t.job_id = j.id
      LEFT JOIN users u ON t.assignee_id = u.id
      WHERE t.assignee_id = $1
      ORDER BY t.completed, t.created_at DESC
    `, [req.user.id]);
    
    res.json({ success: true, tasks: result.rows });
  } catch (error) {
    console.error('Get my tasks error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/job-overview', authenticateToken, async (req, res) => {
  try {
    const user = req.user;
    let jobsQuery;
    let jobsParams = [];
    
    if (user.role === 'admin' || user.role === 'owner') {
      jobsQuery = `
        SELECT j.id, j.job_number, j.customer_name, j.address, j.status, j.urgent
        FROM jobs j
        WHERE j.status IN ('active', 'estimate', 'on_hold') AND j.company_id = $1
        ORDER BY j.urgent DESC, j.created_at DESC
      `;
      jobsParams = [user.company_id];
    } else {
      jobsQuery = `
        SELECT j.id, j.job_number, j.customer_name, j.address, j.status, j.urgent
        FROM jobs j
        INNER JOIN job_assignments ja ON j.id = ja.job_id
        WHERE ja.user_id = $1 AND j.status IN ('active', 'estimate', 'on_hold') AND j.company_id = $2
        ORDER BY j.urgent DESC, j.created_at DESC
      `;
      jobsParams = [user.id, user.company_id];
    }
    
    const jobsResult = await pool.query(jobsQuery, jobsParams);
    
    const overview = [];
    
    for (const job of jobsResult.rows) {
      let assignmentsQuery;
      let assignmentsParams;
      let tasksQuery;
      let tasksParams;
      
      if (user.role === 'admin' || user.role === 'owner') {
        assignmentsQuery = `
          SELECT u.id, u.name, u.trade
          FROM users u
          JOIN job_assignments ja ON u.id = ja.user_id
          WHERE ja.job_id = $1
          ORDER BY u.name
        `;
        assignmentsParams = [job.id];
        
        tasksQuery = `
          SELECT t.id, t.description, t.completed, t.completed_at, t.created_at, t.assignee_id,
                 u.name as assignee_name, u.trade as assignee_trade
          FROM tasks t
          LEFT JOIN users u ON t.assignee_id = u.id
          WHERE t.job_id = $1
          ORDER BY t.completed, t.created_at DESC
        `;
        tasksParams = [job.id];
      } else {
        assignmentsQuery = `
          SELECT u.id, u.name, u.trade
          FROM users u
          WHERE u.id = $1
        `;
        assignmentsParams = [user.id];
        
        tasksQuery = `
          SELECT t.id, t.description, t.completed, t.completed_at, t.created_at, t.assignee_id,
                 u.name as assignee_name, u.trade as assignee_trade
          FROM tasks t
          LEFT JOIN users u ON t.assignee_id = u.id
          WHERE t.job_id = $1 AND t.assignee_id = $2
          ORDER BY t.completed, t.created_at DESC
        `;
        tasksParams = [job.id, user.id];
      }
      
      const assignmentsResult = await pool.query(assignmentsQuery, assignmentsParams);
      const tasksResult = await pool.query(tasksQuery, tasksParams);
      
      const workerTasks = {};
      assignmentsResult.rows.forEach(worker => {
        workerTasks[worker.id] = {
          id: worker.id,
          name: worker.name,
          trade: worker.trade,
          tasks: []
        };
      });
      
      tasksResult.rows.forEach(task => {
        if (task.assignee_id && workerTasks[task.assignee_id]) {
          workerTasks[task.assignee_id].tasks.push({
            id: task.id,
            description: task.description,
            completed: task.completed,
            completed_at: task.completed_at,
            created_at: task.created_at
          });
        }
      });
      
      overview.push({
        id: job.id,
        jobNumber: job.job_number,
        customerName: job.customer_name,
        address: job.address,
        status: job.status,
        urgent: job.urgent,
        workers: Object.values(workerTasks)
      });
    }
    
    res.json({ success: true, jobs: overview });
  } catch (error) {
    console.error('Get job overview error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const cid = req.user.company_id;
    const [activeResult, estimateResult, urgentResult, holdResult, pendingTasksResult, completedResult, revenueResult] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM jobs WHERE status = 'active' AND company_id = $1", [cid]),
      pool.query("SELECT COUNT(*) FROM jobs WHERE status = 'estimate' AND company_id = $1", [cid]),
      pool.query("SELECT COUNT(*) FROM jobs WHERE urgent = true AND status NOT IN ('done','closed','completed') AND company_id = $1", [cid]),
      pool.query("SELECT COUNT(*) FROM jobs WHERE status = 'on_hold' AND company_id = $1", [cid]),
      pool.query("SELECT COUNT(*) FROM tasks t JOIN jobs j ON t.job_id = j.id WHERE t.completed = false AND j.company_id = $1", [cid]),
      pool.query("SELECT COUNT(*) FROM jobs WHERE status IN ('done','completed') AND completed_date >= date_trunc('month', CURRENT_DATE) AND company_id = $1", [cid]),
      pool.query("SELECT COALESCE(SUM(estimate_amount), 0) as total FROM jobs WHERE status IN ('done','completed') AND company_id = $1", [cid]),
    ]);
    
    res.json({
      jobs: {
        active_jobs: parseInt(activeResult.rows[0].count),
        needs_estimate: parseInt(estimateResult.rows[0].count),
        urgent_jobs: parseInt(urgentResult.rows[0].count),
        on_hold: parseInt(holdResult.rows[0].count),
        completed_this_month: parseInt(completedResult.rows[0].count),
      },
      tasks: {
        pending_tasks: parseInt(pendingTasksResult.rows[0].count),
      },
      totalRevenue: parseFloat(revenueResult.rows[0].total) || 0,
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Natural language search endpoint
app.get('/api/search', authenticateToken, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.trim().length < 2) {
      return res.json({ success: true, results: [], query: q });
    }
    
    const query = q.toLowerCase().trim();
    const results = [];
    
    if (!requireCompany(req, res)) return;
    const teamResult = await pool.query('SELECT id, name, trade FROM users WHERE role NOT IN ($1, $2) AND company_id = $3', ['admin', 'owner', req.user.company_id]);
    const teamMembers = teamResult.rows;
    
    // Extract potential person name from query
    const mentionedPerson = nameMatching.extractMentions(query)[0]?.name ||
      query.match(/(?:did|has|is|what|show|find)\s+(\w+)\s/i)?.[1] ||
      query.match(/(?:for|by|from)\s+(\w+)/i)?.[1];
    
    let personFilter = null;
    if (mentionedPerson) {
      const match = nameMatching.findBestMatch(mentionedPerson, teamMembers);
      if (match.match && match.confidence >= 0.7) {
        personFilter = match.match;
      }
    }
    
    // Extract address/location from query
    const addressMatch = query.match(/(?:at|on)\s+([\d]+[^,?]*)/i);
    const addressFilter = addressMatch ? addressMatch[1].trim() : null;
    
    // Extract status keywords
    const statusKeywords = {
      'done': 'completed', 'finished': 'completed', 'complete': 'completed', 'completed': 'completed',
      'active': 'active', 'ongoing': 'active', 'current': 'active',
      'waiting': 'on_hold', 'hold': 'on_hold', 'paused': 'on_hold',
      'estimate': 'estimate', 'pending': 'estimate'
    };
    let statusFilter = null;
    for (const [keyword, status] of Object.entries(statusKeywords)) {
      if (query.includes(keyword)) {
        statusFilter = status;
        break;
      }
    }
    
    // Build SQL query
    let sqlQuery = `
      SELECT j.*, 
        array_agg(DISTINCT u.name) FILTER (WHERE u.id IS NOT NULL) as assigned_trade_names
      FROM jobs j
      LEFT JOIN job_assignments ja ON j.id = ja.job_id
      LEFT JOIN users u ON ja.user_id = u.id
    `;
    const params = [req.user.company_id];
    const conditions = [`j.company_id = $1`];
    
    if (addressFilter) {
      params.push('%' + addressFilter + '%');
      conditions.push(`j.address ILIKE $${params.length}`);
    }
    
    if (statusFilter) {
      params.push(statusFilter);
      conditions.push(`j.status = $${params.length}`);
    }
    
    // Search by customer name
    const clientMatch = query.match(/(\w+)\s+job/i)?.[1] || 
      query.match(/job\s+(?:for|with)\s+(\w+)/i)?.[1];
    if (clientMatch) {
      params.push('%' + clientMatch + '%');
      conditions.push(`j.customer_name ILIKE $${params.length}`);
    }
    
    if (personFilter) {
      params.push(personFilter.id);
      conditions.push(`ja.user_id = $${params.length}`);
    }
    
    if (conditions.length > 0) {
      sqlQuery += ' WHERE ' + conditions.join(' AND ');
    }
    
    sqlQuery += ' GROUP BY j.id ORDER BY j.updated_at DESC LIMIT 10';
    
    const jobsResult = await pool.query(sqlQuery, params);
    
    // Format results
    for (const job of jobsResult.rows) {
      // Get tasks for this job if person filter is applied
      let taskInfo = '';
      if (personFilter) {
        const tasksResult = await pool.query(
          `SELECT t.*, u.name as assignee_name 
           FROM tasks t 
           LEFT JOIN users u ON t.assignee_id = u.id 
           WHERE t.job_id = $1 AND t.assignee_id = $2
           ORDER BY t.created_at DESC`,
          [job.id, personFilter.id]
        );
        
        if (tasksResult.rows.length > 0) {
          const completedCount = tasksResult.rows.filter(t => t.completed).length;
          const totalCount = tasksResult.rows.length;
          taskInfo = `${completedCount}/${totalCount} tasks done`;
          
          // Check if specific task mentioned
          const taskKeywords = ['tile', 'paint', 'fix', 'install', 'finish', 'repair', 'check', 'replace'];
          for (const keyword of taskKeywords) {
            if (query.includes(keyword)) {
              const matchingTask = tasksResult.rows.find(t => 
                t.description?.toLowerCase().includes(keyword)
              );
              if (matchingTask) {
                taskInfo = matchingTask.completed 
                  ? `✅ ${personFilter.name} completed ${keyword} on ${new Date(matchingTask.updated_at).toLocaleDateString()}`
                  : `⏳ ${keyword} task pending for ${personFilter.name}`;
              }
            }
          }
        }
      }
      
      results.push({
        id: job.id,
        type: 'job',
        title: job.customer_name,
        subtitle: job.address,
        status: job.status,
        taskInfo: taskInfo || null,
        assignees: job.assigned_trade_names || []
      });
    }
    
    // If no results but we have a person, search for their tasks across all jobs
    if (results.length === 0 && personFilter) {
      const tasksResult = await pool.query(
        `SELECT t.*, j.customer_name, j.address, j.id as job_id, u.name as assignee_name 
         FROM tasks t 
         JOIN jobs j ON t.job_id = j.id
         LEFT JOIN users u ON t.assignee_id = u.id 
         WHERE t.assignee_id = $1 AND j.company_id = $2
         ORDER BY t.created_at DESC
         LIMIT 10`,
        [personFilter.id, req.user.company_id]
      );
      
      for (const task of tasksResult.rows) {
        results.push({
          id: task.id,
          type: 'task',
          title: task.description,
          subtitle: `${task.customer_name} - ${task.address}`,
          status: task.completed ? 'completed' : 'pending',
          jobId: task.job_id
        });
      }
    }
    
    res.json({ 
      success: true, 
      results,
      query: q,
      interpretation: {
        person: personFilter?.name || null,
        address: addressFilter,
        status: statusFilter
      }
    });
    
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Search failed' });
  }
});

// Export job to Google Docs format (text download)
// Note: Also accepts token via query param for browser direct download
app.get('/api/jobs/:id/export', async (req, res, next) => {
  // Allow token via query param for direct browser downloads
  if (req.query.token && !req.headers.authorization) {
    req.headers.authorization = `Bearer ${req.query.token}`;
  }
  authenticateToken(req, res, async () => {
    try {
      const { id } = req.params;
    
    // Get job with all details
    const jobResult = await pool.query(`
      SELECT j.*, 
        array_agg(DISTINCT jsonb_build_object('id', u.id, 'name', u.name, 'trade', u.trade)) 
          FILTER (WHERE u.id IS NOT NULL) as assigned_workers
      FROM jobs j
      LEFT JOIN job_assignments ja ON j.id = ja.job_id
      LEFT JOIN users u ON ja.user_id = u.id
      WHERE j.id = $1 AND j.company_id = $2
      GROUP BY j.id
    `, [id, req.user.company_id]);
    
    if (jobResult.rows.length === 0) {
      return res.status(404).json({ 
      error: 'Could not find that job. It may have been deleted or you may not have access to it.',
      code: 'JOB_NOT_FOUND'
    });
    }
    
    const job = jobResult.rows[0];
    
    // Get notes
    const notesResult = await pool.query(
      'SELECT * FROM notes WHERE job_id = $1 ORDER BY created_at DESC',
      [id]
    );
    
    // Get tasks grouped by assignee
    const tasksResult = await pool.query(`
      SELECT t.*, u.name as assignee_name, u.trade as assignee_trade
      FROM tasks t
      LEFT JOIN users u ON t.assignee_id = u.id
      WHERE t.job_id = $1
      ORDER BY u.name, t.created_at
    `, [id]);
    
    // Format for Google Docs style
    const formatDate = (date) => {
      if (!date) return '';
      return new Date(date).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: '2-digit' });
    };
    
    let output = '';
    
    // Header
    output += `${job.customer_name?.toUpperCase() || 'UNTITLED'} - ${formatDate(job.created_at)}\n`;
    output += '═'.repeat(50) + '\n\n';
    
    // Contact info
    output += 'CONTACT INFORMATION\n';
    output += '─'.repeat(30) + '\n';
    output += `Address: ${job.address || 'N/A'}\n`;
    output += `Phone: ${job.phone || 'N/A'}\n`;
    output += `Access: ${job.door_code ? `Door code: ${job.door_code}` : job.key_location || 'N/A'}\n`;
    output += `Status: ${job.status?.toUpperCase() || 'UNKNOWN'}\n`;
    if (job.estimate_amount) {
      output += `Estimate: $${job.estimate_amount.toLocaleString()}\n`;
    }
    output += '\n';
    
    // Scope/Description
    if (job.description) {
      output += 'SCOPE\n';
      output += '─'.repeat(30) + '\n';
      output += job.description + '\n\n';
    }
    
    // Tasks by trade
    if (tasksResult.rows.length > 0) {
      output += 'TASKS BY TRADE\n';
      output += '─'.repeat(30) + '\n';
      
      // Group by assignee
      const tasksByPerson = {};
      for (const task of tasksResult.rows) {
        const key = task.assignee_name 
          ? `${task.assignee_name} (${task.assignee_trade || 'General'})`
          : 'Unassigned';
        if (!tasksByPerson[key]) tasksByPerson[key] = [];
        tasksByPerson[key].push(task);
      }
      
      for (const [person, tasks] of Object.entries(tasksByPerson)) {
        output += `\n${person}:\n`;
        for (const task of tasks) {
          const checkbox = task.completed ? '☑' : '☐';
          output += `  ${checkbox} ${task.description}\n`;
        }
      }
      output += '\n';
    }
    
    // Notes/Updates
    if (notesResult.rows.length > 0) {
      output += 'NOTES & UPDATES\n';
      output += '─'.repeat(30) + '\n';
      
      for (const note of notesResult.rows) {
        const noteDate = formatDate(note.created_at);
        const noteTime = new Date(note.created_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        output += `\n[${noteDate} ${noteTime}] ${note.author || 'Unknown'}:\n`;
        output += `${note.text}\n`;
      }
    }
    
    // Footer
    output += '\n' + '═'.repeat(50) + '\n';
    const birminghamDate = new Date().toLocaleString('en-US', {
      timeZone: 'America/Chicago',
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
    output += `Exported from ProTrack on ${birminghamDate}\n`;
    
    // Send as downloadable text file
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${job.customer_name?.replace(/[^a-z0-9]/gi, '_') || 'job'}_${job.job_number || id}.txt"`);
    res.send(output);
    
    } catch (error) {
      console.error('Export error:', error);
      res.status(500).json({ error: 'Export failed' });
    }
  });
});

app.get('/api/settings', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query('SELECT * FROM settings WHERE company_id = $1', [req.user.company_id]);
    const settings = {};
    result.rows.forEach(row => {
      settings[row.key] = row.value === 'true' ? true : row.value === 'false' ? false : row.value;
    });
    
    res.json({ success: true, settings });
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/settings', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const { key, value } = req.body;
    
    await pool.query(
      'INSERT INTO settings (key, value, company_id) VALUES ($1, $2, $3) ON CONFLICT (key, company_id) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP',
      [key, String(value), req.user.company_id]
    );
    
    const result = await pool.query('SELECT * FROM settings WHERE company_id = $1', [req.user.company_id]);
    const settings = {};
    result.rows.forEach(row => {
      settings[row.key] = row.value === 'true' ? true : row.value === 'false' ? false : row.value;
    });
    
    res.json({ success: true, settings });
  } catch (error) {
    console.error('Update setting error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/twilio/status', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const cid = req.user.company_id;
    const result = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_twilio%', cid]);
    const config = {};
    result.rows.forEach(row => { config[row.key] = row.value; });
    
    const twilioSid = process.env.TWILIO_ACCOUNT_SID || config.notification_twilio_sid;
    const twilioToken = process.env.TWILIO_AUTH_TOKEN || (config.notification_twilio_token ? decrypt(config.notification_twilio_token) : null);
    const twilioPhone = process.env.TWILIO_PHONE_NUMBER || config.notification_twilio_phone;
    
    const a2pResult = await pool.query('SELECT value FROM settings WHERE key = $1 AND company_id = $2', ['twilio_a2p_approved', cid]);
    const a2pApproved = a2pResult.rows[0]?.value === 'true';
    
    res.json({
      configured: !!(twilioSid && twilioToken && twilioPhone),
      phone: twilioPhone || null,
      a2pApproved
    });
  } catch (error) {
    console.error('Get Twilio status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/twilio/a2p', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    const { approved } = req.body;
    
    await pool.query(
      `INSERT INTO settings (key, value, company_id, updated_at) VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
       ON CONFLICT (key, company_id) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP`,
      ['twilio_a2p_approved', approved ? 'true' : 'false', req.user.company_id]
    );
    
    console.log(`📱 A2P registration status updated: ${approved ? 'approved' : 'not approved'}`);
    res.json({ success: true, a2pApproved: approved });
  } catch (error) {
    console.error('Update A2P status error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/twilio/test', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    const { phone } = req.body;
    if (!phone) {
      return res.status(400).json({ error: 'Phone number is required' });
    }
    
    const result = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_twilio%', req.user.company_id]);
    const config = {};
    result.rows.forEach(row => { config[row.key] = row.value; });
    
    const twilioSid = process.env.TWILIO_ACCOUNT_SID || config.notification_twilio_sid;
    const twilioToken = process.env.TWILIO_AUTH_TOKEN || (config.notification_twilio_token ? decrypt(config.notification_twilio_token) : null);
    const twilioPhone = process.env.TWILIO_PHONE_NUMBER || config.notification_twilio_phone;
    
    if (!twilioSid || !twilioToken || !twilioPhone) {
      return res.json({ success: false, error: 'Twilio not configured. Add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER to secrets.' });
    }
    
    let formattedPhone = phone.replace(/[^\d+]/g, '');
    if (!formattedPhone.startsWith('+')) {
      if (formattedPhone.length === 10) {
        formattedPhone = '+1' + formattedPhone;
      } else if (formattedPhone.length === 11 && formattedPhone.startsWith('1')) {
        formattedPhone = '+' + formattedPhone;
      }
    }
    
    const twilio = require('twilio')(twilioSid, twilioToken);
    const message = await twilio.messages.create({
      body: 'ProTrack test - SMS notifications are working!',
      from: twilioPhone,
      to: formattedPhone
    });
    
    console.log(`📱 Test SMS sent to ${formattedPhone} (SID: ${message.sid})`);
    res.json({ success: true, message: `Test SMS sent to ${formattedPhone}` });
  } catch (error) {
    console.error('Test SMS error:', error);
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/notifications/config', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_%', req.user.company_id]);
    const config = {};
    result.rows.forEach(row => {
      config[row.key] = row.value;
    });
    
    const emailConfigured = config.notification_email_provider && config.notification_email_address;
    const smsConfigured = (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_PHONE_NUMBER) || (config.notification_twilio_sid && config.notification_twilio_phone);
    
    res.json({
      email: {
        configured: !!emailConfigured,
        provider: config.notification_email_provider || null,
        address: config.notification_email_address || null
      },
      sms: {
        configured: !!smsConfigured,
        phone: config.notification_twilio_phone || null
      }
    });
  } catch (error) {
    console.error('Get notification config error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/notifications/config/email', authenticateToken, async (req, res) => {
  try {
    const { provider, email, server, port, username, password } = req.body;
    
    const encryptedPassword = encrypt(password);
    
    const updates = [
      ['notification_email_provider', provider],
      ['notification_email_address', email],
      ['notification_smtp_server', server || ''],
      ['notification_smtp_port', String(port || 587)],
      ['notification_smtp_username', username || ''],
      ['notification_smtp_password', encryptedPassword]
    ];
    
    for (const [key, value] of updates) {
      await pool.query(
        'INSERT INTO settings (key, value, company_id) VALUES ($1, $2, $3) ON CONFLICT (key, company_id) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP',
        [key, value, req.user.company_id]
      );
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Save email config error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/notifications/config/email', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    await pool.query('DELETE FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_email_%', req.user.company_id]);
    await pool.query('DELETE FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_smtp_%', req.user.company_id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete email config error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Multi-email account management
app.get('/api/email-accounts', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, smtp_server, smtp_port, status, last_error, last_tested_at, is_primary, created_at FROM email_accounts WHERE company_id = $1 ORDER BY is_primary DESC, created_at ASC', [req.user.company_id]
    );
    res.json({ success: true, accounts: result.rows });
  } catch (error) {
    console.error('Get email accounts error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/email-accounts', authenticateToken, async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ 
        error: 'Email and app password are required',
        troubleshooting: [
          'Make sure you entered your full Gmail address (e.g., yourname@gmail.com)',
          'The app password should be 16 characters without spaces'
        ]
      });
    }
    
    if (!email.includes('@')) {
      return res.status(400).json({ 
        error: 'Please enter a valid email address',
        troubleshooting: [
          'Enter your full email address (e.g., yourname@gmail.com)',
          'Gmail and Google Workspace emails are supported'
        ]
      });
    }
    
    const existing = await pool.query('SELECT id FROM email_accounts WHERE email = $1 AND company_id = $2', [email, req.user.company_id]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ 
        error: 'This email is already connected',
        troubleshooting: [
          'Each email can only be added once',
          'If you need to update the password, remove the email first and re-add it'
        ]
      });
    }
    
    const encryptedPassword = encrypt(password);
    
    // Test the connection before saving
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: { user: email, pass: password }
    });
    
    try {
      await transporter.verify();
    } catch (verifyErr) {
      console.error('Email verification failed:', verifyErr.message);
      
      let errorMessage = 'Could not connect to Gmail';
      let troubleshooting = [];
      
      if (verifyErr.message.includes('Invalid login') || verifyErr.message.includes('auth') || verifyErr.message.includes('credentials')) {
        errorMessage = 'Invalid email or app password';
        troubleshooting = [
          'Step 1: Go to myaccount.google.com/apppasswords',
          'Step 2: Sign in with the Gmail account you want to add',
          'Step 3: Select "Mail" as the app and "Other" as the device',
          'Step 4: Click "Generate" to create a new app password',
          'Step 5: Copy the 16-character password (no spaces needed)',
          'Step 6: Paste it here and try again',
          '',
          'Common issues:',
          '• Using your regular Gmail password (you need an App Password)',
          '• 2-Factor Authentication not enabled (required for app passwords)',
          '• Typo in the email address or password'
        ];
      } else if (verifyErr.message.includes('ECONNREFUSED') || verifyErr.message.includes('connect')) {
        errorMessage = 'Could not reach Gmail servers';
        troubleshooting = [
          'Check your internet connection',
          'Try again in a few minutes',
          'If the problem persists, Gmail may be temporarily unavailable'
        ];
      } else {
        troubleshooting = [
          'Make sure 2-Factor Authentication is enabled on your Google account',
          'Generate a fresh app password at myaccount.google.com/apppasswords',
          'Double-check the email address is correct'
        ];
      }
      
      return res.status(400).json({ error: errorMessage, troubleshooting });
    }
    
    // Check if this is the first account (make it primary)
    const countResult = await pool.query('SELECT COUNT(*) FROM email_accounts WHERE company_id = $1', [req.user.company_id]);
    const isPrimary = parseInt(countResult.rows[0].count) === 0;
    
    const result = await pool.query(
      `INSERT INTO email_accounts (email, smtp_server, smtp_port, smtp_username, smtp_password_encrypted, status, is_primary, last_tested_at, company_id)
       VALUES ($1, 'smtp.gmail.com', 587, $1, $2, 'active', $3, CURRENT_TIMESTAMP, $4)
       RETURNING id, email, status, is_primary`,
      [email, encryptedPassword, isPrimary, req.user.company_id]
    );
    
    res.json({ 
      success: true, 
      account: result.rows[0],
      message: `${email} connected successfully!`
    });
  } catch (error) {
    console.error('Add email account error:', error);
    res.status(500).json({ 
      error: 'Failed to add email account',
      troubleshooting: ['Please try again. If the problem persists, contact support.']
    });
  }
});

app.delete('/api/email-accounts/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    const account = await pool.query('SELECT email, is_primary FROM email_accounts WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (account.rows.length === 0) {
      return res.status(404).json({ error: 'Email account not found' });
    }
    
    await pool.query('DELETE FROM email_accounts WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    
    if (account.rows[0].is_primary) {
      await pool.query(
        'UPDATE email_accounts SET is_primary = TRUE WHERE id = (SELECT id FROM email_accounts WHERE company_id = $1 ORDER BY created_at ASC LIMIT 1)',
        [req.user.company_id]
      );
    }
    
    res.json({ success: true, message: `${account.rows[0].email} removed` });
  } catch (error) {
    console.error('Delete email account error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/email-accounts/:id/test', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    const result = await pool.query(
      'SELECT email, smtp_server, smtp_port, smtp_username, smtp_password_encrypted FROM email_accounts WHERE id = $1 AND company_id = $2',
      [id, req.user.company_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Email account not found' });
    }
    
    const account = result.rows[0];
    let decryptedPassword;
    
    try {
      decryptedPassword = decrypt(account.smtp_password_encrypted);
    } catch (err) {
      await pool.query(
        'UPDATE email_accounts SET status = $1, last_error = $2, last_tested_at = CURRENT_TIMESTAMP WHERE id = $3',
        ['error', 'Password decryption failed - please re-add the account', id]
      );
      return res.status(400).json({ 
        error: 'Password is corrupted',
        troubleshooting: ['Remove this email and add it again with a fresh app password']
      });
    }
    
    const transporter = nodemailer.createTransport({
      host: account.smtp_server,
      port: account.smtp_port,
      secure: false,
      auth: { user: account.smtp_username, pass: decryptedPassword }
    });
    
    try {
      await transporter.verify();
      
      // Send test email
      await transporter.sendMail({
        from: account.email,
        to: account.email,
        subject: 'ProTrack: Email Test',
        text: 'Email notifications are working!',
        html: `
          <div style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #1c3b59;">ProTrack</h2>
            <p style="color: #166534; font-weight: bold;">✓ Email notifications are working!</p>
            <p style="color: #666;">This test email was sent from your ProTrack app.</p>
          </div>
        `
      });
      
      await pool.query(
        'UPDATE email_accounts SET status = $1, last_error = NULL, last_tested_at = CURRENT_TIMESTAMP WHERE id = $2',
        ['active', id]
      );
      
      res.json({ success: true, message: `Test email sent to ${account.email}` });
    } catch (sendErr) {
      console.error('Test email failed:', sendErr.message);
      
      let errorMessage = 'Test email failed';
      let troubleshooting = [];
      
      if (sendErr.message.includes('auth') || sendErr.message.includes('credentials')) {
        errorMessage = 'App password no longer works';
        troubleshooting = [
          'Your app password may have been revoked',
          'Go to myaccount.google.com/apppasswords to generate a new one',
          'Remove this email and re-add it with the new password'
        ];
      } else {
        troubleshooting = ['Check your internet connection and try again'];
      }
      
      await pool.query(
        'UPDATE email_accounts SET status = $1, last_error = $2, last_tested_at = CURRENT_TIMESTAMP WHERE id = $3',
        ['error', errorMessage, id]
      );
      
      res.status(400).json({ error: errorMessage, troubleshooting });
    }
  } catch (error) {
    console.error('Test email account error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/email-accounts/:id/primary', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Validate account exists first
    const account = await pool.query('SELECT id, email FROM email_accounts WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (account.rows.length === 0) {
      return res.status(404).json({ error: 'Email account not found' });
    }
    
    await pool.query('BEGIN');
    await pool.query('UPDATE email_accounts SET is_primary = FALSE WHERE is_primary = TRUE AND company_id = $1', [req.user.company_id]);
    await pool.query('UPDATE email_accounts SET is_primary = TRUE WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    await pool.query('COMMIT');
    
    res.json({ success: true, message: `${account.rows[0].email} is now the primary email` });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Set primary email error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/notifications/test-email', authenticateToken, async (req, res) => {
  try {
    const { recipientEmail } = req.body;
    
    if (!requireCompany(req, res)) return;
    const settingsResult = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_%', req.user.company_id]);
    const config = {};
    settingsResult.rows.forEach(row => { config[row.key] = row.value; });
    
    if (!config.notification_smtp_server || !config.notification_smtp_username) {
      return res.status(400).json({ error: 'Email not configured. Please set up SMTP settings first.' });
    }
    
    if (!config.notification_smtp_password) {
      return res.status(400).json({ error: 'Email password not configured. Please update your email settings.' });
    }
    
    let decryptedPassword;
    try {
      decryptedPassword = decrypt(config.notification_smtp_password);
    } catch (decryptErr) {
      console.error('Failed to decrypt SMTP password:', decryptErr.message);
      return res.status(400).json({ error: 'Email password is invalid. Please update your email settings.' });
    }
    
    const transporter = nodemailer.createTransport({
      host: config.notification_smtp_server,
      port: parseInt(config.notification_smtp_port || 587),
      secure: config.notification_smtp_port === '465',
      auth: {
        user: config.notification_smtp_username,
        pass: decryptedPassword
      }
    });
    
    try {
      await transporter.verify();
    } catch (verifyErr) {
      console.error('SMTP verification failed:', verifyErr.message);
      if (verifyErr.message.includes('auth') || verifyErr.message.includes('credentials')) {
        return res.status(400).json({ error: 'Invalid Gmail credentials. Please check your app password and try again.' });
      }
      return res.status(400).json({ error: 'Unable to connect to email server. Please check your settings.' });
    }
    
    const testEmail = recipientEmail || config.notification_email_address || config.notification_smtp_username;
    
    await transporter.sendMail({
      from: config.notification_email_address || config.notification_smtp_username,
      to: testEmail,
      subject: 'ProTrack: Email Test',
      text: 'ProTrack: Email notifications are working!',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px;">
          <div style="background: #1c3b59; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 24px;">ProTrack</h1>
          </div>
          <div style="padding: 30px; background: #f8f9fa; border-radius: 0 0 8px 8px;">
            <p style="font-size: 18px; color: #166534; font-weight: bold;">✓ Email notifications are working!</p>
            <p style="color: #666;">This is a test email from your ProTrack app.</p>
            <p style="color: #999; font-size: 12px; margin-top: 20px;">Sent from: ${config.notification_email_address || config.notification_smtp_username}</p>
          </div>
        </div>
      `
    });
    
    console.log(`✉️ Test email sent to ${testEmail}`);
    res.json({ success: true, message: `Test email sent to ${testEmail}` });
  } catch (error) {
    console.error('Test email error:', error.message);
    let userMessage = 'Failed to send test email. Please check your settings.';
    if (error.message.includes('auth') || error.message.includes('credentials')) {
      userMessage = 'Invalid Gmail credentials. Please check your app password.';
    } else if (error.message.includes('connect') || error.message.includes('ECONNREFUSED')) {
      userMessage = 'Unable to connect to email server. Please check your internet connection.';
    }
    res.status(500).json({ error: userMessage });
  }
});

app.post('/api/notifications/config/sms', authenticateToken, async (req, res) => {
  try {
    const { accountSid, authToken, fromPhone } = req.body;
    
    const encryptedToken = encrypt(authToken);
    
    const updates = [
      ['notification_twilio_sid', accountSid],
      ['notification_twilio_token', encryptedToken],
      ['notification_twilio_phone', fromPhone]
    ];
    
    for (const [key, value] of updates) {
      await pool.query(
        'INSERT INTO settings (key, value, company_id) VALUES ($1, $2, $3) ON CONFLICT (key, company_id) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP',
        [key, value, req.user.company_id]
      );
    }
    
    res.json({ success: true });
  } catch (error) {
    console.error('Save SMS config error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/notifications/config/sms', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    await pool.query('DELETE FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_twilio_%', req.user.company_id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete SMS config error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/notifications/test-email', authenticateToken, async (req, res) => {
  try {
    const { email, server, port, username, password } = req.body;
    
    const transporter = nodemailer.createTransport({
      host: server,
      port: parseInt(port),
      secure: port === 465,
      auth: { user: username, pass: password }
    });
    
    await transporter.verify();
    res.json({ success: true });
  } catch (error) {
    console.error('Email test error:', error);
    res.json({ success: false, error: error.message });
  }
});

app.post('/api/notifications/test-sms', authenticateToken, async (req, res) => {
  try {
    const { accountSid, authToken, fromPhone, toPhone } = req.body;
    
    const twilio = require('twilio')(accountSid, authToken);
    
    await twilio.messages.create({
      body: 'Test message from ProTrack - SMS notifications are working!',
      from: fromPhone,
      to: toPhone
    });
    
    res.json({ success: true });
  } catch (error) {
    console.error('SMS test error:', error);
    res.json({ success: false, error: error.message });
  }
});

app.post('/api/notifications/send-test-email', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_%', req.user.company_id]);
    const config = {};
    result.rows.forEach(row => { config[row.key] = row.value; });
    
    if (!config.notification_smtp_server) {
      return res.json({ success: false, error: 'Email not configured' });
    }
    
    const transporter = nodemailer.createTransport({
      host: config.notification_smtp_server,
      port: parseInt(config.notification_smtp_port || 587),
      secure: config.notification_smtp_port === '465',
      auth: {
        user: config.notification_smtp_username,
        pass: decrypt(config.notification_smtp_password)
      }
    });
    
    await transporter.sendMail({
      from: config.notification_email_address,
      to: config.notification_email_address,
      subject: 'ProTrack - Test Email',
      text: 'This is a test email from ProTrack. Email notifications are working!'
    });
    
    res.json({ success: true });
  } catch (error) {
    console.error('Send test email error:', error);
    res.json({ success: false, error: error.message });
  }
});

app.post('/api/notifications/send-test-sms', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_twilio%', req.user.company_id]);
    const config = {};
    result.rows.forEach(row => { config[row.key] = row.value; });
    
    const twilioSid = process.env.TWILIO_ACCOUNT_SID || config.notification_twilio_sid;
    const twilioToken = process.env.TWILIO_AUTH_TOKEN || (config.notification_twilio_token ? decrypt(config.notification_twilio_token) : null);
    const twilioPhone = process.env.TWILIO_PHONE_NUMBER || config.notification_twilio_phone;
    
    if (!twilioSid || !twilioToken || !twilioPhone) {
      return res.json({ success: false, error: 'SMS not configured - need Twilio credentials' });
    }
    
    const userResult = await pool.query('SELECT phone FROM users WHERE id = $1', [req.user.id]);
    const userPhone = userResult.rows[0]?.phone;
    
    if (!userPhone) {
      return res.json({ success: false, error: 'No phone number in your profile' });
    }
    
    const twilio = require('twilio')(twilioSid, twilioToken);
    
    await twilio.messages.create({
      body: 'ProTrack test - SMS notifications working!',
      from: twilioPhone,
      to: userPhone
    });
    
    res.json({ success: true });
  } catch (error) {
    console.error('Send test SMS error:', error);
    res.json({ success: false, error: error.message });
  }
});

async function sendNotification(type, userId, message, subject = 'ProTrack Notification', attachments = []) {
  try {
    console.log(`📬 sendNotification called: type=${type}, userId=${userId}`);
    
    const userResult = await pool.query('SELECT email, phone, notify_preference FROM users WHERE id = $1', [userId]);
    const user = userResult.rows[0];
    if (!user) {
      console.log(`📬 User ${userId} not found`);
      return;
    }
    
    const preference = user.notify_preference || 'email';
    console.log(`📬 User preference: ${preference}, email: ${user.email || 'none'}, phone: ${user.phone || 'none'}`);
    
    const settingsResult = await pool.query('SELECT * FROM settings WHERE key LIKE $1', ['notification_%']);
    const config = {};
    settingsResult.rows.forEach(row => { config[row.key] = row.value; });
    
    const shouldEmail = (preference === 'email' || preference === 'both') && user.email;
    const shouldSms = (preference === 'sms' || preference === 'both') && user.phone;
    console.log(`📬 shouldEmail: ${shouldEmail}, shouldSms: ${shouldSms}`);
    
    // Build full URLs for attachments
    const baseUrl = process.env.REPLIT_DEV_DOMAIN ? `https://${process.env.REPLIT_DEV_DOMAIN}` : 'http://localhost:5000';
    
    // Handle both old format (string photoPath) and new format (array of attachments)
    const attachmentList = Array.isArray(attachments) ? attachments : (attachments ? [{ path: attachments, name: 'photo.jpg' }] : []);
    
    if (shouldEmail && config.notification_smtp_server) {
      try {
        const transporter = nodemailer.createTransport({
          host: config.notification_smtp_server,
          port: parseInt(config.notification_smtp_port || 587),
          secure: config.notification_smtp_port === '465',
          auth: {
            user: config.notification_smtp_username,
            pass: decrypt(config.notification_smtp_password)
          }
        });
        
        // Build attachment links text
        const attachmentLinks = attachmentList.map(a => `${baseUrl}${a.path}`).join('\n');
        
        const emailOptions = {
          from: config.notification_email_address,
          to: user.email,
          subject: subject,
          text: message + (attachmentList.length > 0 ? `\n\nAttachments:\n${attachmentLinks}` : '')
        };
        
        // Add file attachments
        if (attachmentList.length > 0) {
          emailOptions.attachments = [];
          for (const attachment of attachmentList) {
            const filePath = path.join(__dirname, '..', attachment.path.replace(/^\//, ''));
            if (fs.existsSync(filePath)) {
              emailOptions.attachments.push({
                filename: attachment.name || path.basename(attachment.path),
                path: filePath
              });
              console.log(`📎 Attaching file: ${filePath}`);
            } else {
              console.log(`⚠️ File not found: ${filePath}`);
            }
          }
        }
        
        await transporter.sendMail(emailOptions);
        console.log(`📧 Email sent to ${user.email}: ${message}${attachmentList.length > 0 ? ` (${attachmentList.length} attachments)` : ''}`);
      } catch (e) {
        console.error('Email send failed:', e.message);
      }
    } else if (shouldEmail) {
      console.log(`📧 Email would send to ${user.email}: ${message}`);
    }
    
    // Check for Twilio credentials - prefer env vars, fallback to database settings
    const twilioSid = process.env.TWILIO_ACCOUNT_SID || config.notification_twilio_sid;
    const twilioToken = process.env.TWILIO_AUTH_TOKEN || (config.notification_twilio_token ? decrypt(config.notification_twilio_token) : null);
    const twilioPhone = process.env.TWILIO_PHONE_NUMBER || config.notification_twilio_phone;
    
    // Use Twilio for SMS (more reliable than email-gateway)
    console.log(`📬 Twilio check: shouldSms=${shouldSms}, hasSid=${!!twilioSid}, hasToken=${!!twilioToken}, hasPhone=${!!twilioPhone}`);
    
    if (shouldSms && twilioSid && twilioToken && twilioPhone) {
      try {
        const twilio = require('twilio')(twilioSid, twilioToken);
        
        // Format phone number to E.164 format (required by Twilio)
        let formattedPhone = user.phone.replace(/[^\d+]/g, ''); // Remove all non-digits except +
        if (!formattedPhone.startsWith('+')) {
          // Assume US number if no country code
          if (formattedPhone.length === 10) {
            formattedPhone = '+1' + formattedPhone;
          } else if (formattedPhone.length === 11 && formattedPhone.startsWith('1')) {
            formattedPhone = '+' + formattedPhone;
          }
        }
        
        const smsOptions = {
          body: message,
          from: twilioPhone,
          to: formattedPhone
        };
        
        // Add images as MMS (Twilio supports up to 10 media URLs, only images/videos)
        const imageAttachments = attachmentList.filter(a => 
          a.type?.startsWith('image/') || a.path?.match(/\.(jpg|jpeg|png|gif)$/i)
        );
        if (imageAttachments.length > 0) {
          smsOptions.mediaUrl = imageAttachments.slice(0, 10).map(a => `${baseUrl}${a.path}`);
          console.log(`📷 Adding MMS media: ${smsOptions.mediaUrl.length} files`);
        }
        
        // Add non-image file links to message body
        const otherAttachments = attachmentList.filter(a => 
          !a.type?.startsWith('image/') && !a.path?.match(/\.(jpg|jpeg|png|gif)$/i)
        );
        if (otherAttachments.length > 0) {
          const fileLinks = otherAttachments.map(a => `${a.name}: ${baseUrl}${a.path}`).join('\n');
          smsOptions.body += `\n\nFiles:\n${fileLinks}`;
        }
        
        const twilioResult = await twilio.messages.create(smsOptions);
        console.log(`📱 SMS sent to ${formattedPhone} (SID: ${twilioResult.sid}, Status: ${twilioResult.status})`);
        if (smsOptions.mediaUrl) {
          console.log(`📷 MMS media URLs: ${smsOptions.mediaUrl.join(', ')}`);
        }
      } catch (e) {
        console.error('SMS send failed:', e.message);
        console.error('SMS full error:', e.code, e.status, e.moreInfo);
      }
    } else if (shouldSms) {
      console.log(`📱 SMS would send to ${user.phone} (Twilio not configured): ${message}`);
    }
  } catch (error) {
    console.error('Notification error:', error);
  }
}

notificationService.setSendNotificationFn(sendNotification);
notificationService.startDailyDigestScheduler();

// Database cleanup - runs at 3 AM daily to clean up old records (90 days)
function startDatabaseCleanupScheduler() {
  const runCleanup = async () => {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - 90);
      
      const notificationsResult = await pool.query(
        'DELETE FROM notifications_log WHERE created_at < $1 RETURNING id',
        [cutoffDate]
      );
      
      const activityResult = await pool.query(
        'DELETE FROM activity_logs WHERE created_at < $1 RETURNING id',
        [cutoffDate]
      );
      
      const notifCount = notificationsResult.rowCount || 0;
      const activityCount = activityResult.rowCount || 0;
      
      if (notifCount > 0 || activityCount > 0) {
        console.log(`🧹 Database cleanup: removed ${notifCount} old notifications, ${activityCount} old activity logs`);
      }
    } catch (error) {
      console.error('Database cleanup error:', error.message);
    }
  };
  
  // Check every hour, run at 3 AM
  setInterval(() => {
    const now = new Date();
    if (now.getHours() === 3 && now.getMinutes() === 0) {
      runCleanup();
    }
  }, 60000);
  
  console.log('🧹 Database cleanup scheduler initialized (runs daily at 3 AM, removes records older than 90 days)');
}

startDatabaseCleanupScheduler();

app.post('/api/notifications/send-digests', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    const result = await notificationService.sendDailyDigests();
    res.json({ success: true, ...result });
  } catch (error) {
    console.error('Send digests error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/users', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query(`
      SELECT id, username, name, role, phone, email, trade, profile_picture_url, notify_preference
      FROM users 
      WHERE company_id = $1
      ORDER BY name
    `, [req.user.company_id]);
    res.json({ success: true, members: result.rows });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/jobs/:jobId/tasks', authenticateToken, async (req, res) => {
  try {
    const { jobId } = req.params;
    let { description, assigneeId, assigneeName } = req.body;
    
    if (!description) {
      return res.status(400).json({ error: 'Description is required' });
    }
    
    // If assigneeName provided but no assigneeId, resolve with fuzzy matching
    if (assigneeName && !assigneeId) {
      const allUsersResult = await pool.query('SELECT id, name, username FROM users WHERE company_id = $1', [req.user.company_id]);
      const allUsers = allUsersResult.rows;
      const fuzzyMatch = nameMatching.findBestMatch(assigneeName, allUsers);
      
      if (fuzzyMatch.match) {
        assigneeId = fuzzyMatch.match.id;
        console.log(`Fuzzy resolved "${assigneeName}" to ${fuzzyMatch.match.name} (${fuzzyMatch.confidence})`);
      } else {
        const availableNames = allUsers.map(u => u.name).join(', ');
        return res.status(400).json({ 
          error: `Could not find team member "${assigneeName}". Available team members: ${availableNames}`,
          suggestedAction: 'add_team_member',
          alternatives: fuzzyMatch.alternatives || []
        });
      }
    }
    
    if (!assigneeId) {
      return res.status(400).json({ error: 'Assignee is required' });
    }
    
    const result = await pool.query(
      'INSERT INTO tasks (job_id, description, assignee_id, created_by, company_id) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [jobId, description, assigneeId, req.user.id, req.user.company_id]
    );
    
    const taskId = result.rows[0].id;
    
    // Store undo action
    storeUndoAction(req.user.id, {
      type: 'create_task',
      taskId,
      jobId: parseInt(jobId),
      description
    });
    
    // Fetch assignee info FIRST for activity logging
    const assigneeResult = await pool.query('SELECT name, phone FROM users WHERE id = $1', [assigneeId]);
    const assignee = assigneeResult.rows[0];
    
    // Log activity with assignee name if assigned
    const activityAction = assignee ? `assigned task to ${assignee.name}` : 'added task';
    await logActivity(jobId, req.user.id, activityAction, description);
    
    const jobResult = await pool.query('SELECT address FROM jobs WHERE id = $1', [jobId]);
    const jobAddress = jobResult.rows[0]?.address || 'Unknown location';
    
    const source = req.body.source || 'manual';
    
    // Send notification to assignee
    if (assignee) {
      await sendTaskNotificationWithLog(pool, assigneeId, parseInt(jobId), description, jobAddress, source);
    }
    
    res.json({ success: true, task: { ...result.rows[0], assignee_name: assignee?.name }, undoAvailable: true });
  } catch (error) {
    console.error('Create task error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/tasks/:id/toggle', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Only admin can mark tasks complete' });
    }
    
    const taskResult = await pool.query('SELECT * FROM tasks WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (taskResult.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    const task = taskResult.rows[0];
    const newCompleted = !task.completed;
    
    await pool.query(
      'UPDATE tasks SET completed = $1, completed_at = $2, completed_by = $3 WHERE id = $4',
      [newCompleted, newCompleted ? new Date() : null, newCompleted ? req.user.id : null, id]
    );
    
    const action = newCompleted ? 'completed task' : 'uncompleted task';
    await logActivity(task.job_id, req.user.id, action, task.description);
    
    if (newCompleted) {
      const admins = await pool.query('SELECT id FROM users WHERE role IN ($1, $2) AND company_id = $3', ['admin', 'owner', req.user.company_id]);
      const jobResult = await pool.query('SELECT address, customer_name FROM jobs WHERE id = $1', [task.job_id]);
      const job = jobResult.rows[0];
      
      for (const admin of admins.rows) {
        if (admin.id !== req.user.id) {
          sendNotification('task_completed', admin.id,
            `Task completed: "${task.description}" at ${job?.address || 'Unknown'}`,
            'ProTrack - Task Completed'
          );
        }
      }
    }
    
    res.json({ success: true, completed: newCompleted });
  } catch (error) {
    console.error('Toggle task error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/tasks/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner') {
      return res.status(403).json({ error: 'Only admin can delete tasks' });
    }
    
    const taskResult = await pool.query('SELECT * FROM tasks WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    if (taskResult.rows.length === 0) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    const task = taskResult.rows[0];
    
    await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
    
    await logActivity(task.job_id, req.user.id, 'deleted task', task.description);
    
    res.json({ success: true });
  } catch (error) {
    console.error('Delete task error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/jobs/:id/activity', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT a.*, u.name as user_name 
      FROM activity_logs a
      LEFT JOIN users u ON a.user_id = u.id
      WHERE a.job_id = $1
      ORDER BY a.created_at DESC
    `, [id]);
    res.json({ success: true, activities: result.rows });
  } catch (error) {
    console.error('Get activity error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/jobs/:id/notifications', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const history = await notificationService.getNotificationHistory(id);
    res.json({ success: true, notifications: history });
  } catch (error) {
    console.error('Get notification history error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/notifications/:id/resend', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }
    const { id } = req.params;
    const result = await notificationService.forceResend(id, req.user.name);
    res.json({ success: result.success, message: result.success ? 'Notification resent' : 'Resend failed' });
  } catch (error) {
    console.error('Resend notification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/users/:id/notification-preference', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { preference } = req.body;
    
    if (!['immediate', 'daily_digest', 'disabled'].includes(preference)) {
      return res.status(400).json({ error: 'Invalid preference. Use: immediate, daily_digest, or disabled' });
    }
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner' && req.user.id !== parseInt(id)) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    
    await pool.query(
      'UPDATE users SET notification_preference = $1 WHERE id = $2 AND company_id = $3',
      [preference, id, req.user.company_id]
    );
    
    res.json({ success: true, message: `Notification preference updated to ${preference}` });
  } catch (error) {
    console.error('Update notification preference error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/notifications/check-duplicate', authenticateToken, async (req, res) => {
  try {
    const { recipientId, jobId, taskDescription } = req.body;
    const taskHash = notificationService.generateTaskHash(taskDescription);
    const result = await notificationService.checkDuplicate(recipientId, jobId, taskHash);
    res.json({ success: true, ...result });
  } catch (error) {
    console.error('Check duplicate error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/users/trades', authenticateToken, async (req, res) => {
  try {
    if (!requireCompany(req, res)) return;
    const result = await pool.query(`
      SELECT id, name, trade, phone, email, profile_picture_url 
      FROM users 
      WHERE role NOT IN ('admin', 'owner') AND company_id = $1
      ORDER BY name
    `, [req.user.company_id]);
    res.json({ success: true, trades: result.rows });
  } catch (error) {
    console.error('Get trade users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/users', authenticateToken, async (req, res) => {
  try {
    const { username, name, role, phone, email, trade, notify_preference } = req.body;
    let { password } = req.body;
    
    if (!username || !name) {
      return res.status(400).json({ error: 'Username and name are required' });
    }
    
    let tempPassword = null;
    if (!password) {
      tempPassword = 'PT' + Math.floor(Math.random() * 10000) + '!';
      password = tempPassword;
    }
    
    if (!requireCompany(req, res)) return;
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (username, password_hash, name, role, phone, email, trade, notify_preference, company_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id, username, name, role, phone, email, trade, profile_picture_url, notify_preference',
      [username, hashedPassword, name, role || 'user', phone, email, trade || null, notify_preference || 'email', req.user.company_id]
    );
    
    const response = { success: true, user: result.rows[0] };
    if (tempPassword) {
      response.tempPassword = tempPassword;
    }
    
    if (email && tempPassword) {
      try {
        const settingsResult = await pool.query('SELECT * FROM settings WHERE key LIKE $1', ['notification_%']);
        const config = {};
        settingsResult.rows.forEach(row => { config[row.key] = row.value; });
        
        if (config.notification_smtp_server && config.notification_smtp_username) {
          const transporter = nodemailer.createTransport({
            host: config.notification_smtp_server,
            port: parseInt(config.notification_smtp_port || 587),
            secure: config.notification_smtp_port === '465',
            auth: {
              user: config.notification_smtp_username,
              pass: decrypt(config.notification_smtp_password)
            }
          });
          
          const appUrl = process.env.REPLIT_DEV_DOMAIN 
            ? `https://${process.env.REPLIT_DEV_DOMAIN}` 
            : process.env.REPLIT_DOMAINS 
              ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}`
              : 'the ProTrack app';
          
          await transporter.sendMail({
            from: config.notification_email_address || config.notification_smtp_username,
            to: email,
            subject: 'Welcome to ProTrack - Your Account is Ready',
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: #1c3b59; padding: 20px; text-align: center;">
                  <h1 style="color: white; margin: 0;">Welcome to ProTrack</h1>
                </div>
                <div style="padding: 30px; background: #f8f9fa;">
                  <p style="font-size: 16px;">Hi ${name},</p>
                  <p style="font-size: 16px;">You've been added to the ProTrack team. Here are your login credentials:</p>
                  <div style="background: white; border: 2px solid #1c3b59; border-radius: 8px; padding: 20px; margin: 20px 0;">
                    <p style="margin: 0 0 10px 0;"><strong>Username:</strong> ${username}</p>
                    <p style="margin: 0;"><strong>Temporary Password:</strong> ${tempPassword}</p>
                  </div>
                  <p style="font-size: 16px; color: #dc2626;"><strong>Important:</strong> Please change your password after your first login for security.</p>
                  <p style="font-size: 16px;">You can log in at: ${appUrl}</p>
                  <p style="font-size: 14px; color: #666; margin-top: 30px;">If you have any questions, contact your administrator.</p>
                </div>
                <div style="background: #1c3b59; padding: 15px; text-align: center;">
                  <p style="color: white; margin: 0; font-size: 12px;">ProTrack - Job Tracker</p>
                </div>
              </div>
            `
          });
          response.welcomeEmailSent = true;
          console.log(`✉️ Welcome email sent to ${email}`);
        }
      } catch (emailError) {
        console.error('Failed to send welcome email:', emailError.message);
        response.welcomeEmailSent = false;
      }
    }
    
    res.json(response);
  } catch (error) {
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Username already exists' });
    }
    console.error('Create user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/users/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, role, phone, email, trade, notify_preference } = req.body;
    
    if (!requireCompany(req, res)) return;
    const query = 'UPDATE users SET name = COALESCE($1, name), role = COALESCE($2, role), phone = COALESCE($3, phone), email = COALESCE($4, email), trade = $5, notify_preference = COALESCE($6, notify_preference), updated_at = CURRENT_TIMESTAMP WHERE id = $7 AND company_id = $8 RETURNING id, username, name, role, phone, email, trade, profile_picture_url, notify_preference';
    const params = [name, role, phone, email, trade, notify_preference, id, req.user.company_id];
    
    const result = await pool.query(query, params);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ success: true, user: result.rows[0] });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/users/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    if (parseInt(id) === req.user.id) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }
    if (!requireCompany(req, res)) return;
    await pool.query('DELETE FROM users WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    res.json({ success: true, message: 'User deleted' });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/users/:id/photo', authenticateToken, upload.single('photo'), async (req, res) => {
  try {
    const { id } = req.params;
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner' && req.user.id !== parseInt(id)) {
      return res.status(403).json({ error: 'Not authorized to update this user\'s photo' });
    }
    
    const file = req.file;
    
    if (!file) {
      return res.status(400).json({ error: 'No photo uploaded' });
    }
    
    const photoUrl = `/uploads/profiles/${file.filename}`;
    
    const existingResult = await pool.query('SELECT profile_picture_url FROM users WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    const existingPhoto = existingResult.rows[0]?.profile_picture_url;
    if (existingPhoto) {
      const oldFilePath = path.join(__dirname, '..', existingPhoto.replace(/^\//, ''));
      if (fs.existsSync(oldFilePath)) {
        fs.unlinkSync(oldFilePath);
      }
    }
    
    await pool.query(
      'UPDATE users SET profile_picture_url = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND company_id = $3',
      [photoUrl, id, req.user.company_id]
    );
    
    res.json({ success: true, url: photoUrl });
  } catch (error) {
    console.error('Upload photo error:', error);
    res.status(500).json({ error: 'Upload failed' });
  }
});

app.delete('/api/users/:id/photo', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    if (req.user.role !== 'admin' && req.user.role !== 'owner' && req.user.id !== parseInt(id)) {
      return res.status(403).json({ error: 'Not authorized to delete this user\'s photo' });
    }
    
    const result = await pool.query('SELECT profile_picture_url FROM users WHERE id = $1 AND company_id = $2', [id, req.user.company_id]);
    const user = result.rows[0];
    
    if (user && user.profile_picture_url) {
      const filePath = path.join(__dirname, '..', user.profile_picture_url.replace(/^\//, ''));
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
    
    await pool.query(
      'UPDATE users SET profile_picture_url = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = $1 AND company_id = $2',
      [id, req.user.company_id]
    );
    
    res.json({ success: true, message: 'Photo removed' });
  } catch (error) {
    console.error('Remove photo error:', error);
    res.status(500).json({ error: 'Failed to remove photo' });
  }
});

function fuzzyParseVoice(transcript, context, currentJobId) {
  console.log('Using fuzzy matching for:', transcript);
  
  const lowerTranscript = transcript.toLowerCase();
  
  const createJobKeywords = /\b(create job|new job|add job)\b/i;
  const createUserKeywords = /\b(add team member|new worker|hire|add worker|new team member)\b/i;
  
  if (createJobKeywords.test(lowerTranscript)) {
    const nameMatch = lowerTranscript.match(/(?:for|job for)\s+([a-z]+(?:\s+[a-z]+)?)/i);
    const addressMatch = lowerTranscript.match(/(?:at|address)\s+(.+?)(?:\s+phone|$)/i);
    return {
      intent: 'create_job',
      job_name: nameMatch ? nameMatch[1].split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : null,
      job_id: null,
      person_name: null,
      person_id: null,
      action: null,
      new_job_address: addressMatch ? addressMatch[1].trim() : null,
      new_job_phone: null,
      new_user_trade: null,
      new_user_phone: null,
      confidence: nameMatch && addressMatch ? 0.7 : 0.4
    };
  }
  
  if (createUserKeywords.test(lowerTranscript)) {
    const nameMatch = lowerTranscript.match(/(?:member|worker|hire)\s+([a-z]+(?:\s+[a-z]+)?)/i);
    const tradeMatch = lowerTranscript.match(/(?:as|trade)\s+([a-z]+)/i);
    const trades = ['carpentry', 'drywall', 'electrical', 'flooring', 'framing', 'hvac', 'landscaping', 'masonry', 'painting', 'plumbing', 'roofing', 'tile'];
    let trade = tradeMatch ? tradeMatch[1] : null;
    if (trade) {
      trade = trades.find(t => t.startsWith(trade.toLowerCase())) || trade;
      trade = trade.charAt(0).toUpperCase() + trade.slice(1);
    }
    return {
      intent: 'create_user',
      job_name: null,
      job_id: null,
      person_name: nameMatch ? nameMatch[1].split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : null,
      person_id: null,
      action: null,
      new_job_address: null,
      new_job_phone: null,
      new_user_trade: trade,
      new_user_phone: null,
      confidence: nameMatch && trade ? 0.7 : 0.4
    };
  }
  
  const jobFuse = new Fuse(context.jobs || [], { 
    keys: ['client_name', 'address'], 
    threshold: 0.4,
    ignoreLocation: true
  });
  const jobMatches = jobFuse.search(transcript);
  const jobMatch = jobMatches[0]?.item;
  
  const personFuse = new Fuse(context.team || [], { 
    keys: ['name', 'trade'], 
    threshold: 0.4,
    ignoreLocation: true
  });
  const personMatches = personFuse.search(transcript);
  const personMatch = personMatches[0]?.item;
  
  const taskKeywords = /\b(tell|ask|task|remind|have|get|need|wants?)\b/i;
  const noteKeywords = /\b(note|remember|record|add note|write down)\b/i;
  
  let intent = 'add_note';
  if (taskKeywords.test(lowerTranscript) && personMatch) {
    intent = 'add_task';
  } else if (noteKeywords.test(lowerTranscript)) {
    intent = 'add_note';
  } else if (personMatch) {
    intent = 'add_task';
  }
  
  let action = transcript;
  if (personMatch) {
    const patterns = [
      new RegExp(`tell ${personMatch.name} to `, 'i'),
      new RegExp(`ask ${personMatch.name} to `, 'i'),
      new RegExp(`have ${personMatch.name} `, 'i'),
      new RegExp(`@${personMatch.name} `, 'i'),
    ];
    for (const pattern of patterns) {
      action = action.replace(pattern, '');
    }
  }
  action = action.replace(/^(add note|note|add task|task)[\s:]+/i, '').trim();
  
  let confidence = 0.3;
  if (personMatch && jobMatch) confidence = 0.6;
  else if (personMatch || jobMatch) confidence = 0.5;
  if (action.length < 5) confidence -= 0.1;
  
  return {
    job_name: jobMatch?.client_name || null,
    job_id: jobMatch?.id || currentJobId || null,
    person_name: personMatch?.name || null,
    person_id: personMatch?.id || null,
    action: action || transcript,
    new_job_address: null,
    new_job_phone: null,
    new_user_trade: null,
    new_user_phone: null,
    confidence: Math.max(0.1, confidence),
    intent: intent
  };
}

app.post('/api/voice/parse', authenticateToken, async (req, res) => {
  try {
    const { transcript, jobId, currentJob } = req.body;
    
    if (!transcript || transcript.trim().length === 0) {
      return res.status(400).json({ error: 'Transcript is required' });
    }

    if (transcript.length > 1000) {
      return res.json({ 
        commands: [{
          action: 'unclear',
          message: 'That command was too long. Please keep voice commands under 1 minute.',
          confidence: 0
        }]
      });
    }
    
    console.log('Voice command received:', transcript);
    
    // Get current team members from database
    let teamList = '(no team members found - user may need to add them first)';
    try {
      const teamResult = await pool.query('SELECT name, trade FROM users WHERE role NOT IN ($1, $2) AND company_id = $3', ['admin', 'owner', req.user.company_id]);
      if (teamResult.rows.length > 0) {
        teamList = teamResult.rows.map(u => `${u.name} (${u.trade || 'general'})`).join(', ');
      }
    } catch (e) {
      console.log('Could not load team from database');
    }
    
    if (!anthropic) {
      console.log('No Anthropic API key, using fuzzy matching');
      return res.json({ commands: [fuzzyParseVoiceSimple(transcript)] });
    }
    
    try {
      const message = await anthropic.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        messages: [{
          role: 'user',
          content: `You are a smart voice assistant for a construction job tracker. Parse natural speech into commands. Be VERY FLEXIBLE with typos, slang, accents, and informal speech. This app is used by elderly users so be EXTRA forgiving.

Voice input: "${transcript}"
Current job: ${currentJob ? `"${currentJob.name}" at ${currentJob.address} (ID: ${jobId})` : 'none - on dashboard'}
Current team members: ${teamList}

CURRENT JOB CONTEXT:
${currentJob ? `User is viewing job "${currentJob.name}". If no job is mentioned in the command, use job_identifier: null and the app will use this current job.` : 'User is on the dashboard. They must specify which job.'}

CRITICAL DISTINCTION - TASKS vs JOB ASSIGNMENTS:
- add_task = Give someone WORK TO DO (has a task/action). ALWAYS use this when there's something to do!
- assign_job = Just add person to job roster (NO task content, just putting them on the job)

ACTIONS (pick the best match):

1. create_job - Create NEW job
   Phrases: "add/create/new/start/make/open a job", "I need a job for", "job for [client] at [address]"
   Returns: new_job_address, new_job_client (if mentioned)

2. add_task - Give someone a task to do (USE THIS MOST OFTEN!)
   KEY: If there's ANY action/work mentioned, use add_task NOT assign_job!
   Phrases: "tell/have/ask/get [person] to [do something]", "[person] needs to/should [do something]", 
            "assign [task] to [person]", "give [person] the [task]", "[person] [task]",
            "assign [person] to [do task]", "put [person] on [task]", "[task] for [person]"
   JOB REFERENCE: Look for "at [job name]", "on [job name]", "for [client name]", "at [address]" - extract as job_identifier!
   Examples that ARE tasks: "assign Bob to fix sink" (task=fix sink), "put Lee on electrical" (task=electrical work),
            "Bob needs to check the heater", "tell Rosa to paint bedroom", "assign drywall to Eric",
            "tell Win to paint the tile at test" (job_identifier=test, content=paint the tile),
            "ask Bob to check plumbing at the Johnson house" (job_identifier=Johnson, content=check plumbing)
   Returns: assignee (person name), content (the task/work WITHOUT the job reference), job_identifier (if mentioned)

3. change_status - Change job status
   Phrases: "mark/set/change to [status]", "make it [status]"
   Shortcuts: "done/finished/complete" = completed, "hold/hold it/pause/wait" = on_hold, "close/archive/file" = closed, "start/activate/begin" = active
   Returns: status (estimate/active/on_hold/completed/closed)

4. toggle_urgent - Mark urgent or not
   Phrases: "urgent/priority/rush/important/asap/emergency", "this is urgent", "not urgent/remove urgent/normal"
   Returns: urgent (true/false)

5. add_team_member - Add new worker to company roster
   Phrases: "add team member", "add [name] as [trade]", "new worker", "hire [name]", "new guy [name]"
   Returns: new_member_name, new_member_trade
   Trades: framing, electrical, plumbing, painting, tile, drywall, hvac, roofing, flooring, carpentry, landscaping, masonry, general

6. delete_team_member - Remove worker from company
   Phrases: "remove/delete [name] from team", "fire [name]", "let [name] go"
   Returns: member_name

7. edit_job - Update job details
   Phrases: "change/update/set the [field] to [value]", "door code is [code]", "phone is [number]"
   Returns: edit_field (client_name/address/phone/door_code), edit_value

8. assign_job - ONLY add person to job roster WITHOUT giving them a task
   Use ONLY when NO task/work is mentioned, just adding person to job
   Phrases: "add [person] to this job", "assign [person] to the job" (not to a task!)
   Example: "add Bob to this job" = assign_job (no task). "add Bob to fix sink" = add_task (has task!)
   Returns: assignee

9. navigate - Go to screen/job
   Phrases: "go to/show/open [destination]", "take me to", "show me"
   Returns: destination (dashboard/settings/job), job_identifier if going to specific job

10. add_note - Add a note without assigning to anyone
    Phrases: "add note", "note that", "make a note", "write down"
    Returns: content (the note text)

11. unclear - When you genuinely cannot understand
    Use ONLY when truly incomprehensible. Be generous - try to figure it out!
    Returns: message: "I didn't catch that. Could you say it again?"

SMART RULES:
- TASK PRIORITY: When in doubt between add_task and assign_job, choose add_task! Tasks are more common.
- FIX TYPOS: "jib"="job", "electrition/elektrik"="electrician", "piant/paynt"="paint", "plumer"="plumber"
- CHAIN COMMANDS: "and", "then", "also", "plus" connect multiple actions
- NEW JOB CONTEXT: If creating job + adding task, the task goes to job_identifier: "new"
- FUZZY NAMES: "joe/joey"=Joseph, "bobby/robert"=Bob, "rosa"=Rosales, "win/wynn"=Win, match partial/nicknames/accents
- INFER TRADES: "electrical/wiring" implies Lee, "painting" implies Rosales, "plumbing/pipes" implies Bob
- UNDERSTAND CONTEXT: "fix", "check", "install", "repair", "look at", "handle" = it's a TASK
- BE GENEROUS: If you can reasonably guess the intent, do it! Elderly users may speak slowly or hesitate.

NUMBER CONVERSION (spoken to digits):
- "three nine five nine" = "3959"
- "one twenty three" = "123"  
- "fifteen" = "15"
- "four five two one" = "4521"
Convert spoken numbers to digits when they appear in addresses, door codes, or phone numbers.

JOB REFERENCE PARSING:
When parsing "tell [worker] to [task] at/on/for [job]":
- "at [X]", "on [X]", "for [X]", "on the [X] job", "at the [X] house" = job_identifier
- Everything BEFORE "at/on/for" = task content
- Example: "paint the tile at test" → content="paint the tile", job_identifier="test"
- Example: "fix sink at johnson" → content="fix sink", job_identifier="johnson"

CLARIFICATION:
If you cannot determine the intent OR there are multiple matching workers/jobs, set clarification_needed with a question.
Examples: "Did you mean Mike Johnson or Michael?", "Which job - 123 Main or 124 Main?"

Return JSON: {"commands":[{action, job_identifier, new_job_address, new_job_client, assignee, assignee_confidence ("high"/"medium"/"low"), content, status, urgent, new_member_name, new_member_trade, member_name, edit_field, edit_value, destination, message, confidence, clarification_needed}]}

Examples:
"tell Bob to fix the water heater"
{"commands":[{"action":"add_task","assignee":"Bob","content":"fix the water heater","confidence":0.95}]}

"tell Mike to paint the tile at test"
{"commands":[{"action":"add_task","assignee":"Mike","job_identifier":"test","content":"paint the tile","confidence":0.95}]}

"ask Bob to check plumbing at the Johnson house"
{"commands":[{"action":"add_task","assignee":"Bob","job_identifier":"Johnson","content":"check plumbing","confidence":0.95}]}

"assign drywall to Eric"
{"commands":[{"action":"add_task","assignee":"Eric","content":"drywall work","confidence":0.9}]}

"put Lee on the electrical"
{"commands":[{"action":"add_task","assignee":"Lee","content":"electrical work","confidence":0.9}]}

"assign Bob to check the pipes"
{"commands":[{"action":"add_task","assignee":"Bob","content":"check the pipes","confidence":0.95}]}

"add Bob to this job"
{"commands":[{"action":"assign_job","assignee":"Bob","confidence":0.9}]}

"create job for the smiths at 123 main and tell bob fix the drain and mark urgent"
{"commands":[{"action":"create_job","new_job_address":"123 main","new_job_client":"The Smiths","confidence":0.95},{"action":"add_task","job_identifier":"new","assignee":"Bob","content":"fix the drain","confidence":0.9},{"action":"toggle_urgent","job_identifier":"new","urgent":true,"confidence":0.9}]}

"it's done"
{"commands":[{"action":"change_status","status":"completed","confidence":0.95}]}

"hold it"
{"commands":[{"action":"change_status","status":"on_hold","confidence":0.95}]}

"door code is 4521"
{"commands":[{"action":"edit_job","edit_field":"door_code","edit_value":"4521","confidence":0.95}]}

Return ONLY valid JSON, no markdown.`
        }]
      });

      const responseText = message.content[0].text;
      console.log('Claude response:', responseText);
      
      const cleanJson = responseText.replace(/```json\n?|```\n?/g, '').trim();
      const parsed = JSON.parse(cleanJson);
      
      if (!parsed.commands) {
        parsed.commands = [parsed];
      }
      
      console.log('Parsed commands:', parsed.commands);
      return res.json(parsed);
      
    } catch (claudeError) {
      console.error('Claude API error:', claudeError.message);
      return res.json({ commands: [fuzzyParseVoiceSimple(transcript)] });
    }
    
  } catch (error) {
    console.error('Voice parse error:', error);
    const userMessage = error.message.includes('API') 
      ? 'Voice service temporarily unavailable. Please try typing your command instead.'
      : 'Could not understand that command. Please try again or type it manually.';
    res.status(500).json({ 
      error: userMessage,
      technical: error.message
    });
  }
});

function fuzzyParseVoiceSimple(transcript) {
  const lower = transcript.toLowerCase();
  
  const teamMembers = [
    { name: 'Joseph', trade: 'framing' },
    { name: 'Lee', trade: 'electric' },
    { name: 'Bob', trade: 'plumbing' },
    { name: 'Rosales', trade: 'painting' },
    { name: 'Eric', trade: 'tile' }
  ];
  
  let assignee = null;
  for (const member of teamMembers) {
    if (lower.includes(member.name.toLowerCase())) {
      assignee = member.name;
      break;
    }
  }
  
  if (/\b(urgent|priority|important)\b/i.test(lower)) {
    const isRemove = /\b(not urgent|remove urgent|un-?urgent)\b/i.test(lower);
    return { action: 'toggle_urgent', urgent: !isRemove, job_identifier: null, confidence: 0.85 };
  }
  
  if (/\b(mark|set|change).*(active|estimate|on hold|completed|closed)\b/i.test(lower)) {
    const statusMatch = lower.match(/\b(active|estimate|on.?hold|completed|closed)\b/i);
    if (statusMatch) {
      const status = statusMatch[1].replace(/\s+/g, '_').toLowerCase();
      return { action: 'change_status', status: status, job_identifier: null, confidence: 0.85 };
    }
  }
  
  if (/\b(go to|open|show|navigate)\b.*\b(dashboard|settings|home)\b/i.test(lower)) {
    const dest = /dashboard|home/i.test(lower) ? 'dashboard' : 'settings';
    return { action: 'navigate', destination: dest, confidence: 0.9 };
  }
  
  if (/\b(complete|done|finish|check off)\b.*task/i.test(lower)) {
    const content = transcript.replace(/\b(complete|done|finish|check off|the|task)\b/gi, '').trim();
    return { action: 'complete_task', task_description: content, job_identifier: null, confidence: 0.7 };
  }
  
  // Detect roster-only phrases (just adding person to job, no task)
  // Matches: "add Bob to this job", "assign Bob to the job", "put Bob on job 12", "add Bob to the Main Street job"
  const rosterOnlyPatterns = [
    /\b(add|assign|put)\s+\w+\s+(to|on)\s+(this|the|a)?\s*(new\s+)?job\b/i,           // "assign Bob to this job", "add Bob to job"
    /\b(add|assign|put)\s+\w+\s+(to|on)\s+(this|the)\s+\w+\s*job\b/i,                  // "add Bob to the Main Street job"
    /\b(add|assign|put)\s+\w+\s+(to|on)\s+job\s*\d+/i,                                  // "add Bob to job 12"
    /\b(add|assign)\s+\w+\s*$/i                                                         // Just "assign Bob" with nothing else
  ];
  const isRosterOnly = rosterOnlyPatterns.some(p => p.test(lower));
  
  // Check for task verbs BEFORE deciding roster-only
  const taskVerbs = /\b(fix|repair|check|install|paint|handle|do|clean|inspect|replace|build|finish|complete|look at|work on|take care of|electrical|plumbing|drywall|tile|framing|flooring|wiring|pipes|sink|heater|roof|wall|door|window)\b/i;
  const hasTaskContent = taskVerbs.test(lower);
  
  // If it's a roster-only phrase, no task verbs detected, and we have an assignee, return assign_job
  if (isRosterOnly && !hasTaskContent && assignee) {
    return {
      action: 'assign_job',
      assignee: assignee,
      job_identifier: null,
      confidence: 0.9
    };
  }
  
  // Task detection: if there's an assignee + action verb, it's a task
  const isTask = assignee || /\b(tell|ask|have|task|remind|assign|put)\b/i.test(lower);
  
  let content = transcript;
  if (assignee) {
    const assigneeLower = assignee.toLowerCase();
    
    // Handle "assign [person] to [task]" - extract task AFTER the person's name
    const assignPersonToMatch = lower.match(new RegExp(`assign\\s+${assigneeLower}\\s+to\\s+(.+)`, 'i'));
    if (assignPersonToMatch) {
      content = assignPersonToMatch[1];
    }
    // Handle "assign [task] to [person]" - extract task BEFORE "to [person]"
    else {
      const assignTaskToMatch = lower.match(new RegExp(`assign\\s+(.+?)\\s+to\\s+${assigneeLower}`, 'i'));
      if (assignTaskToMatch) {
        content = assignTaskToMatch[1];
      }
    }
    
    // Handle "put [person] on [task]" pattern
    const putOnMatch = lower.match(new RegExp(`put\\s+${assigneeLower}\\s+on\\s+(.+)`, 'i'));
    if (putOnMatch) {
      content = putOnMatch[1];
    }
    
    // Handle "tell/ask/have [person] to [task]" pattern
    const tellToMatch = lower.match(new RegExp(`(tell|ask|have|get)\\s+${assigneeLower}\\s+to\\s+(.+)`, 'i'));
    if (tellToMatch) {
      content = tellToMatch[2];
    }
    
    // Handle "[person] needs to [task]" pattern
    const needsToMatch = lower.match(new RegExp(`${assigneeLower}\\s+needs?\\s+to\\s+(.+)`, 'i'));
    if (needsToMatch) {
      content = needsToMatch[1];
    }
    
    // Fallback: remove intro phrases if no pattern matched
    if (content === transcript) {
      content = content.replace(new RegExp(`(tell|ask|have|assign|put)\\s+${assignee}\\s+(to|on)?\\s*`, 'gi'), '');
      content = content.replace(new RegExp(`${assignee}\\s+(needs?\\s+to|should)\\s*`, 'gi'), '');
    }
  }
  content = content.replace(/^(add note|note|add task|task)[\s:]+/i, '').trim();
  
  // If we have an assignee and task verbs are detected, it's a task
  if (assignee && hasTaskContent) {
    return {
      action: 'add_task',
      assignee: assignee,
      job_identifier: null,
      content: content || 'general work',
      confidence: 0.85
    };
  }
  
  // If we have an assignee but no clear task content, it's likely a roster assignment
  if (assignee && !hasTaskContent) {
    // If the content is just the person's name or very short, it's probably roster-only
    if (content.toLowerCase() === assignee.toLowerCase() || content.length < 4) {
      return {
        action: 'assign_job',
        assignee: assignee,
        job_identifier: null,
        confidence: 0.7
      };
    }
    // Otherwise treat as a task with the content
    return {
      action: 'add_task',
      assignee: assignee,
      job_identifier: null,
      content: content,
      confidence: 0.75
    };
  }
  
  return {
    action: isTask ? 'add_task' : 'add_note',
    assignee: assignee,
    job_identifier: null,
    content: content,
    confidence: assignee ? 0.85 : 0.7
  };
}

app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

const distPath = path.join(__dirname, '..', 'dist');

// Serve static files with no-cache headers to prevent stale content
app.use(express.static(distPath, {
  setHeaders: (res, filePath) => {
    // HTML files should never be cached
    if (filePath.endsWith('.html')) {
      res.set({
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
    }
  }
}));

app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return next();
  }
  if (req.method === 'GET') {
    res.set({
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.sendFile(path.join(distPath, 'index.html'));
  } else {
    next();
  }
});

app.put('/api/auth/change-password', authenticateToken, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    const user = userResult.rows[0];
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const validPassword = await bcrypt.compare(currentPassword, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }
    
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await pool.query('UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', [hashedPassword, req.user.id]);
    
    res.json({ success: true, message: 'Password changed successfully' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/auth/change-username', authenticateToken, async (req, res) => {
  try {
    const { currentPassword, newUsername } = req.body;
    
    if (!currentPassword) {
      return res.status(400).json({ error: 'Current password is required' });
    }
    
    if (!newUsername || newUsername.trim().length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters' });
    }
    
    const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    const user = userResult.rows[0];
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const validPassword = await bcrypt.compare(currentPassword, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }
    
    // Check if username is already taken
    const existingUser = await pool.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1) AND id != $2', [newUsername.trim(), req.user.id]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'Username is already taken' });
    }
    
    await pool.query('UPDATE users SET username = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2', [newUsername.trim(), req.user.id]);
    
    res.json({ success: true, message: 'Username changed successfully' });
  } catch (error) {
    console.error('Change username error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

const placesCache = new Map();
const PLACES_CACHE_TTL = 5 * 60 * 1000;

if (typeof globalThis.fetch === 'undefined') {
  console.warn('WARNING: Global fetch not available. Google Places API requires Node.js 18+.');
}

app.get('/api/places/autocomplete', authenticateToken, async (req, res) => {
  const { input } = req.query;
  
  if (!input || input.length < 3) {
    return res.json({ predictions: [] });
  }
  
  const apiKey = process.env.GOOGLE_MAPS_API_KEY || process.env.googlemaps || process.env.GOOGLEMAPS_;
  if (!apiKey) {
    console.error('❌ GOOGLE_MAPS_API_KEY not configured - address autocomplete disabled');
    console.error('   Add GOOGLE_MAPS_API_KEY to Replit Secrets to enable this feature');
    return res.status(500).json({ 
      error: 'Address autocomplete not available. Admin needs to configure Google Maps API key.',
      code: 'MISSING_API_KEY'
    });
  }
  
  const cacheKey = `autocomplete:${input.toLowerCase()}`;
  const cached = placesCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < PLACES_CACHE_TTL) {
    return res.json(cached.data);
  }
  
  try {
    const url = new URL('https://maps.googleapis.com/maps/api/place/autocomplete/json');
    url.searchParams.append('input', input);
    url.searchParams.append('key', apiKey);
    url.searchParams.append('types', 'address');
    url.searchParams.append('components', 'country:us');
    url.searchParams.append('language', 'en');
    
    const response = await fetch(url.toString());
    const data = await response.json();
    
    if (data.status === 'OK' || data.status === 'ZERO_RESULTS') {
      const result = {
        predictions: (data.predictions || []).map(p => ({
          place_id: p.place_id,
          description: p.description,
          main_text: p.structured_formatting?.main_text,
          secondary_text: p.structured_formatting?.secondary_text,
        }))
      };
      
      placesCache.set(cacheKey, { data: result, timestamp: Date.now() });
      return res.json(result);
    }
    
    console.error('Google Places API error:', data.status, data.error_message);
    return res.json({ predictions: [] });
  } catch (error) {
    console.error('Places autocomplete error:', error);
    return res.status(500).json({ error: 'Failed to fetch address suggestions' });
  }
});

app.get('/api/places/details', authenticateToken, async (req, res) => {
  const { place_id } = req.query;
  
  if (!place_id) {
    return res.status(400).json({ error: 'Place ID required' });
  }
  
  const apiKey = process.env.googlemaps || process.env.GOOGLEMAPS_;
  if (!apiKey) {
    return res.status(500).json({ error: 'Address lookup not configured' });
  }
  
  const cacheKey = `details:${place_id}`;
  const cached = placesCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < PLACES_CACHE_TTL) {
    return res.json(cached.data);
  }
  
  try {
    const url = new URL('https://maps.googleapis.com/maps/api/place/details/json');
    url.searchParams.append('place_id', place_id);
    url.searchParams.append('key', apiKey);
    url.searchParams.append('fields', 'formatted_address,address_components,geometry');
    
    const response = await fetch(url.toString());
    const data = await response.json();
    
    if (data.status === 'OK' && data.result) {
      const result = {
        formatted_address: data.result.formatted_address,
        address_components: data.result.address_components,
        location: data.result.geometry?.location,
      };
      
      placesCache.set(cacheKey, { data: result, timestamp: Date.now() });
      return res.json(result);
    }
    
    console.error('Google Places Details API error:', data.status);
    return res.status(404).json({ error: 'Place not found' });
  } catch (error) {
    console.error('Places details error:', error);
    return res.status(500).json({ error: 'Failed to fetch address details' });
  }
});

// =====================================================
// COMPANY SETTINGS API (White-label configuration)
// =====================================================

const companyLogoDir = path.join(__dirname, '..', 'uploads', 'company');
if (!fs.existsSync(companyLogoDir)) {
  fs.mkdirSync(companyLogoDir, { recursive: true });
}

const companyLogoStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, companyLogoDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.png';
    cb(null, `company-logo-${Date.now()}${ext}`);
  }
});
const companyLogoUpload = multer({ 
  storage: companyLogoStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'), false);
    }
  }
});

app.get('/api/company-settings', async (req, res) => {
  try {
    let companyId = 1;
    const authHeader = req.headers['authorization'];
    if (authHeader) {
      const token = authHeader.split(' ')[1];
      try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const userResult = await pool.query('SELECT company_id FROM users WHERE id = $1', [decoded.id]);
        if (userResult.rows.length > 0 && userResult.rows[0].company_id) {
          companyId = userResult.rows[0].company_id;
        }
      } catch (e) {}
    }
    const result = await pool.query('SELECT * FROM company_settings WHERE company_id = $1 LIMIT 1', [companyId]);
    if (result.rows.length === 0) {
      return res.json({
        company_name: 'ProTrack',
        logo_path: null,
        contact_phone: '',
        contact_email: '',
        business_address: '',
        primary_color: '#2563eb',
        setup_completed: false
      });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching company settings:', error);
    res.status(500).json({ error: 'Failed to fetch company settings' });
  }
});

app.put('/api/company-settings', authenticateToken, async (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  try {
    const { company_name, contact_phone, contact_email, business_address, primary_color, setup_completed } = req.body;
    
    if (!requireCompany(req, res)) return;
    const cid = req.user.company_id;
    const existing = await pool.query('SELECT id FROM company_settings WHERE company_id = $1 LIMIT 1', [cid]);
    
    if (existing.rows.length === 0) {
      const result = await pool.query(
        `INSERT INTO company_settings (company_name, contact_phone, contact_email, business_address, primary_color, setup_completed, updated_at, company_id)
         VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7)
         RETURNING *`,
        [company_name, contact_phone, contact_email, business_address, primary_color || '#2563eb', setup_completed ?? false, cid]
      );
      return res.json(result.rows[0]);
    }
    
    const result = await pool.query(
      `UPDATE company_settings SET 
        company_name = COALESCE($1, company_name),
        contact_phone = COALESCE($2, contact_phone),
        contact_email = COALESCE($3, contact_email),
        business_address = COALESCE($4, business_address),
        primary_color = COALESCE($5, primary_color),
        setup_completed = COALESCE($6, setup_completed),
        updated_at = NOW()
       WHERE id = $7 AND company_id = $8
       RETURNING *`,
      [company_name, contact_phone, contact_email, business_address, primary_color, setup_completed, existing.rows[0].id, cid]
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating company settings:', error);
    res.status(500).json({ error: 'Failed to update company settings' });
  }
});

app.post('/api/company-settings/logo', authenticateToken, companyLogoUpload.single('logo'), async (req, res) => {
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const logoPath = `/uploads/company/${req.file.filename}`;
    
    if (!requireCompany(req, res)) return;
    const cid = req.user.company_id;
    const existing = await pool.query('SELECT id, logo_path FROM company_settings WHERE company_id = $1 LIMIT 1', [cid]);
    
    if (existing.rows.length > 0 && existing.rows[0].logo_path) {
      const oldPath = path.join(__dirname, '..', existing.rows[0].logo_path);
      if (fs.existsSync(oldPath)) {
        fs.unlinkSync(oldPath);
      }
    }
    
    if (existing.rows.length === 0) {
      await pool.query(
        `INSERT INTO company_settings (logo_path, updated_at, company_id) VALUES ($1, NOW(), $2)`,
        [logoPath, cid]
      );
    } else {
      await pool.query(
        `UPDATE company_settings SET logo_path = $1, updated_at = NOW() WHERE id = $2 AND company_id = $3`,
        [logoPath, existing.rows[0].id, cid]
      );
    }
    
    res.json({ logo_path: logoPath, message: 'Logo uploaded successfully' });
  } catch (error) {
    console.error('Error uploading company logo:', error);
    res.status(500).json({ error: 'Failed to upload logo' });
  }
});

app.use('/uploads/company', express.static(companyLogoDir));



async function logStartupHealth() {
  console.log('\n🏥 STARTUP HEALTH CHECK');
  console.log('═'.repeat(50));
  
  // Database
  try {
    await pool.query('SELECT 1');
    console.log('✅ Database: Connected');
  } catch (e) {
    console.log('❌ Database: Failed -', e.message);
  }
  
  // Anthropic API
  console.log(anthropic ? '✅ Voice AI: Enabled (Claude API)' : '⚠️  Voice AI: Fallback mode (no API key)');
  
  // Google Maps
  const mapsKey = process.env.GOOGLE_MAPS_API_KEY || process.env.googlemaps || process.env.GOOGLEMAPS_;
  console.log(mapsKey ? '✅ Address Autocomplete: Enabled' : '⚠️  Address Autocomplete: Disabled (no API key)');
  
  // Check for notification config in DB
  try {
    const notifCheck = await pool.query("SELECT COUNT(*) FROM settings WHERE key LIKE 'notification_%'");
    const notifCount = parseInt(notifCheck.rows[0].count);
    const twilioFromEnv = process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER;
    console.log((notifCount > 0 || twilioFromEnv) ? '✅ Notifications: Configured' + (twilioFromEnv ? ' (Twilio from env)' : '') : '⚠️  Notifications: Not configured (setup in app Settings)');
  } catch (e) {
    console.log('⚠️  Notifications: Unknown status');
  }
  
  console.log('═'.repeat(50));
  console.log(`🚀 Server ready on port ${PORT}\n`);
}

async function runMultiTenantMigrations() {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS companies (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      slug VARCHAR(255) UNIQUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    await pool.query(`CREATE TABLE IF NOT EXISTS invites (
      id SERIAL PRIMARY KEY,
      company_id INTEGER REFERENCES companies(id),
      email VARCHAR(255) NOT NULL,
      role VARCHAR(50) DEFAULT 'user',
      token VARCHAR(255) UNIQUE NOT NULL,
      expires_at TIMESTAMP NOT NULL,
      accepted BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    const tables = ['users', 'jobs', 'tasks', 'notes', 'photos', 'notifications_log', 'activity_logs', 'company_settings', 'settings', 'email_accounts', 'job_assignments'];
    for (const table of tables) {
      await pool.query(`ALTER TABLE ${table} ADD COLUMN IF NOT EXISTS company_id INTEGER REFERENCES companies(id)`).catch(() => {});
    }

    const demoCompany = await pool.query("SELECT id FROM companies WHERE id = 1");
    if (demoCompany.rows.length === 0) {
      await pool.query("INSERT INTO companies (id, name, slug) VALUES (1, 'Demo Company', 'demo') ON CONFLICT (id) DO NOTHING");
      await pool.query("SELECT setval('companies_id_seq', GREATEST((SELECT MAX(id) FROM companies), 1))");
    }

    for (const table of tables) {
      await pool.query(`UPDATE ${table} SET company_id = 1 WHERE company_id IS NULL`).catch(() => {});
    }

    await pool.query(`
      DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_constraint WHERE conname = 'settings_key_company_id_unique'
        ) THEN
          ALTER TABLE settings DROP CONSTRAINT IF EXISTS settings_key_key;
          ALTER TABLE settings ADD CONSTRAINT settings_key_company_id_unique UNIQUE (key, company_id);
        END IF;
      END $$;
    `).catch(e => console.log('Settings constraint migration:', e.message));

    console.log('Multi-tenant migrations complete');
  } catch (error) {
    console.error('Multi-tenant migration error:', error);
  }
}

app.listen(PORT, '0.0.0.0', async () => {
  await runMultiTenantMigrations();
  await logStartupHealth();
});
