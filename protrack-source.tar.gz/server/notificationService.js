const crypto = require('crypto');
const nodemailer = require('nodemailer');

class NotificationService {
  constructor(pool, sendNotificationFn = null) {
    this.pool = pool;
    this.sendNotificationFn = sendNotificationFn;
    this.DEDUP_WINDOW_HOURS = 24;
    this.MAX_RETRIES = 3;
    this.RETRY_DELAYS = [1000, 5000, 15000];
    this.emailTransporters = {};
  }
  
  setSendNotificationFn(fn) {
    this.sendNotificationFn = fn;
  }

  async getEmailTransporter(companyId = null) {
    const cacheKey = companyId || 'default';
    if (this.emailTransporters[cacheKey]) return this.emailTransporters[cacheKey];
    
    try {
      let settingsResult;
      if (companyId) {
        settingsResult = await this.pool.query('SELECT * FROM settings WHERE key LIKE $1 AND company_id = $2', ['notification_%', companyId]);
      } else {
        settingsResult = await this.pool.query('SELECT * FROM settings WHERE key LIKE $1', ['notification_%']);
      }
      const config = {};
      settingsResult.rows.forEach(row => { config[row.key] = row.value; });
      
      if (config.notification_smtp_server && config.notification_smtp_username) {
        const ENCRYPTION_KEY = process.env.JWT_SECRET || 'default-encryption-key-32chars!';
        const decryptPassword = (text) => {
          if (!text || !text.includes(':')) return '';
          try {
            const [ivHex, encrypted] = text.split(':');
            const iv = Buffer.from(ivHex, 'hex');
            const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
            const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
            let decrypted = decipher.update(encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');
            return decrypted;
          } catch (e) { return ''; }
        };
        
        const transporter = nodemailer.createTransport({
          host: config.notification_smtp_server,
          port: parseInt(config.notification_smtp_port || 587),
          secure: config.notification_smtp_port === '465',
          auth: {
            user: config.notification_smtp_username,
            pass: decryptPassword(config.notification_smtp_password)
          }
        });
        this.emailTransporters[cacheKey] = { transporter, fromEmail: config.notification_email_address || config.notification_smtp_username };
        return this.emailTransporters[cacheKey];
      }
    } catch (error) {
      console.error('Failed to create email transporter:', error.message);
    }
    return null;
  }

  generateTaskHash(description) {
    return crypto.createHash('md5').update(description.toLowerCase().trim()).digest('hex').substring(0, 16);
  }

  generateBatchId() {
    return crypto.randomBytes(16).toString('hex');
  }

  async checkDuplicate(recipientId, jobId, taskHash) {
    const windowStart = new Date(Date.now() - this.DEDUP_WINDOW_HOURS * 60 * 60 * 1000);
    
    const result = await this.pool.query(
      `SELECT id, sent_at, status FROM notifications_log 
       WHERE recipient_id = $1 AND job_id = $2 AND task_hash = $3 
       AND sent_at > $4 AND status IN ('sent', 'delivered')
       ORDER BY sent_at DESC LIMIT 1`,
      [recipientId, jobId, taskHash, windowStart]
    );
    
    if (result.rows.length > 0) {
      const hoursAgo = Math.round((Date.now() - new Date(result.rows[0].sent_at).getTime()) / (1000 * 60 * 60));
      return {
        isDuplicate: true,
        lastNotified: result.rows[0].sent_at,
        hoursAgo: hoursAgo
      };
    }
    return { isDuplicate: false };
  }

  async getUserPreference(userId) {
    const result = await this.pool.query(
      'SELECT notification_preference FROM users WHERE id = $1',
      [userId]
    );
    return result.rows[0]?.notification_preference || 'immediate';
  }

  async sendToUser(userId, message, subject = 'ProTrack - Task Assignment', attachments = []) {
    const userResult = await this.pool.query(
      'SELECT phone, email, notify_preference, company_id FROM users WHERE id = $1',
      [userId]
    );
    const user = userResult.rows[0];
    
    if (!user) {
      return { success: false, error: 'User not found' };
    }
    
    const results = { sms: null, email: null };
    const preference = user.notify_preference || 'email';
    
    if ((preference === 'sms' || preference === 'both') && user.phone) {
      results.sms = { success: true, provider: 'twilio-pending' };
    }
    
    if ((preference === 'email' || preference === 'both') && user.email) {
      const transporterConfig = await this.getEmailTransporter(user.company_id);
      if (transporterConfig) {
        try {
          await transporterConfig.transporter.sendMail({
            from: transporterConfig.fromEmail,
            to: user.email,
            subject,
            text: message,
            html: `<div style="font-family: Arial, sans-serif; padding: 20px;">
              <h2 style="color: #1c3b59;">ProTrack</h2>
              <p style="font-size: 16px; line-height: 1.5;">${message.replace(/\n/g, '<br>')}</p>
            </div>`
          });
          console.log(`✉️ Email sent to ${user.email}`);
          results.email = { success: true };
        } catch (error) {
          console.error(`✉️ Email failed to ${user.email}:`, error.message);
          results.email = { success: false, error: error.message };
        }
      }
    }
    
    if (this.sendNotificationFn) {
      try {
        await this.sendNotificationFn('mention', userId, message, subject, attachments);
      } catch (error) {
        console.error('sendNotificationFn failed:', error.message);
      }
    }
    
    const anySuccess = (results.sms?.success || results.email?.success);
    return { success: anySuccess, results };
  }

  async logNotification(data) {
    const result = await this.pool.query(
      `INSERT INTO notifications_log 
       (recipient_id, recipient_name, recipient_contact, job_id, task_hash, message_content, status, skip_reason, batch_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id`,
      [data.recipientId, data.recipientName, data.recipientContact, data.jobId, 
       data.taskHash, data.message, data.status, data.skipReason, data.batchId]
    );
    return result.rows[0].id;
  }

  async sendWithRetry(userId, phone, message, logId, attachments = []) {
    for (let attempt = 0; attempt <= this.MAX_RETRIES; attempt++) {
      try {
        const result = await this.sendToUser(userId, message, 'ProTrack - Task Assignment', attachments);
        if (result.success) {
          await this.pool.query(
            'UPDATE notifications_log SET status = $1, retry_count = $2 WHERE id = $3',
            ['sent', attempt, logId]
          );
          return { success: true, attempts: attempt + 1 };
        }
      } catch (error) {
        console.error(`Notification attempt ${attempt + 1} failed:`, error.message);
        if (attempt < this.MAX_RETRIES) {
          await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAYS[attempt]));
        }
      }
    }
    
    await this.pool.query(
      'UPDATE notifications_log SET status = $1, retry_count = $2 WHERE id = $3',
      ['failed', this.MAX_RETRIES, logId]
    );
    return { success: false, attempts: this.MAX_RETRIES };
  }

  async processMentions(mentions, jobId, senderName, noteContent, attachments = []) {
    const results = [];
    const batchId = this.generateBatchId();
    
    const jobResult = await this.pool.query(
      'SELECT customer_name, address FROM jobs WHERE id = $1',
      [jobId]
    );
    const job = jobResult.rows[0];
    const jobLocation = job?.address || job?.customer_name || `Job #${jobId}`;
    
    const mentionsByRecipient = {};
    for (const mention of mentions) {
      const key = mention.userId;
      if (!mentionsByRecipient[key]) {
        mentionsByRecipient[key] = {
          user: mention,
          tasks: []
        };
      }
      mentionsByRecipient[key].tasks.push(mention.task || mention.action || 'New mention');
    }
    
    for (const recipientId of Object.keys(mentionsByRecipient)) {
      const data = mentionsByRecipient[recipientId];
      const user = data.user;
      const tasks = data.tasks;
      
      const preference = await this.getUserPreference(user.userId);
      
      if (preference === 'disabled') {
        results.push({
          recipient: user.name,
          status: 'skipped',
          reason: 'Notifications disabled'
        });
        continue;
      }
      
      if (preference === 'daily_digest') {
        let queuedCount = 0;
        let skippedCount = 0;
        for (const task of tasks) {
          const taskHash = this.generateTaskHash(task);
          const dupCheck = await this.checkDuplicate(user.userId, jobId, taskHash);
          
          if (dupCheck.isDuplicate) {
            await this.logNotification({
              recipientId: user.userId,
              recipientName: user.name,
              recipientContact: user.phone,
              jobId,
              taskHash,
              message: task,
              status: 'skipped',
              skipReason: `Already notified ${dupCheck.hoursAgo}h ago`,
              batchId
            });
            skippedCount++;
          } else {
            await this.logNotification({
              recipientId: user.userId,
              recipientName: user.name,
              recipientContact: user.phone,
              jobId,
              taskHash,
              message: task,
              status: 'pending',
              skipReason: 'Queued for daily digest',
              batchId
            });
            queuedCount++;
          }
        }
        results.push({
          recipient: user.name,
          status: queuedCount > 0 ? 'queued' : 'skipped',
          reason: queuedCount > 0 ? `${queuedCount} task(s) will be sent in daily digest at 8 AM` : `All ${skippedCount} task(s) already notified`,
          taskCount: queuedCount,
          skippedCount: skippedCount
        });
        continue;
      }
      
      const tasksToSend = [];
      const skippedTasks = [];
      
      for (const task of tasks) {
        const taskHash = this.generateTaskHash(task);
        const dupCheck = await this.checkDuplicate(user.userId, jobId, taskHash);
        
        if (dupCheck.isDuplicate) {
          await this.logNotification({
            recipientId: user.userId,
            recipientName: user.name,
            recipientContact: user.phone,
            jobId,
            taskHash,
            message: task,
            status: 'skipped',
            skipReason: `Already notified ${dupCheck.hoursAgo}h ago`,
            batchId
          });
          skippedTasks.push({ task, hoursAgo: dupCheck.hoursAgo });
        } else {
          tasksToSend.push({ task, taskHash });
        }
      }
      
      if (tasksToSend.length === 0) {
        results.push({
          recipient: user.name,
          status: 'skipped',
          reason: `All ${skippedTasks.length} task(s) already notified`,
          skippedTasks
        });
        continue;
      }
      
      let message;
      if (tasksToSend.length === 1) {
        message = `Hi ${user.name}, ${senderName} added a task for you at ${jobLocation}: ${tasksToSend[0].task}. Reply DONE when complete.`;
      } else {
        const taskList = tasksToSend.map(t => `• ${t.task}`).join('\n');
        message = `Hi ${user.name}, ${senderName} added ${tasksToSend.length} tasks for you at ${jobLocation}:\n${taskList}\nReply DONE when complete.`;
      }
      
      const combinedHash = this.generateTaskHash(tasksToSend.map(t => t.task).join('|'));
      const logId = await this.logNotification({
        recipientId: user.userId,
        recipientName: user.name,
        recipientContact: user.phone,
        jobId,
        taskHash: combinedHash,
        message,
        status: 'pending',
        batchId
      });
      
      const sendResult = await this.sendWithRetry(user.userId, user.phone, message, logId, attachments);
      
      results.push({
        recipient: user.name,
        status: sendResult.success ? 'sent' : 'failed',
        taskCount: tasksToSend.length,
        skippedCount: skippedTasks.length,
        message: sendResult.success ? message : 'Failed after 3 retries'
      });
    }
    
    return {
      batchId,
      results,
      totalMentions: mentions.length,
      sentCount: results.filter(r => r.status === 'sent').length,
      skippedCount: results.filter(r => r.status === 'skipped').length
    };
  }

  async getNotificationHistory(jobId, limit = 50) {
    const result = await this.pool.query(
      `SELECT id, recipient_name, recipient_contact, task_hash, message_content, 
              sent_at, status, skip_reason, batch_id
       FROM notifications_log 
       WHERE job_id = $1 
       ORDER BY sent_at DESC 
       LIMIT $2`,
      [jobId, limit]
    );
    return result.rows;
  }

  async forceResend(notificationId, senderName) {
    const original = await this.pool.query(
      'SELECT * FROM notifications_log WHERE id = $1',
      [notificationId]
    );
    
    if (!original.rows[0]) {
      return { success: false, error: 'Notification not found' };
    }
    
    const notification = original.rows[0];
    const newLogId = await this.logNotification({
      recipientId: notification.recipient_id,
      recipientName: notification.recipient_name,
      recipientContact: notification.recipient_contact,
      jobId: notification.job_id,
      taskHash: notification.task_hash + '_resend',
      message: notification.message_content,
      status: 'pending',
      batchId: this.generateBatchId()
    });
    
    const result = await this.sendWithRetry(notification.recipient_id, notification.recipient_contact, notification.message_content, newLogId);
    return result;
  }

  async sendDailyDigests() {
    const pendingResult = await this.pool.query(
      `SELECT DISTINCT recipient_id, recipient_name, recipient_contact 
       FROM notifications_log 
       WHERE status = 'pending' AND skip_reason LIKE '%daily digest%'`
    );
    
    for (const recipient of pendingResult.rows) {
      const tasksResult = await this.pool.query(
        `SELECT nl.*, j.client_name, j.address 
         FROM notifications_log nl
         JOIN jobs j ON nl.job_id = j.id
         WHERE nl.recipient_id = $1 AND nl.status = 'pending' AND nl.skip_reason LIKE '%daily digest%'
         ORDER BY nl.job_id, nl.created_at`,
        [recipient.recipient_id]
      );
      
      if (tasksResult.rows.length === 0) continue;
      
      const tasksByJob = {};
      for (const row of tasksResult.rows) {
        if (!tasksByJob[row.job_id]) {
          tasksByJob[row.job_id] = {
            jobName: row.address || row.client_name,
            tasks: []
          };
        }
        tasksByJob[row.job_id].tasks.push(row.message_content);
      }
      
      let message = `Good morning ${recipient.recipient_name}! Here are your tasks for today:\n\n`;
      for (const [jobId, data] of Object.entries(tasksByJob)) {
        message += `📍 ${data.jobName}:\n`;
        data.tasks.forEach(t => message += `  • ${t}\n`);
        message += '\n';
      }
      message += 'Reply DONE [task] when complete.';
      
      console.log(`📱 Daily digest to ${recipient.recipient_name}: ${tasksResult.rows.length} tasks`);
      
      try {
        await this.sendToUser(recipient.recipient_id, message, 'ProTrack - Daily Task Summary');
        
        await this.pool.query(
          `UPDATE notifications_log SET status = 'sent', sent_at = NOW() 
           WHERE recipient_id = $1 AND status = 'pending' AND skip_reason LIKE '%daily digest%'`,
          [recipient.recipient_id]
        );
      } catch (error) {
        console.error(`Failed to send digest to ${recipient.recipient_name}:`, error.message);
        await this.pool.query(
          `UPDATE notifications_log SET status = 'failed' 
           WHERE recipient_id = $1 AND status = 'pending' AND skip_reason LIKE '%daily digest%'`,
          [recipient.recipient_id]
        );
      }
    }
    
    return { digestsSent: pendingResult.rows.length };
  }

  startDailyDigestScheduler() {
    const checkTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      if (hours === 8 && minutes === 0) {
        console.log('🕗 Running daily digest at 8:00 AM...');
        this.sendDailyDigests().catch(err => console.error('Daily digest error:', err));
      }
    };
    setInterval(checkTime, 60000);
    console.log('📬 Daily digest scheduler initialized (checks every minute, sends at 8 AM)');
  }
}

module.exports = NotificationService;
