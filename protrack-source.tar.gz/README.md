# ProTrack - Contractor Job Management

**Professional white-label job tracking system for contractors**

A complete, customizable job management solution for construction and contracting companies. Built with React Native (Expo) and Express.js backend.

---

## Features

- **Voice Dictation** - Create notes and tasks hands-free with AI-powered voice commands
- **Job Management** - Track jobs from estimate to completion
- **Team Management** - Assign workers, manage trades, track assignments
- **@Mention Notifications** - SMS and email notifications when team members are mentioned
- **Photo Documentation** - Attach photos to jobs from camera or gallery
- **Activity Logging** - Complete audit trail of all job activities
- **TV Dashboard Mode** - Display job overview on office TV
- **White-Label Ready** - Fully customizable branding (logo, company name, colors)

---

## Quick Start

```bash
npm install
node server/index.js
```

Access the app at the provided URL. Default admin login: `admin` / `admin123`

---

## White-Label Customization

ProTrack is designed as a white-label solution. Customize for any contractor:

1. **Login as Admin** - Use admin credentials
2. **Go to Settings** - Navigate to Company Branding section
3. **Upload Logo** - Add your company's logo
4. **Set Company Info** - Company name, phone, email, address
5. **Toggle Demo Mode** - Turn off when ready for production

All branding automatically updates throughout the app.

---

## Technology Stack

- **Frontend**: React Native (Expo) with web support
- **Backend**: Express.js REST API
- **Database**: PostgreSQL
- **AI**: Claude API for voice command parsing
- **Notifications**: Email (SMTP) and SMS (Twilio)
- **Address**: Google Places API autocomplete

---

## Environment Variables

Required secrets (add to Replit Secrets):

- `DATABASE_URL` - PostgreSQL connection string
- `JWT_SECRET` - Secret key for authentication tokens
- `ANTHROPIC_API_KEY` - (Optional) For AI voice commands
- `GOOGLE_MAPS_API_KEY` - (Optional) For address autocomplete
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER` - (Optional) For SMS

---

## Documentation

- See Settings page for notification and branding configuration
- Voice commands work with natural language: "Tell Mike to fix the door at 123 Main St"

---

## Demo Version

This is a demonstration version of ProTrack. The DEMO VERSION banner can be disabled in Settings > Company Branding once configured for a client.

**Ready for deployment!**
